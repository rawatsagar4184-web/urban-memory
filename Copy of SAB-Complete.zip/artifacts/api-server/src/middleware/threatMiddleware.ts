import { type Request, type Response, type NextFunction } from "express";
import {
  recordRequest,
  isBlacklisted,
  isHoneypotPath,
  HONEYPOT_PATHS,
} from "../core/threatIntelligence.js";

const DELAY_MS_PER_LAYER: Record<number, number> = {
  1: 0,
  2: 200,
  3: 800,
  4: 2000,
  5: 5000,
};

export function threatMiddleware(req: Request, res: Response, next: NextFunction): void {
  const ip =
    (req.headers["x-forwarded-for"] as string)?.split(",")[0]?.trim() ??
    req.socket.remoteAddress ??
    "unknown";

  if (isBlacklisted(ip)) {
    res.status(429).json({
      error: "Too many requests. Access temporarily suspended.",
      code: "BLACKLISTED",
      message:
        "आपका IP अस्थायी रूप से अवरुद्ध है। संदिग्ध गतिविधि दर्ज की गई है।",
    });
    return;
  }

  const record = recordRequest(req);

  if (isHoneypotPath(req.path)) {
    const delay = DELAY_MS_PER_LAYER[Math.min(record?.layer ?? 1, 5)] ?? 0;
    setTimeout(() => {
      res.status(403).json({
        error: "Access denied",
        code: "HONEYPOT",
        message: "यह क्षेत्र प्रतिबंधित है। आपकी गतिविधि दर्ज की जा रही है।",
        fake_data: {
          note: "This is a monitored decoy endpoint.",
          timestamp: new Date().toISOString(),
        },
      });
    }, delay);
    return;
  }

  if (record && record.layer >= 3) {
    const delay = DELAY_MS_PER_LAYER[Math.min(record.layer, 5)] ?? 0;
    if (delay > 0) {
      setTimeout(() => next(), delay);
      return;
    }
  }

  next();
}

export { HONEYPOT_PATHS };
