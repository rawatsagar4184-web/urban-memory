import { createHash, randomBytes } from "crypto";
import { SAB_TO_INR_RATE } from "./blockchain.js";

export interface Wallet {
  address: string;
  privateKey: string;
  ownerName: string;
  balance: number;
  transactionCount: number;
  createdAt: string;
}

function generateKeyPair(): { address: string; privateKey: string } {
  const privateKey = randomBytes(32).toString("hex");
  const address =
    "SAB" +
    createHash("sha256").update(privateKey).digest("hex").slice(0, 40).toUpperCase();
  return { address, privateKey };
}

class WalletStore {
  private wallets: Map<string, Wallet> = new Map();

  create(ownerName: string, initialBalance = 1000): Wallet {
    const { address, privateKey } = generateKeyPair();
    const wallet: Wallet = {
      address,
      privateKey,
      ownerName,
      balance: initialBalance,
      transactionCount: 0,
      createdAt: new Date().toISOString(),
    };
    this.wallets.set(address, wallet);
    return wallet;
  }

  get(address: string): Wallet | undefined {
    return this.wallets.get(address);
  }

  verifyKey(address: string, privateKey: string): boolean {
    const w = this.wallets.get(address);
    return w !== undefined && w.privateKey === privateKey;
  }

  debit(address: string, amount: number): boolean {
    const w = this.wallets.get(address);
    if (!w || w.balance < amount) return false;
    w.balance -= amount;
    w.transactionCount++;
    return true;
  }

  credit(address: string, amount: number): void {
    const w = this.wallets.get(address);
    if (w) {
      w.balance += amount;
      w.transactionCount++;
    }
  }

  totalWallets(): number {
    return this.wallets.size;
  }

  totalSABInCirculation(): number {
    let total = 0;
    for (const w of this.wallets.values()) total += w.balance;
    return total;
  }

  toINR(sab: number): number {
    return sab / SAB_TO_INR_RATE;
  }
}

export const walletStore = new WalletStore();

walletStore.create("Sagar Bhai (Owner)", 10_000_000);
