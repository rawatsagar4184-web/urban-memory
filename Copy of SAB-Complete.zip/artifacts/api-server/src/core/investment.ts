// @quantum-safe: SHA-3 migration hook reserved | @pqc-hook: dilithium2 slot reserved
// Investment Engine: Fixed Deposit, Recurring Deposit, Standing Instructions

// ── Rate Tables ──────────────────────────────────────────────────────────────
const FD_RATES: Record<string, number> = {
  "7d": 4.0, "30d": 5.0, "90d": 5.75, "180d": 6.5, "365d": 7.5,
};
const FD_DAYS: Record<string, number> = {
  "7d": 7, "30d": 30, "90d": 90, "180d": 180, "365d": 365,
};
const SC_BONUS = 2.0;

// ── Types ────────────────────────────────────────────────────────────────────
export interface FDRecord {
  id: string;
  accountNumber: string;
  principal: number;
  tenure: "7d" | "30d" | "90d" | "180d" | "365d";
  ratePercent: number;
  scBonus: boolean;
  openedAt: string;
  maturesAt: string;
  maturityAmount: number;
  status: "active" | "matured" | "closed";
}

export interface RDRecord {
  id: string;
  accountNumber: string;
  monthlyAmount: number;
  tenureMonths: number;
  ratePercent: number;
  openedAt: string;
  maturesAt: string;
  installmentsPaid: number;
  totalDeposited: number;
  status: "active" | "matured" | "closed";
}

export type SIFrequency = "once" | "daily" | "weekly" | "monthly";
export interface SIRecord {
  id: string;
  accountNumber: string;
  toAccount: string;
  amount: number;
  description: string;
  frequency: SIFrequency;
  nextRunAt: string;
  createdAt: string;
  status: "active" | "cancelled";
  runsCompleted: number;
}

// ── Stores (O(1) indexed) ────────────────────────────────────────────────────
const fdById = new Map<string, FDRecord>();
const fdByAcc = new Map<string, string[]>();
const rdById = new Map<string, RDRecord>();
const rdByAcc = new Map<string, string[]>();
const siById = new Map<string, SIRecord>();
const siByAcc = new Map<string, string[]>();

const uid = (prefix: string) =>
  `${prefix}${Date.now()}${Math.random().toString(36).slice(2, 5).toUpperCase()}`;

// ── FD API ───────────────────────────────────────────────────────────────────
export function openFD(
  accountNumber: string,
  principal: number,
  tenure: string,
  scBonus = false
): FDRecord {
  if (principal < 1000) throw new Error("न्यूनतम FD राशि ₹1,000 है");
  if (!FD_RATES[tenure]) throw new Error("अमान्य tenure — 7d/30d/90d/180d/365d");
  const rate = FD_RATES[tenure]! + (scBonus ? SC_BONUS : 0);
  const days = FD_DAYS[tenure]!;
  const now = Date.now();
  const fd: FDRecord = {
    id: uid("FD"),
    accountNumber,
    principal,
    tenure: tenure as FDRecord["tenure"],
    ratePercent: rate,
    scBonus,
    openedAt: new Date(now).toISOString(),
    maturesAt: new Date(now + days * 86_400_000).toISOString(),
    maturityAmount: +(principal * (1 + (rate / 100) * (days / 365))).toFixed(2),
    status: "active",
  };
  fdById.set(fd.id, fd);
  const list = fdByAcc.get(accountNumber) ?? [];
  list.push(fd.id);
  fdByAcc.set(accountNumber, list);
  return fd;
}

export function getFDsByAccount(accountNumber: string): FDRecord[] {
  return (fdByAcc.get(accountNumber) ?? [])
    .map(id => fdById.get(id)!)
    .filter(Boolean);
}

export function closeFDRecord(fdId: string): FDRecord {
  const fd = fdById.get(fdId);
  if (!fd) throw new Error("FD नहीं मिली");
  if (fd.status !== "active") throw new Error("FD पहले से बंद है");
  fd.status = "closed";
  return fd;
}

export function getRateCard() {
  return {
    rates: Object.entries(FD_RATES).map(([tenure, rate]) => ({
      tenure,
      rate,
      scBonusRate: rate + SC_BONUS,
      days: FD_DAYS[tenure]!,
    })),
    scBonusNote: `SAB Wallet से link FD पर +${SC_BONUS}% अतिरिक्त ब्याज`,
  };
}

// ── RD API ───────────────────────────────────────────────────────────────────
export function openRD(
  accountNumber: string,
  monthlyAmount: number,
  tenureMonths: number
): RDRecord {
  if (monthlyAmount < 100) throw new Error("न्यूनतम RD ₹100/माह है");
  if (tenureMonths < 6 || tenureMonths > 120)
    throw new Error("RD अवधि 6–120 माह होनी चाहिए");
  const rate = tenureMonths <= 12 ? 5.5 : tenureMonths <= 36 ? 6.0 : 6.75;
  const now = Date.now();
  const rd: RDRecord = {
    id: uid("RD"),
    accountNumber,
    monthlyAmount,
    tenureMonths,
    ratePercent: rate,
    openedAt: new Date(now).toISOString(),
    maturesAt: new Date(now + tenureMonths * 30 * 86_400_000).toISOString(),
    installmentsPaid: 0,
    totalDeposited: 0,
    status: "active",
  };
  rdById.set(rd.id, rd);
  const list = rdByAcc.get(accountNumber) ?? [];
  list.push(rd.id);
  rdByAcc.set(accountNumber, list);
  return rd;
}

export function getRDsByAccount(accountNumber: string): RDRecord[] {
  return (rdByAcc.get(accountNumber) ?? [])
    .map(id => rdById.get(id)!)
    .filter(Boolean);
}

// ── SI API ───────────────────────────────────────────────────────────────────
function nextRunDate(freq: SIFrequency): string {
  const d = new Date();
  if (freq === "daily") d.setDate(d.getDate() + 1);
  else if (freq === "weekly") d.setDate(d.getDate() + 7);
  else if (freq === "monthly") d.setMonth(d.getMonth() + 1);
  else d.setDate(d.getDate() + 1);
  return d.toISOString();
}

export function createSIRecord(
  accountNumber: string,
  toAccount: string,
  amount: number,
  description: string,
  frequency: SIFrequency
): SIRecord {
  if (amount <= 0) throw new Error("राशि शून्य से अधिक होनी चाहिए");
  if (accountNumber === toAccount) throw new Error("एक ही खाते में SI नहीं");
  const si: SIRecord = {
    id: uid("SI"),
    accountNumber,
    toAccount,
    amount,
    description,
    frequency,
    nextRunAt: nextRunDate(frequency),
    createdAt: new Date().toISOString(),
    status: "active",
    runsCompleted: 0,
  };
  siById.set(si.id, si);
  const list = siByAcc.get(accountNumber) ?? [];
  list.push(si.id);
  siByAcc.set(accountNumber, list);
  return si;
}

export function getSIsByAccount(accountNumber: string): SIRecord[] {
  return (siByAcc.get(accountNumber) ?? [])
    .map(id => siById.get(id)!)
    .filter(Boolean);
}

export function cancelSIRecord(siId: string): SIRecord {
  const si = siById.get(siId);
  if (!si) throw new Error("SI नहीं मिली");
  si.status = "cancelled";
  return si;
}
