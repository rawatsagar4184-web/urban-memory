/* ============================================================
   SAB Live User Tracker — RAM only, no DB needed
   Tracks active sessions by heartbeat pings
   Session = active if pinged within last 10 minutes
   ============================================================ */

const SAB_SESSION_TTL_MS = 10 * 60 * 1000; // 10 minutes

interface SAB_Session {
  id: string;
  firstSeen: number;
  lastSeen: number;
  page: string;
}

const sab_sessions = new Map<string, SAB_Session>();

export function sab_ping(sessionId: string, page = "/"): void {
  const now = Date.now();
  const existing = sab_sessions.get(sessionId);
  if (existing) {
    existing.lastSeen = now;
    existing.page = page;
  } else {
    sab_sessions.set(sessionId, { id: sessionId, firstSeen: now, lastSeen: now, page });
  }
}

export function sab_getLiveStats() {
  const now = Date.now();
  // evict stale sessions
  for (const [id, s] of sab_sessions) {
    if (now - s.lastSeen > SAB_SESSION_TTL_MS) sab_sessions.delete(id);
  }
  const active = Array.from(sab_sessions.values());
  const pageMap: Record<string, number> = {};
  for (const s of active) {
    pageMap[s.page] = (pageMap[s.page] ?? 0) + 1;
  }
  return {
    liveCount: active.length,
    totalSessions: sab_sessions.size,
    pages: pageMap,
    updatedAt: new Date().toISOString(),
  };
}
