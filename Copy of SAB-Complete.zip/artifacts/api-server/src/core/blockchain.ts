import { createHash, randomBytes } from "crypto";

export const SAB_TO_INR_RATE = 100;
export const MINING_DIFFICULTY = 2;
export const TRANSACTION_FEE_PERCENT = 0.001;

export interface Transaction {
  id: string;
  fromAddress: string | null;
  toAddress: string;
  amount: number;
  fee: number;
  timestamp: string;
  type: "transfer" | "reward" | "genesis";
}

export interface Block {
  index: number;
  timestamp: string;
  transactions: Transaction[];
  hash: string;
  previousHash: string;
  nonce: number;
}

function sha256(data: string): string {
  return createHash("sha256").update(data).digest("hex");
}

function calcHash(
  index: number,
  timestamp: string,
  transactions: Transaction[],
  previousHash: string,
  nonce: number,
): string {
  return sha256(
    `${index}${timestamp}${JSON.stringify(transactions)}${previousHash}${nonce}`,
  );
}

function mineBlock(
  index: number,
  timestamp: string,
  transactions: Transaction[],
  previousHash: string,
): { hash: string; nonce: number } {
  let nonce = 0;
  let hash = calcHash(index, timestamp, transactions, previousHash, nonce);
  const prefix = "0".repeat(MINING_DIFFICULTY);
  while (!hash.startsWith(prefix)) {
    nonce++;
    hash = calcHash(index, timestamp, transactions, previousHash, nonce);
  }
  return { hash, nonce };
}

function createGenesisBlock(): Block {
  const timestamp = new Date().toISOString();
  const transactions: Transaction[] = [
    {
      id: "genesis-tx-001",
      fromAddress: null,
      toAddress: "SABSE_AAGE_BHARAT_GENESIS",
      amount: 1_000_000_000,
      fee: 0,
      timestamp,
      type: "genesis",
    },
  ];
  const { hash, nonce } = mineBlock(0, timestamp, transactions, "0");
  return { index: 0, timestamp, transactions, hash, previousHash: "0", nonce };
}

class Blockchain {
  chain: Block[] = [createGenesisBlock()];
  pendingTransactions: Transaction[] = [];
  isFrozen = false;

  getLatestBlock(): Block {
    return this.chain[this.chain.length - 1];
  }

  addTransaction(tx: Omit<Transaction, "id">): Transaction {
    const full: Transaction = { id: randomBytes(16).toString("hex"), ...tx };
    this.pendingTransactions.push(full);
    return full;
  }

  minePendingTransactions(): Block {
    const timestamp = new Date().toISOString();
    const prev = this.getLatestBlock();
    const transactions = [...this.pendingTransactions];
    const { hash, nonce } = mineBlock(
      prev.index + 1,
      timestamp,
      transactions,
      prev.hash,
    );
    const block: Block = {
      index: prev.index + 1,
      timestamp,
      transactions,
      hash,
      previousHash: prev.hash,
      nonce,
    };
    this.chain.push(block);
    this.pendingTransactions = [];
    return block;
  }

  isChainValid(): boolean {
    for (let i = 1; i < this.chain.length; i++) {
      const curr = this.chain[i];
      const prev = this.chain[i - 1];
      if (curr.previousHash !== prev.hash) return false;
      const recomputed = calcHash(
        curr.index,
        curr.timestamp,
        curr.transactions,
        curr.previousHash,
        curr.nonce,
      );
      if (curr.hash !== recomputed) return false;
    }
    return true;
  }

  getAllTransactions(): Transaction[] {
    return this.chain.flatMap((b) => b.transactions);
  }

  getTotalCirculation(): number {
    const all = this.getAllTransactions();
    let total = 0;
    for (const tx of all) {
      if (tx.type === "genesis") continue;
      if (tx.fromAddress === null) total += tx.amount;
    }
    return total;
  }
}

export const blockchain = new Blockchain();
