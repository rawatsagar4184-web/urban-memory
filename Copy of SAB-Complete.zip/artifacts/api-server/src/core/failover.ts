import { logger } from "../lib/logger.js";

export interface ServerNode {
  id: string;
  url: string;
  priority: number;
}

export interface NodeHealth {
  id: string;
  url: string;
  status: "up" | "down" | "unknown";
  latencyMs: number;
  lastChecked: string;
  failCount: number;
}

const FAIL_THRESHOLD = 3;
const INTERVAL_MS = 30_000;

function loadRegistry(): ServerNode[] {
  const nodes: ServerNode[] = [
    { id: "primary",   url: process.env["PRIMARY_URL"]   ?? "", priority: 1 },
    { id: "fallback1", url: process.env["FALLBACK_1_URL"] ?? "", priority: 2 },
    { id: "fallback2", url: process.env["FALLBACK_2_URL"] ?? "", priority: 3 },
  ];
  return nodes.filter(n => n.url.length > 0);
}

const healthMap = new Map<string, NodeHealth>();
let heartbeatTimer: ReturnType<typeof setInterval> | null = null;

async function pingNode(node: ServerNode): Promise<void> {
  const prev = healthMap.get(node.id);
  const failCount = prev?.failCount ?? 0;
  const t0 = Date.now();
  try {
    const ctrl = new AbortController();
    const timeout = setTimeout(() => ctrl.abort(), 2000);
    const res = await fetch(`${node.url}/api/healthz`, { signal: ctrl.signal });
    clearTimeout(timeout);
    const latencyMs = Date.now() - t0;
    healthMap.set(node.id, {
      id: node.id, url: node.url,
      status: res.ok ? "up" : "down",
      latencyMs, failCount: res.ok ? 0 : failCount + 1,
      lastChecked: new Date().toISOString(),
    });
    if (!res.ok) logger.warn({ node: node.id }, "Heartbeat: non-OK response");
  } catch {
    const newFail = failCount + 1;
    healthMap.set(node.id, {
      id: node.id, url: node.url, status: newFail >= FAIL_THRESHOLD ? "down" : "unknown",
      latencyMs: Date.now() - t0, failCount: newFail,
      lastChecked: new Date().toISOString(),
    });
    logger.warn({ node: node.id, failCount: newFail }, "Heartbeat: unreachable");
  }
}

async function runHeartbeat(): Promise<void> {
  const nodes = loadRegistry();
  await Promise.all(nodes.map(pingNode));
}

export function startHeartbeat(): void {
  const nodes = loadRegistry();
  if (nodes.length === 0) {
    logger.info("Failover: no external nodes configured — single-server mode");
    return;
  }
  nodes.forEach(n => healthMap.set(n.id, { id: n.id, url: n.url, status: "unknown", latencyMs: 0, failCount: 0, lastChecked: new Date().toISOString() }));
  void runHeartbeat();
  heartbeatTimer = setInterval(() => { void runHeartbeat(); }, INTERVAL_MS);
  logger.info({ nodes: nodes.map(n => n.id) }, "Failover: heartbeat started");
}

export function stopHeartbeat(): void {
  if (heartbeatTimer) { clearInterval(heartbeatTimer); heartbeatTimer = null; }
}

export function getBestNode(): ServerNode | null {
  const nodes = loadRegistry().sort((a, b) => a.priority - b.priority);
  for (const n of nodes) {
    const h = healthMap.get(n.id);
    if (!h || h.status !== "down") return n;
  }
  return null;
}

export function getHealthReport(): NodeHealth[] {
  return Array.from(healthMap.values()).sort((a, b) => a.id.localeCompare(b.id));
}
