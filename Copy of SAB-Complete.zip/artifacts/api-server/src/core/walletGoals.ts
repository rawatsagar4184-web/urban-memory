// Wallet Savings Goals — O(1) indexed, quota-saver design

export interface WalletGoal {
  id: string;
  walletAddress: string;
  name: string;
  targetAmount: number;
  savedAmount: number;
  progressPercent: number;
  createdAt: string;
}

const goalById = new Map<string, WalletGoal>();
const goalByWallet = new Map<string, string[]>();

const uid = () =>
  `GOAL${Date.now()}${Math.random().toString(36).slice(2, 5).toUpperCase()}`;

export function createGoal(
  walletAddress: string,
  name: string,
  targetAmount: number
): WalletGoal {
  if (targetAmount <= 0) throw new Error("लक्ष्य राशि शून्य से अधिक होनी चाहिए");
  if (!name.trim()) throw new Error("लक्ष्य का नाम आवश्यक है");
  const goal: WalletGoal = {
    id: uid(),
    walletAddress,
    name: name.trim(),
    targetAmount,
    savedAmount: 0,
    progressPercent: 0,
    createdAt: new Date().toISOString(),
  };
  goalById.set(goal.id, goal);
  const list = goalByWallet.get(walletAddress) ?? [];
  list.push(goal.id);
  goalByWallet.set(walletAddress, list);
  return goal;
}

export function getGoalsByWallet(walletAddress: string): WalletGoal[] {
  return (goalByWallet.get(walletAddress) ?? [])
    .map(id => goalById.get(id)!)
    .filter(Boolean);
}
