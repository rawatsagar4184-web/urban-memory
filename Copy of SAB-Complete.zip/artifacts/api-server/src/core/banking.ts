import { randomBytes } from "crypto";

export interface BankAccount {
  accountNumber: string;
  ifscCode: string;
  holderName: string;
  mobile: string;
  aadhaarLast4: string;
  balance: number;
  sabLinked: string | null;
  createdAt: string;
  isActive: boolean;
  accountType: "savings" | "current" | "Jan Dhan";
  upiId: string;
  dailyDebitTotal: number;
  dailyDebitDate: string;
  suspiciousFlags: number;
  lastTxTime: number;
  rapidTxCount: number;
}

export interface BankTransaction {
  id: string;
  accountNumber: string;
  type: "credit" | "debit";
  amount: number;
  description: string;
  reference: string;
  balanceBefore: number;
  balanceAfter: number;
  timestamp: string;
  mode: "UPI" | "NEFT" | "IMPS" | "SAB" | "CASH" | "ATM";
  status: "success" | "failed" | "pending";
  fraudFlag?: boolean;
}

// O(1) lookups — indexed by accountNumber
const accounts = new Map<string, BankAccount>();
// Per-account transaction list — O(1) statement fetch
const txIndex = new Map<string, BankTransaction[]>();
// UPI reverse index — O(1) UPI→account lookup
const upiIndex = new Map<string, string>();
// Global recent-tx ring for admin view (capped at 500)
const globalTxRing: BankTransaction[] = [];
const RING_CAP = 500;

// Daily limits (₹) by account type
const DAILY_LIMIT: Record<BankAccount["accountType"], number> = {
  "savings": 100_000,
  "current": 1_000_000,
  "Jan Dhan": 10_000,
};

// Rapid-fire window: >5 transactions in 30s = suspicious
const RAPID_WINDOW_MS = 30_000;
const RAPID_THRESHOLD = 5;

function genId(): string {
  return randomBytes(6).toString("hex").toUpperCase();
}

function genAccountNumber(): string {
  return "SAB" + Date.now().toString().slice(-7) + genId().slice(0, 4);
}

function genIFSC(): string {
  return "SAAB0" + genId().slice(0, 6);
}

function genRef(): string {
  return "REF" + Date.now().toString(36).toUpperCase() + genId().slice(0, 4);
}

function genUPI(name: string, mobile: string): string {
  const slug = name.toLowerCase().replace(/\s+/g, "").slice(0, 8);
  return `${slug}.${mobile.slice(-4)}@sabpay`;
}

function todayStr(): string {
  return new Date().toISOString().slice(0, 10);
}

function pushTx(tx: BankTransaction): void {
  // Per-account index
  const list = txIndex.get(tx.accountNumber) ?? [];
  list.unshift(tx);
  txIndex.set(tx.accountNumber, list);
  // Global ring — O(1) cap
  globalTxRing.unshift(tx);
  if (globalTxRing.length > RING_CAP) globalTxRing.length = RING_CAP;
}

// Fraud check: velocity + daily limit
function checkFraud(acc: BankAccount, amount: number): { blocked: boolean; flag: boolean; reason?: string } {
  const today = todayStr();
  const now = Date.now();

  // Reset daily counter if new day
  if (acc.dailyDebitDate !== today) {
    acc.dailyDebitTotal = 0;
    acc.dailyDebitDate = today;
    acc.rapidTxCount = 0;
    acc.lastTxTime = 0;
  }

  // Daily limit check
  if (acc.dailyDebitTotal + amount > DAILY_LIMIT[acc.accountType]) {
    return { blocked: true, flag: true, reason: `Daily debit limit ₹${DAILY_LIMIT[acc.accountType].toLocaleString()} exceeded` };
  }

  // Rapid-fire detection
  if (now - acc.lastTxTime < RAPID_WINDOW_MS) {
    acc.rapidTxCount += 1;
  } else {
    acc.rapidTxCount = 1;
  }
  acc.lastTxTime = now;

  const flag = acc.rapidTxCount > RAPID_THRESHOLD;
  if (flag) acc.suspiciousFlags += 1;

  return { blocked: false, flag };
}

export function createBankAccount(data: {
  holderName: string;
  mobile: string;
  aadhaarNumber: string;
  accountType: "savings" | "current" | "Jan Dhan";
  sabWalletAddress?: string;
}): BankAccount {
  const accountNumber = genAccountNumber();
  const upiId = genUPI(data.holderName, data.mobile);

  const account: BankAccount = {
    accountNumber,
    ifscCode: genIFSC(),
    holderName: data.holderName,
    mobile: data.mobile,
    aadhaarLast4: data.aadhaarNumber.slice(-4),
    balance: 0,
    sabLinked: data.sabWalletAddress ?? null,
    createdAt: new Date().toISOString(),
    isActive: true,
    accountType: data.accountType,
    upiId,
    dailyDebitTotal: 0,
    dailyDebitDate: todayStr(),
    suspiciousFlags: 0,
    lastTxTime: 0,
    rapidTxCount: 0,
  };

  accounts.set(accountNumber, account);
  upiIndex.set(upiId, accountNumber);
  txIndex.set(accountNumber, []);

  // Welcome entry
  pushTx({
    id: genId(),
    accountNumber,
    type: "credit",
    amount: 0,
    description: "खाता खोला गया — SAB Core Banking में आपका स्वागत है",
    reference: "OPEN-" + accountNumber,
    balanceBefore: 0,
    balanceAfter: 0,
    timestamp: new Date().toISOString(),
    mode: "CASH",
    status: "success",
  });

  return account;
}

export function getAccount(accountNumber: string): BankAccount | undefined {
  return accounts.get(accountNumber);
}

export function getAccountByUPI(upiId: string): BankAccount | undefined {
  const accNum = upiIndex.get(upiId);
  return accNum ? accounts.get(accNum) : undefined;
}

export function getAllAccounts(): BankAccount[] {
  return [...accounts.values()];
}

export function deposit(
  accountNumber: string,
  amount: number,
  description: string,
  mode: BankTransaction["mode"] = "CASH"
): BankTransaction {
  const acc = accounts.get(accountNumber);
  if (!acc) throw new Error("Account not found");
  if (!acc.isActive) throw new Error("Account is inactive");
  if (amount <= 0 || !Number.isFinite(amount)) throw new Error("Invalid amount");

  const before = acc.balance;
  acc.balance += amount;

  const tx: BankTransaction = {
    id: genId(),
    accountNumber,
    type: "credit",
    amount,
    description,
    reference: genRef(),
    balanceBefore: before,
    balanceAfter: acc.balance,
    timestamp: new Date().toISOString(),
    mode,
    status: "success",
  };
  pushTx(tx);
  return tx;
}

export function withdraw(
  accountNumber: string,
  amount: number,
  description: string,
  mode: BankTransaction["mode"] = "ATM"
): BankTransaction {
  const acc = accounts.get(accountNumber);
  if (!acc) throw new Error("Account not found");
  if (!acc.isActive) throw new Error("Account is inactive");
  if (amount <= 0 || !Number.isFinite(amount)) throw new Error("Invalid amount");
  if (acc.balance < amount) throw new Error("Insufficient balance");

  const fraud = checkFraud(acc, amount);
  if (fraud.blocked) throw new Error(fraud.reason);

  const before = acc.balance;
  acc.balance -= amount;
  acc.dailyDebitTotal += amount;

  const tx: BankTransaction = {
    id: genId(),
    accountNumber,
    type: "debit",
    amount,
    description,
    reference: genRef(),
    balanceBefore: before,
    balanceAfter: acc.balance,
    timestamp: new Date().toISOString(),
    mode,
    status: "success",
    fraudFlag: fraud.flag,
  };
  pushTx(tx);
  return tx;
}

export function transfer(
  fromAccount: string,
  toAccount: string,
  amount: number,
  description: string,
  mode: BankTransaction["mode"] = "UPI"
): { debit: BankTransaction; credit: BankTransaction } {
  if (fromAccount === toAccount) throw new Error("Cannot transfer to same account");
  const from = accounts.get(fromAccount);
  const to = accounts.get(toAccount);
  if (!from) throw new Error("Source account not found");
  if (!to) throw new Error("Destination account not found");
  if (!from.isActive) throw new Error("Source account is inactive");
  if (!to.isActive) throw new Error("Destination account is inactive");
  if (amount <= 0 || !Number.isFinite(amount)) throw new Error("Invalid amount");
  if (from.balance < amount) throw new Error("Insufficient balance");

  const fraud = checkFraud(from, amount);
  if (fraud.blocked) throw new Error(fraud.reason);

  const ref = genRef();
  const ts = new Date().toISOString();

  const beforeFrom = from.balance;
  from.balance -= amount;
  from.dailyDebitTotal += amount;

  const beforeTo = to.balance;
  to.balance += amount;

  const debit: BankTransaction = {
    id: genId(),
    accountNumber: fromAccount,
    type: "debit",
    amount,
    description: `Transfer to ${toAccount} — ${description}`,
    reference: ref,
    balanceBefore: beforeFrom,
    balanceAfter: from.balance,
    timestamp: ts,
    mode,
    status: "success",
    fraudFlag: fraud.flag,
  };

  const credit: BankTransaction = {
    id: genId(),
    accountNumber: toAccount,
    type: "credit",
    amount,
    description: `Transfer from ${fromAccount} — ${description}`,
    reference: ref,
    balanceBefore: beforeTo,
    balanceAfter: to.balance,
    timestamp: ts,
    mode,
    status: "success",
  };

  pushTx(debit);
  pushTx(credit);
  return { debit, credit };
}

// O(1) — direct index lookup, no filter
export function getStatement(accountNumber: string, limit = 20): BankTransaction[] {
  return (txIndex.get(accountNumber) ?? []).slice(0, limit);
}

export function getAllTransactions(limit = 50): BankTransaction[] {
  return globalTxRing.slice(0, limit);
}

export function getBankingStats() {
  const allAccs = [...accounts.values()];
  const totalBalance = allAccs.reduce((s, a) => s + a.balance, 0);
  const totalDeposits = globalTxRing
    .filter(t => t.type === "credit" && t.amount > 0)
    .reduce((s, t) => s + t.amount, 0);
  const suspiciousCount = allAccs.reduce((s, a) => s + a.suspiciousFlags, 0);

  return {
    totalAccounts: accounts.size,
    totalBalance,
    totalTransactions: globalTxRing.length,
    totalDeposits,
    janDhanAccounts: allAccs.filter(a => a.accountType === "Jan Dhan").length,
    activeAccounts: allAccs.filter(a => a.isActive).length,
    sabLinkedAccounts: allAccs.filter(a => a.sabLinked).length,
    suspiciousFlags: suspiciousCount,
  };
}

export function getFraudAlerts(): BankTransaction[] {
  return globalTxRing.filter(t => t.fraudFlag).slice(0, 20);
}
