import { Router } from "express";
import { randomBytes } from "crypto";
const router = Router();

const BANNED_WORDS = ["obscene1", "banned2"];

const seedPosts = [
  { id: "p1", authorName: "राम प्रसाद नेगी", content: "उत्तराखंड के पहाड़ों की यह सुंदरता अतुलनीय है। हमारी स्वदेशी धरती, हमारी पहचान।", type: "text" as const, likes: 2340, comments: 145, sabReward: 234, createdAt: new Date(Date.now() - 3600000).toISOString(), isModerated: true },
  { id: "p2", authorName: "प्रिया रावत", content: "सबसे आगे भारत प्लेटफॉर्म से आज मेरी पहाड़ी ऐपण कला को 1000 लोगों ने देखा। SAB Coin में 500 मिले!", type: "photo" as const, likes: 5670, comments: 389, sabReward: 567, createdAt: new Date(Date.now() - 7200000).toISOString(), isModerated: true },
  { id: "p3", authorName: "किसान सुरेश पंत", content: "आज मंडी में सेब का भाव ₹4500/क्विंटल मिला। कृषि मित्र की सलाह से फसल बेहतर हुई।", type: "text" as const, likes: 1890, comments: 234, sabReward: 189, createdAt: new Date(Date.now() - 10800000).toISOString(), isModerated: true },
  { id: "p4", authorName: "Sagar Bhai (Owner)", content: "सबसे आगे भारत — यह केवल एक ऐप नहीं, यह हमारी डिजिटल स्वतंत्रता की घोषणा है। जय हिंद!", type: "text" as const, likes: 12500, comments: 890, sabReward: 1250, createdAt: new Date(Date.now() - 1800000).toISOString(), isModerated: true },
];

const posts = [...seedPosts];

router.get("/social/feed", (req, res) => {
  const limit = Math.min(Number(req.query["limit"]) || 20, 100);
  res.json({ posts: posts.slice(0, limit), total: posts.length });
});

router.post("/social/post", (req, res) => {
  const { authorName, content, type } = req.body as { authorName: string; content: string; type: "text"|"reel"|"photo" };
  if (!authorName || !content || !type) { res.status(400).json({ error: "सभी फ़ील्ड आवश्यक हैं" }); return; }
  const hasBanned = BANNED_WORDS.some(w => content.toLowerCase().includes(w));
  if (hasBanned) { res.status(400).json({ error: "आपत्तिजनक सामग्री पाई गई। पोस्ट ब्लॉक की गई।", code: "MODERATED" }); return; }
  const post = {
    id: randomBytes(4).toString("hex"),
    authorName, content, type,
    likes: 0, comments: 0,
    sabReward: Math.floor(Math.random() * 50) + 10,
    createdAt: new Date().toISOString(),
    isModerated: true,
  };
  posts.unshift(post as typeof seedPosts[number]);
  res.status(201).json(post);
});

router.get("/social/stats", (_req, res) => {
  res.json({ totalUsers: 485000, totalPosts: posts.length, totalReels: 12400, activeToday: 23400, totalSABDistributed: 2450000 });
});

export default router;
