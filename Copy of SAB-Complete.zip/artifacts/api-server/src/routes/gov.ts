import { Router } from "express";
import { randomBytes } from "crypto";
const router = Router();

const services = [
  { id: "g1", name: "जाति प्रमाण पत्र", department: "राजस्व विभाग", description: "अनुसूचित जाति/जनजाति/OBC प्रमाण पत्र के लिए आवेदन", processingDays: 7, isOnline: true, requiredDocs: ["आधार कार्ड", "निवास प्रमाण", "पुराना जाति प्रमाण (यदि हो)"] },
  { id: "g2", name: "मूल निवास प्रमाण पत्र", department: "राजस्व विभाग", description: "उत्तराखंड का मूल निवास प्रमाण पत्र", processingDays: 10, isOnline: true, requiredDocs: ["आधार कार्ड", "वोटर ID", "पिता/माता का प्रमाण"] },
  { id: "g3", name: "राशन कार्ड (नया/संशोधन)", department: "खाद्य विभाग", description: "नया राशन कार्ड बनवाएं या पुराने में बदलाव करें", processingDays: 21, isOnline: true, requiredDocs: ["आधार कार्ड", "परिवार के सभी सदस्यों का आधार", "आय प्रमाण"] },
  { id: "g4", name: "किसान क्रेडिट कार्ड", department: "कृषि विभाग", description: "किसानों के लिए 3 लाख तक का ऋण", processingDays: 14, isOnline: true, requiredDocs: ["आधार कार्ड", "ज़मीन की खतौनी", "बैंक पासबुक"] },
  { id: "g5", name: "विधवा पेंशन", department: "समाज कल्याण", description: "पात्र विधवाओं के लिए मासिक पेंशन", processingDays: 30, isOnline: true, requiredDocs: ["मृत्यु प्रमाण पत्र", "आधार कार्ड", "बैंक खाता"] },
  { id: "g6", name: "वृद्धावस्था पेंशन", department: "समाज कल्याण", description: "60 वर्ष से ऊपर के वरिष्ठ नागरिकों के लिए", processingDays: 30, isOnline: true, requiredDocs: ["आधार कार्ड", "आयु प्रमाण", "बैंक खाता"] },
  { id: "g7", name: "कृषि सब्सिडी आवेदन", department: "कृषि विभाग", description: "बीज, खाद और यंत्रों पर सरकारी अनुदान", processingDays: 15, isOnline: true, requiredDocs: ["किसान क्रेडिट कार्ड", "ज़मीन की खतौनी", "बैंक खाता"] },
];

const applications: Array<{ applicationId: string; serviceName: string; serviceId: string; applicantName: string; status: "submitted"|"processing"|"approved"|"rejected"; submittedAt: string; estimatedCompletion: string }> = [];

router.get("/gov/services", (_req, res) => {
  res.json({ services, total: services.length });
});

router.post("/gov/apply", (req, res) => {
  const { serviceId, applicantName, aadhaarNumber, mobileNumber, address } = req.body as {
    serviceId: string; applicantName: string; aadhaarNumber: string; mobileNumber: string; address: string;
  };
  if (!serviceId || !applicantName || !aadhaarNumber || !mobileNumber || !address) {
    res.status(400).json({ error: "सभी आवश्यक जानकारी भरें" }); return;
  }
  const service = services.find(s => s.id === serviceId);
  if (!service) { res.status(404).json({ error: "सेवा नहीं मिली" }); return; }
  const applicationId = "SAB-GOV-" + randomBytes(4).toString("hex").toUpperCase();
  const submittedAt = new Date().toISOString();
  const completion = new Date(Date.now() + service.processingDays * 86400000).toISOString();
  applications.push({ applicationId, serviceName: service.name, serviceId, applicantName, status: "submitted", submittedAt, estimatedCompletion: completion });
  res.status(201).json({ applicationId, serviceId, applicantName, status: "submitted", submittedAt, estimatedCompletion: completion });
});

router.get("/gov/applications", (_req, res) => {
  res.json({ applications, total: applications.length });
});

export default router;
