import { Router } from "express";
const router = Router();

const SAB_INR_FIXED = 100;

function makeTicker() {
  const base = SAB_INR_FIXED;
  const jitter = (Math.random() - 0.5) * 0.002;
  return {
    pair: "SAB/INR",
    price: parseFloat((base + jitter).toFixed(4)),
    change24h: parseFloat(((Math.random() - 0.5) * 0.001).toFixed(4)),
    high24h: base + 0.001,
    low24h: base - 0.001,
    volume24h: Math.floor(Math.random() * 1000000) + 500000,
    sabToINRFixed: SAB_INR_FIXED,
  };
}

function makeOrderBook() {
  const bids = Array.from({ length: 8 }, (_, i) => ({
    price: parseFloat((SAB_INR_FIXED - (i + 1) * 0.0005).toFixed(4)),
    quantity: Math.floor(Math.random() * 50000) + 5000,
    total: 0,
  })).map(b => ({ ...b, total: parseFloat((b.price * b.quantity).toFixed(2)) }));

  const asks = Array.from({ length: 8 }, (_, i) => ({
    price: parseFloat((SAB_INR_FIXED + (i + 1) * 0.0005).toFixed(4)),
    quantity: Math.floor(Math.random() * 40000) + 3000,
    total: 0,
  })).map(a => ({ ...a, total: parseFloat((a.price * a.quantity).toFixed(2)) }));

  return { bids, asks, spread: parseFloat((asks[0].price - bids[0].price).toFixed(4)) };
}

function makeSwadeshiIndex() {
  const base = 18500;
  const now = Date.now();
  const history = Array.from({ length: 30 }, (_, i) => ({
    time: new Date(now - (29 - i) * 60000).toISOString(),
    value: parseFloat((base + (Math.random() - 0.5) * 200 + i * 3).toFixed(2)),
  }));
  const current = history[history.length - 1].value;
  const open = history[0].value;
  return {
    name: "SAB Swadeshi Index (SSI)",
    currentValue: current,
    change: parseFloat((current - open).toFixed(2)),
    changePercent: parseFloat(((current - open) / open * 100).toFixed(2)),
    high: Math.max(...history.map(h => h.value)),
    low: Math.min(...history.map(h => h.value)),
    history,
  };
}

router.get("/exchange/orderbook", (_req, res) => res.json(makeOrderBook()));
router.get("/exchange/ticker", (_req, res) => res.json(makeTicker()));
router.get("/exchange/index", (_req, res) => res.json(makeSwadeshiIndex()));

export default router;
