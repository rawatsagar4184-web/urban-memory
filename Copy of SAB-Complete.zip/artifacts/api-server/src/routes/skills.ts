import { Router } from "express";
const router = Router();

const categories = [
  { id: "s1", name: "सिलाई और कढ़ाई", description: "घरेलू सिलाई से लेकर फैशन डिज़ाइन तक", courseCount: 12, icon: "scissors" },
  { id: "s2", name: "हस्तशिल्प और पेंटिंग", description: "पहाड़ी हस्तकला, ऐपण, रंगोली और कला", courseCount: 8, icon: "palette" },
  { id: "s3", name: "मोमबत्ती और साबुन निर्माण", description: "घर पर ही व्यवसाय शुरू करें", courseCount: 6, icon: "flame" },
  { id: "s4", name: "खाद्य प्रसंस्करण", description: "अचार, पापड़, मुरब्बा और पहाड़ी उत्पाद", courseCount: 10, icon: "chef-hat" },
  { id: "s5", name: "डिजिटल मार्केटिंग", description: "अपने उत्पाद ऑनलाइन बेचना सीखें", courseCount: 7, icon: "trending-up" },
  { id: "s6", name: "मशरूम की खेती", description: "कम लागत में अधिक मुनाफा", courseCount: 4, icon: "sprout" },
];

const skillCourses = [
  { id: "sc1", title: "बेसिक सिलाई - शुरुआत से सीखें", category: "सिलाई और कढ़ाई", description: "मशीन चलाना, कपड़े काटना, सिलाई के मूल नियम", duration: "30 घंटे", enrolled: 28000, sabReward: 500, isFree: true },
  { id: "sc2", title: "पहाड़ी ऐपण कला", category: "हस्तशिल्प और पेंटिंग", description: "उत्तराखंड की पारंपरिक ऐपण लोककला सीखें", duration: "20 घंटे", enrolled: 15000, sabReward: 300, isFree: true },
  { id: "sc3", title: "अचार और मुरब्बा व्यवसाय", category: "खाद्य प्रसंस्करण", description: "घर से शुरू करें, सरकारी FSSAI लाइसेंस गाइड", duration: "25 घंटे", enrolled: 32000, sabReward: 600, isFree: true },
  { id: "sc4", title: "WhatsApp और Instagram से बेचें", category: "डिजिटल मार्केटिंग", description: "सोशल मीडिया से अपना व्यवसाय बढ़ाएं", duration: "15 घंटे", enrolled: 45000, sabReward: 400, isFree: true },
];

router.get("/skills/categories", (_req, res) => {
  res.json({ categories });
});

router.get("/skills/courses", (req, res) => {
  const { category } = req.query;
  const result = category ? skillCourses.filter(c => c.category === String(category)) : skillCourses;
  res.json({ courses: result });
});

export default router;
