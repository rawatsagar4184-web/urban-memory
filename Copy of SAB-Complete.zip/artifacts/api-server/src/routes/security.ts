import { Router } from "express";
const router = Router();

router.get("/security/status", (_req, res) => {
  res.json({
    cyberWallActive: true,
    ddosBlocked: Math.floor(Math.random() * 500) + 1240,
    ransomwareBlocked: 43,
    nodesOnline: 7,
    lastThreatAt: new Date(Date.now() - Math.random() * 3600000).toISOString(),
    encryptionLevel: "AES-256 + SHA-512",
    p2pNodeCount: 7,
    compressionRatio: "10x (LZ4 + custom)",
    backupStatus: "सुरक्षित — अंतिम बैकअप 2 घंटे पहले",
  });
});

router.get("/security/disaster-alert", (_req, res) => {
  res.json({
    alerts: [
      { id: "d1", type: "none", severity: "low", location: "उत्तराखंड", message: "सभी क्षेत्रों में स्थिति सामान्य है", timestamp: new Date().toISOString() },
    ],
    systemStatus: "सभी सेंसर सक्रिय — कोई आपदा चेतावनी नहीं",
  });
});

export default router;
