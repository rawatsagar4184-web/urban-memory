import { Router } from "express";
import { createGoal, getGoalsByWallet } from "../core/walletGoals.js";

const router = Router();

// ── Goals ────────────────────────────────────────────────────────────────────
router.post("/wallet/goal", (req, res) => {
  const { walletAddress, name, targetAmount } = req.body as {
    walletAddress: string; name: string; targetAmount: number;
  };
  if (!walletAddress || !name || !targetAmount) {
    res.status(400).json({ error: "walletAddress, name, targetAmount आवश्यक हैं" });
    return;
  }
  try {
    const goal = createGoal(walletAddress, name, Number(targetAmount));
    res.status(201).json(goal);
  } catch (e: unknown) {
    res.status(400).json({ error: e instanceof Error ? e.message : "Error" });
  }
});

router.get("/wallet/goals/:address", (req, res) => {
  const goals = getGoalsByWallet(req.params["address"] ?? "");
  res.json({ goals, total: goals.length });
});

// ── UPI QR ───────────────────────────────────────────────────────────────────
router.get("/wallet/qr/:upiId", (req, res) => {
  const upiId = req.params["upiId"] ?? "";
  const amount = req.query["amount"] ? Number(req.query["amount"]) : undefined;
  const note = (req.query["note"] as string | undefined) ?? "SAB Payment";
  const parts = [`pa=${encodeURIComponent(upiId)}`, `pn=SAB%20Pay`, `cu=INR`];
  if (amount) parts.push(`am=${amount}`);
  parts.push(`tn=${encodeURIComponent(note)}`);
  res.json({
    upiId,
    upiUri: `upi://pay?${parts.join("&")}`,
    amount: amount ?? 0,
    note,
    displayName: "SAB Pay — " + upiId,
  });
});

export default router;
