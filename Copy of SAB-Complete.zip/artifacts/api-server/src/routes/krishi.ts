import { Router } from "express";
const router = Router();

const mandiPrices = [
  { crop: "गेहूं", market: "देहरादून मंडी", pricePerQuintal: 2275, change: 25, trend: "up" as const },
  { crop: "धान (बासमती)", market: "हरिद्वार मंडी", pricePerQuintal: 3800, change: -50, trend: "down" as const },
  { crop: "मक्का", market: "रुड़की मंडी", pricePerQuintal: 1950, change: 10, trend: "up" as const },
  { crop: "आलू", market: "ऋषिकेश मंडी", pricePerQuintal: 1200, change: 0, trend: "stable" as const },
  { crop: "प्याज", market: "देहरादून मंडी", pricePerQuintal: 2100, change: 150, trend: "up" as const },
  { crop: "टमाटर", market: "हरिद्वार मंडी", pricePerQuintal: 1800, change: -200, trend: "down" as const },
  { crop: "सेब (पहाड़ी)", market: "मसूरी मंडी", pricePerQuintal: 4500, change: 200, trend: "up" as const },
  { crop: "माल्टा संतरा", market: "रानीखेत मंडी", pricePerQuintal: 3200, change: 100, trend: "up" as const },
];

const advisoryMap: Record<string, object> = {
  default: {
    crop: "सामान्य फसल",
    soilHealth: "मिट्टी की pH 6.5-7.0 — स्वस्थ",
    recommendation: "जैविक खाद का प्रयोग करें, रासायनिक खाद कम करें। फसल चक्र अपनाएं।",
    pestAlert: "इस मौसम में माहू (एफिड) का खतरा — नीम का तेल छिड़कें",
    irrigationAdvice: "सुबह 6-8 बजे सिंचाई करें, शाम को ड्रिप इरिगेशन बेहतर",
    expectedYield: "अनुमानित उत्पादन: 25-30 क्विंटल/हेक्टेयर",
  },
};

router.get("/krishi/advisory", (req, res) => {
  const crop = String(req.query["crop"] ?? "default");
  res.json(advisoryMap[crop] ?? { ...advisoryMap["default"], crop });
});

router.get("/krishi/mandi", (_req, res) => {
  res.json({ prices: mandiPrices, lastUpdated: new Date().toISOString() });
});

router.get("/krishi/weather", (_req, res) => {
  const today = new Date();
  const forecast = Array.from({ length: 7 }, (_, i) => {
    const d = new Date(today);
    d.setDate(d.getDate() + i);
    return {
      date: d.toISOString().split("T")[0],
      condition: ["आंशिक बादल", "साफ आसमान", "हल्की बारिश", "बादल", "धूप", "बारिश", "साफ"][i],
      tempMax: 28 - i * 0.5,
      tempMin: 18 - i * 0.3,
      rainfall: [0, 0, 12, 0, 0, 25, 0][i],
      humidity: [65, 60, 80, 70, 62, 88, 65][i],
      windSpeed: [12, 8, 18, 10, 9, 22, 11][i],
    };
  });
  res.json({
    location: "उत्तराखंड (देहरादून/रानीखेत क्षेत्र)",
    forecast,
    farmingAdvice: "अगले 3 दिनों में हल्की बारिश की संभावना — बुवाई रोकें, काटी गई फसल को ढकें",
  });
});

router.get("/krishi/livestock", (_req, res) => {
  res.json({
    beekeepingGuide: "उत्तराखंड में मधुमक्खी पालन के लिए मार्च-अप्रैल सबसे उपयुक्त है। एक बॉक्स से सालाना 30-40 किलो शहद मिलता है।",
    govSubsidies: [
      "राष्ट्रीय मधुमक्खी पालन एवं शहद मिशन — 50% सब्सिडी",
      "NABARD पशुपालन ऋण — 4% ब्याज दर",
      "उत्तराखंड दुग्ध विकास बोर्ड — प्रति लीटर ₹2 बोनस",
    ],
    trainingCenters: [
      "पंतनगर कृषि विश्वविद्यालय — मधुमक्खी पालन प्रशिक्षण केंद्र",
      "देहरादून — उत्तराखंड पशु चिकित्सा अनुसंधान केंद्र",
      "रानीखेत — पर्वतीय मधु उत्पादन केंद्र",
    ],
    livestockHealth: "पशुओं को FMD टीका लगवाएं। गाय/भैंस में थनेला रोग की जांच कराएं। साफ पानी और हरा चारा दें।",
    milkYieldTips: "संकर नस्ल (HF/जर्सी) से 15-20 लीटर/दिन, देशी गाय से 8-12 लीटर। वैज्ञानिक आहार से 20% उत्पादन बढ़ाएं।",
  });
});

export default router;
