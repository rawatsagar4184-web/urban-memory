import { Router } from "express";
import { blockchain, SAB_TO_INR_RATE } from "../core/blockchain.js";
import { walletStore } from "../core/wallet.js";

const router = Router();

router.get("/blockchain/chain", (_req, res) => {
  res.json({
    chain: blockchain.chain,
    length: blockchain.chain.length,
    isValid: blockchain.isChainValid(),
  });
});

router.get("/blockchain/stats", (_req, res) => {
  res.json({
    totalBlocks: blockchain.chain.length,
    totalTransactions: blockchain.getAllTransactions().length,
    totalSABInCirculation: walletStore.totalSABInCirculation(),
    totalWallets: walletStore.totalWallets(),
    isSystemFrozen: blockchain.isFrozen,
    difficulty: 2,
    sabToINRRate: SAB_TO_INR_RATE,
  });
});

router.get("/blockchain/transactions", (req, res) => {
  const limit = Math.min(Number(req.query["limit"]) || 20, 100);
  const all = blockchain.getAllTransactions().reverse().slice(0, limit);
  res.json({ transactions: all, total: blockchain.getAllTransactions().length });
});

export default router;
