import { Router } from "express";
const router = Router();

const langCourses = [
  { id: "l1", language: "English", level: "Beginner to Advanced", enrolled: 125000, description: "वैश्विक रोज़गार के लिए धाराप्रवाह अंग्रेजी - उच्चारण सुधार के साथ", flag: "GB" },
  { id: "l2", language: "German", level: "A1 to B2", enrolled: 34000, description: "जर्मनी में नौकरी और उच्च शिक्षा के लिए जर्मन भाषा", flag: "DE" },
  { id: "l3", language: "Spanish", level: "Beginner", enrolled: 28000, description: "लैटिन अमेरिका और स्पेन में करियर के अवसर", flag: "ES" },
  { id: "l4", language: "Japanese", level: "JLPT N5-N3", enrolled: 18000, description: "जापानी कंपनियों में नौकरी के लिए जापानी भाषा", flag: "JP" },
  { id: "l5", language: "French", level: "DELF A1-B1", enrolled: 22000, description: "फ्रांस और कनाडा में उच्च शिक्षा के लिए फ्रेंच", flag: "FR" },
  { id: "l6", language: "Pahari (पहाड़ी)", level: "All Levels", enrolled: 45000, description: "उत्तराखंड की स्थानीय गढ़वाली/कुमाऊंनी बोलियों का संरक्षण", flag: "IN" },
];

const translations: Record<string, string> = {
  "hello": "नमस्ते",
  "how are you": "आप कैसे हैं",
  "machine learning": "मशीन लर्निंग",
  "artificial intelligence": "कृत्रिम बुद्धिमत्ता",
  "blockchain": "ब्लॉकचेन",
  "democracy": "लोकतंत्र",
};

router.get("/language/courses", (_req, res) => {
  res.json({ courses: langCourses, total: langCourses.length });
});

router.post("/language/translate", (req, res) => {
  const { text, targetLanguage } = req.body as { text: string; targetLanguage: string };
  if (!text) { res.status(400).json({ error: "text is required" }); return; }
  const lower = text.toLowerCase();
  const translated = translations[lower] ?? `[${targetLanguage ?? "hindi"}] ${text} — अनुवाद प्रक्रिया में है`;
  res.json({ original: text, translated, targetLanguage: targetLanguage ?? "hindi", confidence: 0.92 });
});

export default router;
