import { Router } from "express";
const router = Router();

const COMMAND_MAP: Array<{ patterns: string[]; intent: string; action: string; navigateTo: string | null }> = [
  { patterns: ["वॉलेट", "wallet", "बैलेंस", "balance"], intent: "navigate_wallet", action: "Navigating to Wallet Hub", navigateTo: "/wallet" },
  { patterns: ["ट्रांसफर", "transfer", "भेजो", "send"], intent: "navigate_transfer", action: "Navigating to SAB Transfer", navigateTo: "/transfer" },
  { patterns: ["ब्लॉकचेन", "blockchain", "चेन", "chain"], intent: "navigate_blockchain", action: "Opening Blockchain Explorer", navigateTo: "/blockchain" },
  { patterns: ["अकादमी", "academy", "पढ़ाई", "upsc", "ias"], intent: "navigate_academy", action: "Opening IAS/IPS Academy", navigateTo: "/academy" },
  { patterns: ["भाषा", "language", "english", "अंग्रेजी"], intent: "navigate_language", action: "Opening Language Academy", navigateTo: "/language" },
  { patterns: ["हुनर", "skills", "सिलाई", "crafts"], intent: "navigate_skills", action: "Opening Skill Center", navigateTo: "/skills" },
  { patterns: ["सरकार", "gov", "प्रमाण", "certificate"], intent: "navigate_gov", action: "Opening Government Window", navigateTo: "/gov" },
  { patterns: ["किसान", "krishi", "खेती", "मंडी", "farming"], intent: "navigate_krishi", action: "Opening Krishi Mitra", navigateTo: "/krishi" },
  { patterns: ["सोशल", "social", "फीड", "feed", "रील"], intent: "navigate_social", action: "Opening Swadeshi Social Media", navigateTo: "/social" },
  { patterns: ["एक्सचेंज", "exchange", "ट्रेडिंग", "trading"], intent: "navigate_exchange", action: "Opening SAB Exchange", navigateTo: "/exchange" },
  { patterns: ["क्रिएटर", "creator", "reward", "इनाम"], intent: "navigate_creator", action: "Opening Creator Economy", navigateTo: "/creator" },
  { patterns: ["सुरक्षा", "security", "cyber", "साइबर"], intent: "navigate_security", action: "Opening Security Center", navigateTo: "/security" },
  { patterns: ["एडमिन", "admin", "मालिक", "kill"], intent: "navigate_admin", action: "Opening Admin Panel", navigateTo: "/admin" },
  { patterns: ["होम", "home", "dashboard", "डैशबोर्ड"], intent: "navigate_home", action: "Going to Dashboard", navigateTo: "/" },
  { patterns: ["फ्रीज", "freeze", "बंद"], intent: "system_freeze", action: "Please use the Admin Panel Kill-Switch for freeze command", navigateTo: "/admin" },
  { patterns: ["खुशी", "khushi", "ai", "help", "मदद"], intent: "ai_help", action: "Khushi AI is ready to assist! Tell me what you need.", navigateTo: null },
];

router.post("/voice/command", (req, res) => {
  const { command, language } = req.body as { command: string; language?: string };
  if (!command) { res.status(400).json({ error: "command is required" }); return; }

  const lower = command.toLowerCase();
  const matched = COMMAND_MAP.find(c => c.patterns.some(p => lower.includes(p)));

  if (matched) {
    res.json({
      command, intent: matched.intent, action: matched.action,
      result: `खुशी AI: "${command}" — ${matched.action}`,
      navigateTo: matched.navigateTo, confidence: 0.95,
    });
    return;
  }

  res.json({
    command, intent: "unknown",
    action: "Command noted — processing with Khushi AI",
    result: `खुशी AI समझ रही है: "${command}" — कृपया और स्पष्ट करें या दोबारा बोलें`,
    navigateTo: null, confidence: 0.45,
  });
});

export default router;
