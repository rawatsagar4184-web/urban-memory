import { Router, type IRouter } from "express";
import { getHealthReport, getBestNode } from "../core/failover.js";

const router: IRouter = Router();

router.get("/failover/status", (req, res) => {
  const report = getHealthReport();
  const best = getBestNode();
  req.log.info({ best: best?.id }, "Failover status requested");
  res.json({
    activeNode: best ? { id: best.id, url: best.url, priority: best.priority } : null,
    nodes: report,
    singleServerMode: report.length === 0,
    checkedAt: new Date().toISOString(),
  });
});

export default router;
