import { Router } from "express";
import {
  getThreatLog,
  getBlacklist,
  removeFromBlacklist,
  getStats,
  generateCERTReport,
  issueChallenge,
  verifyChallenge,
  CANARY_PATHS,
} from "../core/threatIntelligence.js";

const router = Router();

router.get("/security/threats", (_req, res) => {
  res.json({ threats: getThreatLog(), total: getThreatLog().length });
});

router.get("/security/threat-stats", (_req, res) => {
  res.json(getStats());
});

router.get("/security/blacklist", (_req, res) => {
  res.json({ ips: getBlacklist(), total: getBlacklist().length });
});

router.delete("/security/blacklist/:ip", (req, res) => {
  const ip = decodeURIComponent(req.params["ip"] ?? "");
  removeFromBlacklist(ip);
  res.json({ removed: ip, message: "IP blacklist से हटा दिया गया" });
});

router.get("/security/cert-report", (req, res) => {
  const { threatId } = req.query as { threatId?: string };
  const report = generateCERTReport(threatId);
  res.json(report);
});

// L10: Cryptographic challenge endpoints
router.get("/security/challenge/:ip", (req, res) => {
  const ip = decodeURIComponent(req.params["ip"] ?? "");
  res.json(issueChallenge(ip));
});

router.post("/security/challenge/:ip/verify", (req, res) => {
  const ip = decodeURIComponent(req.params["ip"] ?? "");
  const { answer } = req.body as { answer: string };
  const valid = verifyChallenge(ip, answer ?? "");
  res.json({ valid, ip });
});

// Canary paths — all return fake data but trigger L8 flag
for (const cp of CANARY_PATHS) {
  router.get(cp, (_req, res) => {
    res.status(200).json({ data: [], message: "No records found", status: "ok" });
  });
}

export default router;
