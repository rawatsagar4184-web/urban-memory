import { Router } from "express";
const router = Router();

const creators = [
  { rank: 1, name: "Sagar Bhai", sabEarned: 125000, posts: 234, followers: 85000, category: "देशभक्ति" },
  { rank: 2, name: "प्रिया रावत", sabEarned: 89000, posts: 456, followers: 42000, category: "हस्तशिल्प" },
  { rank: 3, name: "अमन जोशी", sabEarned: 67000, posts: 189, followers: 31000, category: "कृषि" },
  { rank: 4, name: "सुमन नेगी", sabEarned: 54000, posts: 320, followers: 28000, category: "शिक्षा" },
  { rank: 5, name: "राहुल बिष्ट", sabEarned: 43000, posts: 278, followers: 22000, category: "मनोरंजन" },
  { rank: 6, name: "अनिता पांडे", sabEarned: 38000, posts: 412, followers: 19000, category: "खाना-पकाना" },
  { rank: 7, name: "विक्रम सिंह", sabEarned: 29000, posts: 156, followers: 14000, category: "खेल" },
  { rank: 8, name: "मीनाक्षी देवी", sabEarned: 24000, posts: 234, followers: 11000, category: "हस्तशिल्प" },
  { rank: 9, name: "दीपक कुमार", sabEarned: 18000, posts: 89, followers: 9000, category: "तकनीक" },
  { rank: 10, name: "रेखा जोशी", sabEarned: 14000, posts: 178, followers: 7500, category: "स्वास्थ्य" },
];

router.get("/creator/leaderboard", (_req, res) => {
  const totalSAB = creators.reduce((s, c) => s + c.sabEarned, 0);
  res.json({ creators, totalSABDistributed: totalSAB, lastUpdated: new Date().toISOString() });
});

router.get("/creator/rewards", (_req, res) => {
  const totalSAB = creators.reduce((s, c) => s + c.sabEarned, 0);
  res.json({
    totalCreators: 12800,
    totalSABDistributed: totalSAB,
    averagePerCreator: parseFloat((totalSAB / creators.length).toFixed(0)),
    topCategory: "देशभक्ति",
    rewardRate: "10 SAB प्रति 100 views, 50 SAB प्रति like",
  });
});

export default router;
