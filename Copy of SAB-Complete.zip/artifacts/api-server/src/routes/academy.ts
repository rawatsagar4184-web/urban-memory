import { Router } from "express";
const router = Router();

const courses = [
  { id: "c1", title: "UPSC सामान्य अध्ययन - पेपर 1", category: "UPSC", description: "इतिहास, भूगोल, राजव्यवस्था की पूर्ण तैयारी", instructor: "Dr. Rajesh Sharma", duration: "120 घंटे", level: "intermediate", enrolled: 45230, isFree: true, thumbnailUrl: "" },
  { id: "c2", title: "IAS इंटरव्यू मास्टरक्लास", category: "IAS", description: "साक्षात्कार तकनीक और व्यक्तित्व विकास", instructor: "IAS Officer Priya Negi", duration: "40 घंटे", level: "advanced", enrolled: 12800, isFree: true, thumbnailUrl: "" },
  { id: "c3", title: "PCS प्रारंभिक परीक्षा - उत्तराखंड", category: "PCS", description: "उत्तराखंड राज्य सेवा परीक्षा की विशेष तैयारी", instructor: "Prof. Mohan Bisht", duration: "80 घंटे", level: "beginner", enrolled: 32100, isFree: true, thumbnailUrl: "" },
  { id: "c4", title: "IPS नैतिकता और अखंडता", category: "IPS", description: "पुलिस सेवा के लिए नैतिकता और केस स्टडी", instructor: "SP Kavita Rawat", duration: "60 घंटे", level: "intermediate", enrolled: 8900, isFree: true, thumbnailUrl: "" },
  { id: "c5", title: "CSAT गणित और तर्कशक्ति", category: "UPSC", description: "CSAT पेपर के लिए गणित और रिजनिंग", instructor: "Amit Joshi", duration: "50 घंटे", level: "beginner", enrolled: 67000, isFree: true, thumbnailUrl: "" },
  { id: "c6", title: "करंट अफेयर्स - हिंदी में", category: "UPSC", description: "रोज़ाना अपडेट होने वाली करंट अफेयर्स सीरीज़", instructor: "News Desk Team", duration: "365 घंटे", level: "beginner", enrolled: 125000, isFree: true, thumbnailUrl: "" },
];

const tests = [
  { id: "t1", title: "UPSC प्रारंभिक मॉक टेस्ट - 1", subject: "सामान्य अध्ययन", questions: 100, duration: "2 घंटे", attempts: 34500 },
  { id: "t2", title: "उत्तराखंड PCS मॉक - सेट A", subject: "राज्य विशेष", questions: 150, duration: "3 घंटे", attempts: 18200 },
  { id: "t3", title: "CSAT पूर्ण अभ्यास सेट", subject: "CSAT", questions: 80, duration: "2 घंटे", attempts: 28900 },
  { id: "t4", title: "IAS मुख्य परीक्षा - निबंध", subject: "निबंध", questions: 4, duration: "3 घंटे", attempts: 9800 },
];

router.get("/academy/courses", (req, res) => {
  const { category } = req.query;
  const result = category ? courses.filter(c => c.category === String(category)) : courses;
  res.json({ courses: result, total: result.length });
});

router.get("/academy/courses/:id", (req, res) => {
  const course = courses.find(c => c.id === req.params["id"]);
  if (!course) { res.status(404).json({ error: "Course not found" }); return; }
  res.json({
    ...course,
    lessons: [
      { id: "l1", title: "परिचय और पाठ्यक्रम", duration: "45 मिनट", type: "video" },
      { id: "l2", title: "अध्याय 1 - मूल अवधारणाएं", duration: "90 मिनट", type: "video" },
      { id: "l3", title: "अध्याय 1 - प्रश्न अभ्यास", duration: "30 मिनट", type: "quiz" },
      { id: "l4", title: "अध्याय 2 - विस्तृत विश्लेषण", duration: "75 मिनट", type: "video" },
      { id: "l5", title: "संदर्भ सामग्री", duration: "20 मिनट", type: "reading" },
    ],
  });
});

router.get("/academy/tests", (_req, res) => {
  res.json({ tests, total: tests.length });
});

router.get("/academy/stats", (_req, res) => {
  res.json({ totalStudents: 285000, totalCourses: courses.length, totalTests: tests.length, totalHours: 450, successRate: 78.4 });
});

export default router;
