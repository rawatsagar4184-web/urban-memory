import { Router, type IRouter } from "express";

interface MeshPacket {
  id: string; from: string; to: string;
  type: "msg" | "file" | "data";
  payload: string; hops: string[]; ts: number; synced: boolean;
}

function isValidPackets(body: unknown): body is { packets: MeshPacket[] } {
  if (typeof body !== "object" || body === null) return false;
  const b = body as Record<string, unknown>;
  return Array.isArray(b["packets"]) &&
    (b["packets"] as unknown[]).every(p =>
      typeof p === "object" && p !== null &&
      typeof (p as Record<string, unknown>)["id"] === "string"
    );
}

const router: IRouter = Router();

router.post("/mesh/sync", (req, res) => {
  if (!isValidPackets(req.body)) {
    res.status(400).json({ error: "Invalid mesh packets" });
    return;
  }
  const packets = req.body.packets;
  req.log.info({ count: packets.length }, "Mesh sync received");
  res.json({ synced: packets.map((p: MeshPacket) => p.id), ts: new Date().toISOString() });
});

router.get("/mesh/status", (req, res) => {
  req.log.info("Mesh status requested");
  res.json({ protocol: 13, name: "Offline Mesh Network", encryption: "AES-256-GCM", version: "1.0.0" });
});

export default router;
