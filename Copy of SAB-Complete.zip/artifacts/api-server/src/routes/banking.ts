import { Router } from "express";
import {
  createBankAccount,
  getAccount,
  getAllAccounts,
  deposit,
  withdraw,
  transfer,
  getStatement,
  getAllTransactions,
  getBankingStats,
  getFraudAlerts,
} from "../core/banking.js";
import {
  openFD,
  getFDsByAccount,
  closeFDRecord,
  getRateCard,
  openRD,
  getRDsByAccount,
  createSIRecord,
  getSIsByAccount,
  cancelSIRecord,
  type SIFrequency,
} from "../core/investment.js";

const router = Router();

router.post("/banking/account/create", (req, res) => {
  const { holderName, mobile, aadhaarNumber, accountType, sabWalletAddress } =
    req.body as {
      holderName: string;
      mobile: string;
      aadhaarNumber: string;
      accountType: "savings" | "current" | "Jan Dhan";
      sabWalletAddress?: string;
    };
  if (!holderName || !mobile || !aadhaarNumber || !accountType) {
    res.status(400).json({ error: "सभी आवश्यक जानकारी भरें" });
    return;
  }
  try {
    const account = createBankAccount({ holderName, mobile, aadhaarNumber, accountType, sabWalletAddress });
    res.status(201).json(account);
  } catch (e: unknown) {
    res.status(400).json({ error: e instanceof Error ? e.message : "Unknown error" });
  }
});

router.get("/banking/account/:accountNumber", (req, res) => {
  const acc = getAccount(req.params["accountNumber"] ?? "");
  if (!acc) { res.status(404).json({ error: "Account not found" }); return; }
  res.json(acc);
});

router.get("/banking/accounts", (_req, res) => {
  res.json({ accounts: getAllAccounts(), total: getAllAccounts().length });
});

router.post("/banking/deposit", (req, res) => {
  const { accountNumber, amount, description, mode } = req.body as {
    accountNumber: string; amount: number; description: string; mode?: "CASH" | "NEFT" | "IMPS" | "UPI";
  };
  if (!accountNumber || !amount || !description) {
    res.status(400).json({ error: "accountNumber, amount, description आवश्यक हैं" }); return;
  }
  try {
    const tx = deposit(accountNumber, Number(amount), description, mode ?? "CASH");
    res.json(tx);
  } catch (e: unknown) {
    res.status(400).json({ error: e instanceof Error ? e.message : "Unknown error" });
  }
});

router.post("/banking/withdraw", (req, res) => {
  const { accountNumber, amount, description, mode } = req.body as {
    accountNumber: string; amount: number; description: string; mode?: "ATM" | "CASH" | "UPI";
  };
  if (!accountNumber || !amount || !description) {
    res.status(400).json({ error: "accountNumber, amount, description आवश्यक हैं" }); return;
  }
  try {
    const tx = withdraw(accountNumber, Number(amount), description, mode ?? "ATM");
    res.json(tx);
  } catch (e: unknown) {
    res.status(400).json({ error: e instanceof Error ? e.message : "Unknown error" });
  }
});

router.post("/banking/transfer", (req, res) => {
  const { fromAccount, toAccount, amount, description, mode } = req.body as {
    fromAccount: string; toAccount: string; amount: number; description: string; mode?: "UPI" | "NEFT" | "IMPS";
  };
  if (!fromAccount || !toAccount || !amount || !description) {
    res.status(400).json({ error: "सभी ट्रांसफर विवरण आवश्यक हैं" }); return;
  }
  try {
    const result = transfer(fromAccount, toAccount, Number(amount), description, mode ?? "UPI");
    res.json(result);
  } catch (e: unknown) {
    res.status(400).json({ error: e instanceof Error ? e.message : "Unknown error" });
  }
});

router.get("/banking/statement/:accountNumber", (req, res) => {
  const limit = Math.min(Number(req.query["limit"]) || 20, 100);
  const statement = getStatement(req.params["accountNumber"] ?? "", limit);
  res.json({ accountNumber: req.params["accountNumber"], transactions: statement, total: statement.length });
});

router.get("/banking/transactions", (_req, res) => {
  const limit = Math.min(Number(_req.query["limit"]) || 50, 200);
  res.json({ transactions: getAllTransactions(limit), total: getAllTransactions(limit).length });
});

router.get("/banking/stats", (_req, res) => {
  res.json(getBankingStats());
});

router.get("/banking/fraud-alerts", (_req, res) => {
  res.json({ alerts: getFraudAlerts(), total: getFraudAlerts().length });
});

// ── FD Routes ────────────────────────────────────────────────────────────────
router.get("/banking/fd/rate-card", (_req, res) => {
  res.json(getRateCard());
});

router.post("/banking/fd/create", (req, res) => {
  const { accountNumber, principal, tenure, scBonus } = req.body as {
    accountNumber: string; principal: number; tenure: string; scBonus?: boolean;
  };
  if (!accountNumber || !principal || !tenure) {
    res.status(400).json({ error: "accountNumber, principal, tenure आवश्यक हैं" }); return;
  }
  try {
    const fd = openFD(accountNumber, Number(principal), tenure, scBonus ?? false);
    res.status(201).json(fd);
  } catch (e: unknown) {
    res.status(400).json({ error: e instanceof Error ? e.message : "Error" });
  }
});

router.get("/banking/fd/:accountNumber", (req, res) => {
  const fds = getFDsByAccount(req.params["accountNumber"] ?? "");
  res.json({ fds, total: fds.length });
});

router.post("/banking/fd/close/:fdId", (req, res) => {
  try {
    const fd = closeFDRecord(req.params["fdId"] ?? "");
    res.json(fd);
  } catch (e: unknown) {
    res.status(400).json({ error: e instanceof Error ? e.message : "Error" });
  }
});

// ── RD Routes ────────────────────────────────────────────────────────────────
router.post("/banking/rd/create", (req, res) => {
  const { accountNumber, monthlyAmount, tenureMonths } = req.body as {
    accountNumber: string; monthlyAmount: number; tenureMonths: number;
  };
  if (!accountNumber || !monthlyAmount || !tenureMonths) {
    res.status(400).json({ error: "accountNumber, monthlyAmount, tenureMonths आवश्यक हैं" }); return;
  }
  try {
    const rd = openRD(accountNumber, Number(monthlyAmount), Number(tenureMonths));
    res.status(201).json(rd);
  } catch (e: unknown) {
    res.status(400).json({ error: e instanceof Error ? e.message : "Error" });
  }
});

router.get("/banking/rd/:accountNumber", (req, res) => {
  const rds = getRDsByAccount(req.params["accountNumber"] ?? "");
  res.json({ rds, total: rds.length });
});

// ── SI Routes ────────────────────────────────────────────────────────────────
router.post("/banking/si/create", (req, res) => {
  const { accountNumber, toAccount, amount, description, frequency } = req.body as {
    accountNumber: string; toAccount: string; amount: number;
    description: string; frequency: SIFrequency;
  };
  if (!accountNumber || !toAccount || !amount || !description || !frequency) {
    res.status(400).json({ error: "सभी SI विवरण आवश्यक हैं" }); return;
  }
  try {
    const si = createSIRecord(accountNumber, toAccount, Number(amount), description, frequency);
    res.status(201).json(si);
  } catch (e: unknown) {
    res.status(400).json({ error: e instanceof Error ? e.message : "Error" });
  }
});

router.get("/banking/si/:accountNumber", (req, res) => {
  const sis = getSIsByAccount(req.params["accountNumber"] ?? "");
  res.json({ sis, total: sis.length });
});

router.post("/banking/si/cancel/:siId", (req, res) => {
  try {
    const si = cancelSIRecord(req.params["siId"] ?? "");
    res.json(si);
  } catch (e: unknown) {
    res.status(400).json({ error: e instanceof Error ? e.message : "Error" });
  }
});

export default router;
