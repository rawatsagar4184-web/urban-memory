import { Router } from "express";
import { blockchain, TRANSACTION_FEE_PERCENT } from "../core/blockchain.js";
import { walletStore } from "../core/wallet.js";

const router = Router();

router.post("/wallet/create", (req, res) => {
  if (blockchain.isFrozen) {
    res.status(503).json({ error: "System is frozen by owner", code: "FROZEN" });
    return;
  }
  const { ownerName, initialBalance } = req.body as {
    ownerName?: string;
    initialBalance?: number;
  };
  if (!ownerName || typeof ownerName !== "string") {
    res.status(400).json({ error: "ownerName is required" });
    return;
  }
  const wallet = walletStore.create(ownerName.trim(), initialBalance ?? 1000);
  res.status(201).json({
    address: wallet.address,
    privateKey: wallet.privateKey,
    ownerName: wallet.ownerName,
    balance: wallet.balance,
    balanceINR: walletStore.toINR(wallet.balance),
    createdAt: wallet.createdAt,
  });
});

router.get("/wallet/:address", (req, res) => {
  const { address } = req.params;
  const wallet = walletStore.get(address);
  if (!wallet) {
    res.status(404).json({ error: "Wallet not found" });
    return;
  }
  res.json({
    address: wallet.address,
    ownerName: wallet.ownerName,
    balance: wallet.balance,
    balanceINR: walletStore.toINR(wallet.balance),
    transactionCount: wallet.transactionCount,
    createdAt: wallet.createdAt,
  });
});

router.post("/wallet/transfer", (req, res) => {
  if (blockchain.isFrozen) {
    res.status(503).json({ error: "System is frozen by owner", code: "FROZEN" });
    return;
  }
  const { fromAddress, toAddress, amount, privateKey } = req.body as {
    fromAddress?: string;
    toAddress?: string;
    amount?: number;
    privateKey?: string;
  };
  if (!fromAddress || !toAddress || !amount || !privateKey) {
    res.status(400).json({ error: "fromAddress, toAddress, amount, privateKey are required" });
    return;
  }
  if (amount <= 0) {
    res.status(400).json({ error: "Amount must be positive" });
    return;
  }
  if (!walletStore.verifyKey(fromAddress, privateKey)) {
    res.status(403).json({ error: "Invalid private key" });
    return;
  }
  if (!walletStore.get(toAddress)) {
    res.status(404).json({ error: "Destination wallet not found" });
    return;
  }
  const fee = parseFloat((amount * TRANSACTION_FEE_PERCENT).toFixed(2));
  const total = amount + fee;
  const debited = walletStore.debit(fromAddress, total);
  if (!debited) {
    res.status(400).json({ error: "Insufficient SAB balance" });
    return;
  }
  walletStore.credit(toAddress, amount);
  const tx = blockchain.addTransaction({
    fromAddress,
    toAddress,
    amount,
    fee,
    timestamp: new Date().toISOString(),
    type: "transfer",
  });
  const block = blockchain.minePendingTransactions();
  res.json({
    transactionId: tx.id,
    blockIndex: block.index,
    fromAddress,
    toAddress,
    amount,
    fee,
    timestamp: tx.timestamp,
    status: "confirmed",
  });
});

export default router;
