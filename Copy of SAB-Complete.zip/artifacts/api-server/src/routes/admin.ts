import { Router } from "express";
import { blockchain } from "../core/blockchain.js";
import { walletStore } from "../core/wallet.js";
import { sab_ping, sab_getLiveStats } from "../core/liveUsers.js";

const OWNER_MASTER_KEY = process.env["OWNER_MASTER_KEY"] ?? "SAGAR_BHAI_MASTER_KEY_SAB_2024";

const router = Router();

router.get("/admin/status", (_req, res) => {
  res.json({
    systemName: "सबसे आगे भारत",
    owner: "Sagar Bhai",
    isFrozen: blockchain.isFrozen,
    uptime: process.uptime(),
    totalWallets: walletStore.totalWallets(),
    totalBlocks: blockchain.chain.length,
    version: "1.0.0-dev",
    mode: "development",
  });
});

/* Live user count — owner only */
router.get("/admin/live", (_req, res) => {
  res.json(sab_getLiveStats());
});

/* Client heartbeat — called by every public user every 60s */
router.post("/admin/ping", (req, res) => {
  const { sessionId, page } = req.body as { sessionId?: string; page?: string };
  if (!sessionId || typeof sessionId !== "string" || sessionId.length > 64) {
    res.status(400).json({ error: "invalid sessionId" });
    return;
  }
  sab_ping(sessionId, page ?? "/");
  res.json({ ok: true });
});

router.post("/admin/kill-switch", (req, res) => {
  const { action, ownerKey } = req.body as {
    action?: string;
    ownerKey?: string;
  };
  if (!ownerKey || ownerKey !== OWNER_MASTER_KEY) {
    res.status(403).json({ error: "Unauthorized. Owner key required." });
    return;
  }
  if (!action || !["freeze", "unfreeze", "backup"].includes(action)) {
    res.status(400).json({ error: "action must be freeze | unfreeze | backup" });
    return;
  }
  let message = "";
  if (action === "freeze") {
    blockchain.isFrozen = true;
    message = "System FROZEN. All transactions halted. Owner has full control.";
  } else if (action === "unfreeze") {
    blockchain.isFrozen = false;
    message = "System UNFROZEN. Normal operation resumed.";
  } else if (action === "backup") {
    message = `Backup initiated. Chain length: ${blockchain.chain.length} blocks. Wallets: ${walletStore.totalWallets()}`;
  }
  res.json({
    action,
    status: blockchain.isFrozen ? "frozen" : "active",
    message,
    timestamp: new Date().toISOString(),
  });
});

export default router;
