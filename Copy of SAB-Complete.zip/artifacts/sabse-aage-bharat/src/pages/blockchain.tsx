import { useGetChain, getGetChainQueryKey } from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { CopyableHash } from "@/components/copyable-hash";
import { format } from "date-fns";
import { Boxes, Hash, Clock, ShieldCheck, ChevronDown, CheckCircle2 } from "lucide-react";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { Button } from "@/components/ui/button";

export function BlockchainExplorer() {
  const { data, isLoading, error } = useGetChain({
    query: { queryKey: getGetChainQueryKey(), refetchInterval: 10000 }
  });

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <h2 className="text-3xl font-bold tracking-tight text-foreground">Blockchain Explorer</h2>
          <p className="text-muted-foreground mt-2">Transparent, immutable, and indigenous ledger.</p>
        </div>
        {data && (
          <div className="flex items-center gap-2 bg-success/10 text-success border border-success/20 px-4 py-2 rounded-full font-medium" data-testid="badge-chain-validity">
            <ShieldCheck className="w-5 h-5" />
            Chain Validity: {data.isValid ? "VERIFIED SECURE" : "COMPROMISED"}
          </div>
        )}
      </div>

      {isLoading ? (
        <div className="space-y-4">
          {[1, 2, 3].map(i => (
            <Card key={i} className="animate-pulse">
              <CardHeader className="h-16 bg-muted/50" />
            </Card>
          ))}
        </div>
      ) : error ? (
        <Card className="bg-destructive/10 border-destructive">
          <CardContent className="p-6 text-center text-destructive font-bold">
            Failed to load blockchain data.
          </CardContent>
        </Card>
      ) : data?.chain.map((block) => (
        <Collapsible key={block.index} className="w-full" defaultOpen={block.index === data.chain.length - 1}>
          <Card className="border-l-4 border-l-primary overflow-hidden">
            <CollapsibleTrigger asChild>
              <CardHeader className="bg-muted/30 cursor-pointer hover:bg-muted/50 transition-colors flex flex-row items-center justify-between p-4" data-testid={`block-trigger-${block.index}`}>
                <div className="flex items-center gap-4">
                  <div className="bg-primary text-primary-foreground w-12 h-12 rounded-lg flex items-center justify-center font-bold text-lg shadow-inner">
                    #{block.index}
                  </div>
                  <div>
                    <CardTitle className="text-lg flex items-center gap-2">
                      Block {block.index === 0 && <Badge variant="secondary">GENESIS</Badge>}
                    </CardTitle>
                    <p className="text-sm text-muted-foreground flex items-center gap-1 mt-1">
                      <Clock className="w-3 h-3" />
                      {format(new Date(block.timestamp), "PP pp")}
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-6">
                  <div className="hidden md:block text-right">
                    <p className="text-xs font-bold text-muted-foreground uppercase tracking-wider mb-1">Transactions</p>
                    <Badge variant="outline" className="font-mono text-sm">{block.transactions.length}</Badge>
                  </div>
                  <Button variant="ghost" size="icon">
                    <ChevronDown className="w-5 h-5" />
                  </Button>
                </div>
              </CardHeader>
            </CollapsibleTrigger>
            
            <CollapsibleContent>
              <CardContent className="p-0">
                <div className="bg-slate-50 dark:bg-slate-900 p-4 border-y grid grid-cols-1 md:grid-cols-2 gap-4 text-sm font-mono">
                  <div>
                    <span className="text-muted-foreground block text-xs mb-1">Block Hash</span>
                    <CopyableHash hash={block.hash} />
                  </div>
                  <div>
                    <span className="text-muted-foreground block text-xs mb-1">Previous Hash</span>
                    {block.index === 0 ? (
                      <span className="text-muted-foreground">0000000000000000000000000000000000000000000000000000000000000000</span>
                    ) : (
                      <CopyableHash hash={block.previousHash} />
                    )}
                  </div>
                  <div>
                    <span className="text-muted-foreground block text-xs mb-1">Nonce</span>
                    <span>{block.nonce}</span>
                  </div>
                </div>

                <div className="p-4">
                  <h4 className="font-bold mb-3 flex items-center gap-2 text-sm uppercase text-muted-foreground tracking-wider">
                    <Boxes className="w-4 h-4" />
                    Block Transactions
                  </h4>
                  {block.transactions.length === 0 ? (
                    <p className="text-sm text-muted-foreground italic">No transactions in this block.</p>
                  ) : (
                    <div className="space-y-2">
                      {block.transactions.map((tx) => (
                        <div key={tx.id} className="bg-background border rounded-lg p-3 text-sm flex flex-col md:flex-row md:items-center justify-between gap-3">
                          <div className="flex items-center gap-3">
                            <Badge variant={tx.type === "genesis" ? "secondary" : tx.type === "reward" ? "default" : "outline"}>
                              {tx.type.toUpperCase()}
                            </Badge>
                            <CopyableHash hash={tx.id} />
                          </div>
                          <div className="flex items-center gap-2 md:gap-4 font-mono">
                            <div className="flex flex-col md:items-end">
                              <span className="text-xs text-muted-foreground">Amount</span>
                              <span className="font-bold text-foreground">{tx.amount} SAB</span>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </CardContent>
            </CollapsibleContent>
          </Card>
        </Collapsible>
      ))}
    </div>
  );
}
