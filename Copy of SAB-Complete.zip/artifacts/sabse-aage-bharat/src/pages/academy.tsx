import { useGetAcademyCourses, useGetAcademyTests, useGetAcademyStats } from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { GraduationCap, Users, Clock, Target, FileText } from "lucide-react";

export function Academy() {
  const { data: courses, isLoading: loadingCourses } = useGetAcademyCourses();
  const { data: tests, isLoading: loadingTests } = useGetAcademyTests();
  const { data: stats, isLoading: loadingStats } = useGetAcademyStats();

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3">
        <GraduationCap className="w-10 h-10 text-primary" />
        <div>
          <h1 className="text-3xl font-bold tracking-tight text-primary">IAS/IPS Academy LMS</h1>
          <p className="text-muted-foreground mt-1">Free civil services preparation for the youth of Bharat / भारत के युवाओं के लिए मुफ्त सिविल सेवा तैयारी</p>
        </div>
      </div>

      {loadingStats ? (
        <Skeleton className="h-32 w-full" data-testid="skeleton-academy-stats" />
      ) : stats && (
        <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
          <Card className="border-primary/20 bg-primary/5">
            <CardContent className="pt-6 text-center">
              <Users className="w-6 h-6 mx-auto mb-2 text-primary" />
              <div className="text-2xl font-bold" data-testid="text-total-students">{stats.totalStudents.toLocaleString()}</div>
              <p className="text-xs text-muted-foreground">Total Students</p>
            </CardContent>
          </Card>
          <Card className="border-primary/20 bg-primary/5">
            <CardContent className="pt-6 text-center">
              <GraduationCap className="w-6 h-6 mx-auto mb-2 text-primary" />
              <div className="text-2xl font-bold" data-testid="text-total-courses">{stats.totalCourses}</div>
              <p className="text-xs text-muted-foreground">Courses</p>
            </CardContent>
          </Card>
          <Card className="border-primary/20 bg-primary/5">
            <CardContent className="pt-6 text-center">
              <FileText className="w-6 h-6 mx-auto mb-2 text-primary" />
              <div className="text-2xl font-bold" data-testid="text-total-tests">{stats.totalTests}</div>
              <p className="text-xs text-muted-foreground">Mock Tests</p>
            </CardContent>
          </Card>
          <Card className="border-primary/20 bg-primary/5">
            <CardContent className="pt-6 text-center">
              <Clock className="w-6 h-6 mx-auto mb-2 text-primary" />
              <div className="text-2xl font-bold" data-testid="text-total-hours">{stats.totalHours.toLocaleString()}h</div>
              <p className="text-xs text-muted-foreground">Learning Hours</p>
            </CardContent>
          </Card>
          <Card className="border-primary/20 bg-primary/5">
            <CardContent className="pt-6 text-center">
              <Target className="w-6 h-6 mx-auto mb-2 text-primary" />
              <div className="text-2xl font-bold text-success" data-testid="text-success-rate">{stats.successRate}%</div>
              <p className="text-xs text-muted-foreground">Success Rate</p>
            </CardContent>
          </Card>
        </div>
      )}

      <Tabs defaultValue="courses" className="w-full">
        <TabsList className="grid w-full md:w-[400px] grid-cols-2">
          <TabsTrigger value="courses" data-testid="tab-courses">Courses / पाठ्यक्रम</TabsTrigger>
          <TabsTrigger value="tests" data-testid="tab-tests">Mock Tests / मॉक टेस्ट</TabsTrigger>
        </TabsList>
        
        <TabsContent value="courses" className="mt-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {loadingCourses ? (
              Array.from({ length: 6 }).map((_, i) => <Skeleton key={i} className="h-48 w-full" data-testid={`skeleton-course-${i}`} />)
            ) : courses?.courses.map((course) => (
              <Card key={course.id} className="flex flex-col hover:border-primary/50 transition-colors" data-testid={`card-course-${course.id}`}>
                <CardHeader>
                  <div className="flex justify-between items-start mb-2">
                    <Badge variant="secondary" data-testid={`badge-category-${course.id}`}>{course.category}</Badge>
                    {course.isFree && <Badge className="bg-success text-white" data-testid={`badge-free-${course.id}`}>Free / मुफ्त</Badge>}
                  </div>
                  <CardTitle className="text-lg">{course.title}</CardTitle>
                  <CardDescription>Instructor: {course.instructor}</CardDescription>
                </CardHeader>
                <CardContent className="mt-auto flex flex-col gap-4">
                  <div className="flex justify-between items-center text-sm text-muted-foreground">
                    <span className="flex items-center gap-1"><Clock className="w-4 h-4"/> {course.duration}</span>
                    <span className="flex items-center gap-1"><Users className="w-4 h-4"/> {course.enrolled.toLocaleString()}</span>
                  </div>
                  <Button className="w-full" data-testid={`button-enroll-${course.id}`}>Enroll Now / अभी नामांकन करें</Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="tests" className="mt-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {loadingTests ? (
              Array.from({ length: 3 }).map((_, i) => <Skeleton key={i} className="h-48 w-full" data-testid={`skeleton-test-${i}`} />)
            ) : tests?.tests.map((test) => (
              <Card key={test.id} className="flex flex-col border-secondary/20" data-testid={`card-test-${test.id}`}>
                <CardHeader>
                  <Badge variant="outline" className="w-fit mb-2">{test.subject}</Badge>
                  <CardTitle>{test.title}</CardTitle>
                </CardHeader>
                <CardContent className="mt-auto flex flex-col gap-4 pt-4">
                  <div className="grid grid-cols-2 gap-2 text-sm text-muted-foreground bg-muted/30 p-3 rounded-md">
                    <div>Questions: <span className="font-bold text-foreground">{test.questions}</span></div>
                    <div>Duration: <span className="font-bold text-foreground">{test.duration}</span></div>
                    <div className="col-span-2">Attempts: <span className="font-bold text-foreground">{test.attempts.toLocaleString()}</span></div>
                  </div>
                  <Button variant="secondary" className="w-full" data-testid={`button-start-test-${test.id}`}>Start Test / टेस्ट शुरू करें</Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
