import { useGetGovServices, useGetGovApplications, useApplyGovService } from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { Landmark, FileText, CheckCircle2, Clock } from "lucide-react";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { useState } from "react";
import { useQueryClient } from "@tanstack/react-query";

const applicationSchema = z.object({
  serviceId: z.string(),
  applicantName: z.string().min(2, "Name is required"),
  aadhaarNumber: z.string().length(12, "Aadhaar must be exactly 12 digits").regex(/^\d+$/, "Must contain only numbers"),
  mobileNumber: z.string().length(10, "Mobile must be exactly 10 digits").regex(/^\d+$/, "Must contain only numbers"),
  address: z.string().min(10, "Full address is required"),
});

export function Gov() {
  const { data: services, isLoading: loadingServices } = useGetGovServices();
  const { data: applications, isLoading: loadingApps } = useGetGovApplications();
  const applyMutation = useApplyGovService();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [selectedService, setSelectedService] = useState<string | null>(null);
  const [isDialogOpen, setIsDialogOpen] = useState(false);

  const form = useForm<z.infer<typeof applicationSchema>>({
    resolver: zodResolver(applicationSchema),
    defaultValues: {
      serviceId: "",
      applicantName: "",
      aadhaarNumber: "",
      mobileNumber: "",
      address: "",
    },
  });

  const handleOpenDialog = (serviceId: string) => {
    setSelectedService(serviceId);
    form.reset({ serviceId, applicantName: "", aadhaarNumber: "", mobileNumber: "", address: "" });
    setIsDialogOpen(true);
  };

  const onSubmit = (values: z.infer<typeof applicationSchema>) => {
    applyMutation.mutate({ data: values }, {
      onSuccess: (data) => {
        toast({
          title: "Application Submitted Successfully",
          description: `Application ID: ${data.applicationId}`,
        });
        setIsDialogOpen(false);
        // Assuming we invalidate queries here
        queryClient.invalidateQueries({ queryKey: ["/api/gov/applications"] });
      },
      onError: () => {
        toast({
          variant: "destructive",
          title: "Submission Failed",
          description: "Please check your details and try again.",
        });
      }
    });
  };

  return (
    <div className="space-y-8">
      <div className="flex items-center gap-3">
        <Landmark className="w-10 h-10 text-primary" />
        <div>
          <h1 className="text-3xl font-bold tracking-tight text-primary">Digital Sarkar Khidki</h1>
          <p className="text-muted-foreground mt-1">Apply for government services directly from your home. / घर बैठे सरकारी सेवाओं के लिए आवेदन करें।</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-6">
          <h2 className="text-xl font-semibold flex items-center gap-2">
            <FileText className="w-5 h-5 text-secondary" />
            Available Services / उपलब्ध सेवाएं
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {loadingServices ? (
              Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-48 w-full" data-testid={`skeleton-service-${i}`} />)
            ) : services?.services.map((service) => (
              <Card key={service.id} className="flex flex-col" data-testid={`card-service-${service.id}`}>
                <CardHeader>
                  <div className="flex justify-between items-start mb-2">
                    <Badge variant="outline">{service.department}</Badge>
                    {service.isOnline && <Badge className="bg-success text-white">100% Online</Badge>}
                  </div>
                  <CardTitle className="text-lg leading-tight">{service.name}</CardTitle>
                </CardHeader>
                <CardContent className="flex-1">
                  <p className="text-sm text-muted-foreground line-clamp-3">{service.description}</p>
                  <div className="mt-4 flex items-center gap-2 text-xs font-medium text-primary">
                    <Clock className="w-4 h-4" />
                    Processing: {service.processingDays} Days
                  </div>
                </CardContent>
                <CardFooter>
                  <Button 
                    className="w-full" 
                    onClick={() => handleOpenDialog(service.id)}
                    data-testid={`button-apply-${service.id}`}
                  >
                    Apply Now / आवेदन करें
                  </Button>
                </CardFooter>
              </Card>
            ))}
          </div>
        </div>

        <div>
          <h2 className="text-xl font-semibold mb-6">My Applications / मेरे आवेदन</h2>
          <div className="space-y-4">
            {loadingApps ? (
              Array.from({ length: 3 }).map((_, i) => <Skeleton key={i} className="h-32 w-full" data-testid={`skeleton-app-${i}`} />)
            ) : applications?.applications.length === 0 ? (
              <Card className="bg-muted/50 border-dashed">
                <CardContent className="p-8 text-center text-muted-foreground">
                  No applications found.
                </CardContent>
              </Card>
            ) : applications?.applications.map((app) => (
              <Card key={app.applicationId} className="border-l-4 border-l-primary" data-testid={`card-app-${app.applicationId}`}>
                <CardContent className="p-4">
                  <div className="flex justify-between items-start mb-3">
                    <h3 className="font-semibold text-sm leading-tight pr-2">{app.serviceName}</h3>
                    <Badge 
                      variant={app.status === 'approved' ? 'default' : app.status === 'rejected' ? 'destructive' : 'secondary'} 
                      className={app.status === 'approved' ? 'bg-success' : ''}
                      data-testid={`badge-status-${app.applicationId}`}
                    >
                      {app.status.toUpperCase()}
                    </Badge>
                  </div>
                  <div className="space-y-1 text-xs text-muted-foreground">
                    <p>Applicant: <span className="font-medium text-foreground">{app.applicantName}</span></p>
                    <p>ID: {app.applicationId}</p>
                    <p>Submitted: {new Date(app.submittedAt).toLocaleDateString()}</p>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>

      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>Service Application / सेवा आवेदन</DialogTitle>
            <DialogDescription>
              Please provide accurate details. Aadhaar verification will be performed automatically.
            </DialogDescription>
          </DialogHeader>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4 pt-4">
              <FormField
                control={form.control}
                name="applicantName"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Full Name / पूरा नाम</FormLabel>
                    <FormControl>
                      <Input placeholder="As per Aadhaar" {...field} data-testid="input-gov-name" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="aadhaarNumber"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Aadhaar Number / आधार नंबर</FormLabel>
                      <FormControl>
                        <Input placeholder="12 digit number" {...field} maxLength={12} data-testid="input-gov-aadhaar" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="mobileNumber"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Mobile Number / मोबाइल नंबर</FormLabel>
                      <FormControl>
                        <Input placeholder="10 digit number" {...field} maxLength={10} data-testid="input-gov-mobile" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <FormField
                control={form.control}
                name="address"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Full Address / पूरा पता</FormLabel>
                    <FormControl>
                      <Textarea placeholder="Current residential address" {...field} data-testid="input-gov-address" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <div className="bg-blue-50 dark:bg-blue-900/20 p-3 rounded-md text-xs text-blue-800 dark:text-blue-300 flex gap-2 mt-2">
                <CheckCircle2 className="w-4 h-4 shrink-0 mt-0.5" />
                <p>I hereby declare that all information provided is true to my knowledge and I consent to Aadhaar authentication.</p>
              </div>

              <Button type="submit" className="w-full mt-4" disabled={applyMutation.isPending} data-testid="button-gov-submit">
                Submit Application / आवेदन जमा करें
              </Button>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
