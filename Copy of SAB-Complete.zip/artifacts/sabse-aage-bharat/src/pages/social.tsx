import { useGetSocialFeed, useGetSocialStats, useCreateSocialPost } from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import { Form, FormControl, FormField, FormItem, FormMessage } from "@/components/ui/form";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { Heart, MessageCircle, ShieldCheck, Users, Image as ImageIcon, Video, Send } from "lucide-react";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { useQueryClient } from "@tanstack/react-query";

const postSchema = z.object({
  content: z.string().min(5, "Post must be at least 5 characters long").max(500, "Post too long"),
});

export function Social() {
  const { data: feed, isLoading: loadingFeed } = useGetSocialFeed();
  const { data: stats, isLoading: loadingStats } = useGetSocialStats();
  const createPostMutation = useCreateSocialPost();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const form = useForm<z.infer<typeof postSchema>>({
    resolver: zodResolver(postSchema),
    defaultValues: {
      content: "",
    },
  });

  const onSubmit = (values: z.infer<typeof postSchema>) => {
    createPostMutation.mutate({ 
      data: { 
        content: values.content,
        authorName: "Current User", // Mocked user
        type: "text"
      } 
    }, {
      onSuccess: () => {
        toast({ title: "Post Published", description: "Your post is live on Swadeshi Social." });
        form.reset();
        queryClient.invalidateQueries({ queryKey: ["/api/social/feed"] });
      }
    });
  };

  return (
    <div className="space-y-6 max-w-2xl mx-auto">
      <div className="text-center mb-8">
        <div className="bg-primary w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-lg rotate-3">
          <Users className="w-8 h-8 text-white -rotate-3" />
        </div>
        <h1 className="text-3xl font-bold tracking-tight text-primary">Swadeshi Social</h1>
        <p className="text-muted-foreground mt-2">A safe, family-friendly space for Bharat. Create value, earn SAB.</p>
      </div>

      {loadingStats ? (
        <Skeleton className="h-24 w-full" data-testid="skeleton-social-stats" />
      ) : stats && (
        <div className="grid grid-cols-3 gap-4 mb-8">
          <Card className="bg-primary/5 text-center py-4 border-primary/20 shadow-none">
            <div className="text-2xl font-bold text-primary" data-testid="stat-active">{stats.activeToday.toLocaleString()}</div>
            <div className="text-[10px] font-bold text-muted-foreground uppercase tracking-wider">Active Today</div>
          </Card>
          <Card className="bg-secondary/5 text-center py-4 border-secondary/20 shadow-none">
            <div className="text-2xl font-bold text-secondary" data-testid="stat-posts">{stats.totalPosts.toLocaleString()}</div>
            <div className="text-[10px] font-bold text-muted-foreground uppercase tracking-wider">Total Posts</div>
          </Card>
          <Card className="bg-success/5 text-center py-4 border-success/20 shadow-none">
            <div className="text-2xl font-bold text-success" data-testid="stat-rewards">{stats.totalSABDistributed.toLocaleString()}</div>
            <div className="text-[10px] font-bold text-muted-foreground uppercase tracking-wider">SAB Rewarded</div>
          </Card>
        </div>
      )}

      {/* Create Post */}
      <Card className="border-2 shadow-sm">
        <CardContent className="p-4">
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <div className="flex gap-3">
                <div className="w-10 h-10 rounded-full bg-secondary text-secondary-foreground flex items-center justify-center font-bold shrink-0">
                  CU
                </div>
                <div className="flex-1">
                  <FormField
                    control={form.control}
                    name="content"
                    render={({ field }) => (
                      <FormItem>
                        <FormControl>
                          <Textarea 
                            placeholder="What's happening in Bharat? / भारत में क्या हो रहा है?" 
                            className="resize-none bg-muted/50 border-transparent focus-visible:bg-background min-h-[100px] text-base"
                            {...field} 
                            data-testid="input-post-content"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
              </div>
              <div className="flex justify-between items-center pt-2 border-t">
                <div className="flex gap-2">
                  <Button type="button" variant="ghost" size="sm" className="text-muted-foreground hover:text-primary">
                    <ImageIcon className="w-4 h-4 mr-2" /> Photo
                  </Button>
                  <Button type="button" variant="ghost" size="sm" className="text-muted-foreground hover:text-primary">
                    <Video className="w-4 h-4 mr-2" /> Reel
                  </Button>
                </div>
                <Button type="submit" disabled={createPostMutation.isPending} data-testid="button-post-submit">
                  {createPostMutation.isPending ? "Posting..." : <><Send className="w-4 h-4 mr-2"/> Post</>}
                </Button>
              </div>
            </form>
          </Form>
        </CardContent>
      </Card>

      {/* Feed */}
      <div className="space-y-6 mt-8">
        {loadingFeed ? (
          Array.from({ length: 3 }).map((_, i) => <Skeleton key={i} className="h-48 w-full" data-testid={`skeleton-post-${i}`} />)
        ) : feed?.posts.map((post) => (
          <Card key={post.id} className="overflow-hidden" data-testid={`card-post-${post.id}`}>
            <CardHeader className="pb-3 bg-muted/20">
              <div className="flex justify-between items-center">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-primary text-primary-foreground flex items-center justify-center font-bold shadow-sm">
                    {post.authorName.charAt(0)}
                  </div>
                  <div>
                    <h3 className="font-bold text-sm leading-none">{post.authorName}</h3>
                    <p className="text-xs text-muted-foreground mt-1">{new Date(post.createdAt).toLocaleString(undefined, { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit'})}</p>
                  </div>
                </div>
                {post.isModerated && (
                  <Badge variant="outline" className="text-success border-success bg-success/10 flex items-center gap-1 shadow-sm px-2 py-0.5">
                    <ShieldCheck className="w-3 h-3" /> Safe
                  </Badge>
                )}
              </div>
            </CardHeader>
            <CardContent className="pt-4 pb-2 text-[15px] leading-relaxed">
              <p>{post.content}</p>
              
              {post.type === 'photo' && (
                <div className="w-full h-48 bg-muted rounded-md mt-4 flex items-center justify-center text-muted-foreground">
                  <ImageIcon className="w-8 h-8 opacity-50" />
                </div>
              )}
              {post.type === 'reel' && (
                <div className="w-full h-64 bg-muted rounded-md mt-4 flex items-center justify-center text-muted-foreground">
                  <Video className="w-8 h-8 opacity-50" />
                </div>
              )}
            </CardContent>
            <CardFooter className="flex justify-between items-center pt-2 border-t bg-muted/10 px-4 py-3">
              <div className="flex gap-1">
                <Button variant="ghost" size="sm" className="flex items-center gap-1.5 h-8 text-muted-foreground hover:text-primary rounded-full px-3">
                  <Heart className="w-4 h-4" /> <span className="text-xs font-medium">{post.likes}</span>
                </Button>
                <Button variant="ghost" size="sm" className="flex items-center gap-1.5 h-8 text-muted-foreground hover:text-primary rounded-full px-3">
                  <MessageCircle className="w-4 h-4" /> <span className="text-xs font-medium">{post.comments}</span>
                </Button>
              </div>
              {post.sabReward > 0 && (
                <div className="bg-secondary/10 text-secondary-foreground text-xs font-bold px-3 py-1.5 rounded-full flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-secondary animate-pulse"></span>
                  +{post.sabReward} SAB Earned
                </div>
              )}
            </CardFooter>
          </Card>
        ))}
      </div>
    </div>
  );
}
