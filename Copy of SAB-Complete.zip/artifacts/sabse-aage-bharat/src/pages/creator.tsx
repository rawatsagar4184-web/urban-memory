import { useGetCreatorLeaderboard, useGetCreatorRewards } from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Trophy, Medal, Star, Target, Zap, TrendingUp } from "lucide-react";

export function Creator() {
  const { data: leaderboard, isLoading: loadingBoard } = useGetCreatorLeaderboard();
  const { data: rewards, isLoading: loadingRewards } = useGetCreatorRewards();

  return (
    <div className="space-y-8">
      <div className="flex items-center gap-3">
        <Trophy className="w-10 h-10 text-secondary" />
        <div>
          <h1 className="text-3xl font-bold tracking-tight text-primary">Creator Economy</h1>
          <p className="text-muted-foreground mt-1">Earn SAB for creating value for Bharat. Sovereign rewards for sovereign content.</p>
        </div>
      </div>

      {loadingRewards ? (
        <Skeleton className="h-32 w-full" data-testid="skeleton-creator-rewards" />
      ) : rewards && (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <Card className="bg-primary text-primary-foreground border-none shadow-md overflow-hidden relative">
            <div className="absolute -right-4 -bottom-4 opacity-10">
              <Trophy className="w-24 h-24" />
            </div>
            <CardContent className="pt-6 relative z-10">
              <p className="text-xs font-bold uppercase tracking-wider mb-1 opacity-80">Total SAB Awarded</p>
              <div className="text-3xl font-black mb-1">{rewards.totalSABDistributed.toLocaleString()}</div>
              <p className="text-xs opacity-90">To all creators globally</p>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="pt-6 flex flex-col justify-between h-full">
              <div>
                <p className="text-xs text-muted-foreground font-bold uppercase tracking-wider mb-1">Active Creators</p>
                <div className="text-2xl font-bold text-primary flex items-center gap-2">
                  <UsersIcon className="w-5 h-5 text-muted-foreground" />
                  {rewards.totalCreators.toLocaleString()}
                </div>
              </div>
              <p className="text-xs text-muted-foreground mt-2 border-t pt-2 flex items-center gap-1"><TrendingUp className="w-3 h-3 text-success"/> Growing daily</p>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="pt-6 flex flex-col justify-between h-full">
              <div>
                <p className="text-xs text-muted-foreground font-bold uppercase tracking-wider mb-1">Avg per Creator</p>
                <div className="text-2xl font-bold text-secondary flex items-center gap-2">
                  <Zap className="w-5 h-5 text-secondary/50" />
                  {rewards.averagePerCreator} SAB
                </div>
              </div>
              <p className="text-xs text-muted-foreground mt-2 border-t pt-2">Current cycle</p>
            </CardContent>
          </Card>
          
          <Card className="border-secondary/20 bg-secondary/5">
            <CardContent className="pt-6 flex flex-col justify-between h-full">
              <div>
                <p className="text-xs text-secondary font-bold uppercase tracking-wider mb-1">Top Category</p>
                <div className="text-xl font-bold text-foreground flex items-center gap-2">
                  <Target className="w-5 h-5 text-secondary" />
                  {rewards.topCategory}
                </div>
              </div>
              <p className="text-xs font-mono text-muted-foreground mt-2 border-t pt-2 bg-secondary/10 px-2 rounded w-fit">Rate: {rewards.rewardRate}</p>
            </CardContent>
          </Card>
        </div>
      )}

      <Card className="border-2 shadow-sm">
        <CardHeader className="border-b bg-muted/10 pb-4">
          <CardTitle className="flex items-center gap-2">
            <Star className="w-5 h-5 text-yellow-500 fill-yellow-500" />
            Top Earners Leaderboard / शीर्ष कमाई करने वाले
          </CardTitle>
          <CardDescription>Ranked by SAB earned. Updated dynamically.</CardDescription>
        </CardHeader>
        <CardContent className="p-0">
          {loadingBoard ? (
            <div className="p-6"><Skeleton className="h-64 w-full" data-testid="skeleton-leaderboard" /></div>
          ) : leaderboard && (
            <div className="divide-y">
              {leaderboard.creators.map((creator, index) => (
                <div 
                  key={index} 
                  className={`flex flex-col sm:flex-row sm:items-center justify-between p-4 sm:p-6 transition-colors hover:bg-muted/30 ${index < 3 ? 'bg-gradient-to-r from-transparent to-secondary/5' : ''}`}
                  data-testid={`row-creator-${creator.rank}`}
                >
                  <div className="flex items-center gap-5 mb-4 sm:mb-0">
                    <div className={`w-12 h-12 shrink-0 rounded-2xl flex items-center justify-center font-black text-xl shadow-sm ${
                      index === 0 ? 'bg-gradient-to-br from-yellow-300 to-yellow-500 text-yellow-900 border-2 border-yellow-200' :
                      index === 1 ? 'bg-gradient-to-br from-gray-200 to-gray-400 text-gray-800 border-2 border-gray-100' :
                      index === 2 ? 'bg-gradient-to-br from-amber-500 to-amber-700 text-white border-2 border-amber-400' :
                      'bg-muted text-muted-foreground font-bold'
                    }`}>
                      {index < 3 ? <Medal className="w-6 h-6" /> : creator.rank}
                    </div>
                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <h3 className="font-bold text-lg">{creator.name}</h3>
                        {index === 0 && <Badge className="bg-yellow-500 hover:bg-yellow-600 text-white border-none text-[10px] px-1.5 py-0">Top Creator</Badge>}
                      </div>
                      <div className="flex items-center gap-3 text-xs text-muted-foreground">
                        <Badge variant="outline" className="font-normal">{creator.category}</Badge>
                        <span className="flex items-center gap-1"><UsersIcon className="w-3 h-3"/> {creator.followers.toLocaleString()}</span>
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex sm:flex-col items-center sm:items-end justify-between sm:justify-center border-t sm:border-t-0 pt-3 sm:pt-0">
                    <div className="text-sm text-muted-foreground sm:mb-1">{creator.posts} posts</div>
                    <div className="text-xl font-black text-secondary flex items-center gap-1.5 bg-secondary/10 px-3 py-1 rounded-lg">
                      {creator.sabEarned.toLocaleString()} SAB
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

// Inline icon component since Users is already used but maybe we want a different variant
function UsersIcon(props: any) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2" />
      <circle cx="9" cy="7" r="4" />
      <path d="M22 21v-2a4 4 0 0 0-3-3.87" />
      <path d="M16 3.13a4 4 0 0 1 0 7.75" />
    </svg>
  )
}
