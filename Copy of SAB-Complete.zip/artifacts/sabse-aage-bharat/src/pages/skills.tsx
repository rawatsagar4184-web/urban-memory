import { useGetSkillCategories, useGetSkillCourses } from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import { Hammer, Clock, Users, ArrowRight, Zap, Target } from "lucide-react";

export function Skills() {
  const { data: categories, isLoading: loadingCategories } = useGetSkillCategories();
  const { data: courses, isLoading: loadingCourses } = useGetSkillCourses();

  return (
    <div className="space-y-8">
      <div className="flex items-center gap-3">
        <Hammer className="w-10 h-10 text-secondary" />
        <div>
          <h1 className="text-3xl font-bold tracking-tight text-primary">Ghareloo Hunar Kendra</h1>
          <p className="text-muted-foreground mt-1">Skill training for self-reliance. Earn SAB rewards as you learn. / आत्मनिर्भरता के लिए कौशल प्रशिक्षण।</p>
        </div>
      </div>

      <div>
        <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
          <Target className="w-5 h-5 text-primary" />
          Skill Categories / कौशल श्रेणियां
        </h2>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {loadingCategories ? (
            Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-32 w-full" data-testid={`skeleton-skill-cat-${i}`} />)
          ) : categories?.categories.map((cat) => (
            <Card key={cat.id} className="text-center hover:bg-muted/50 transition-all cursor-pointer border-primary/20 hover:border-primary/50 group" data-testid={`card-skill-cat-${cat.id}`}>
              <CardContent className="pt-6">
                <div className="text-4xl mb-3 group-hover:scale-110 transition-transform">{cat.icon}</div>
                <h3 className="font-bold text-sm text-primary mb-1">{cat.name}</h3>
                <p className="text-xs text-muted-foreground">{cat.courseCount} courses available</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      <div>
        <h2 className="text-xl font-semibold mb-4 mt-8 flex items-center gap-2">
          <Zap className="w-5 h-5 text-secondary" />
          Earn While You Learn / सीखते हुए कमाएं
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {loadingCourses ? (
            Array.from({ length: 6 }).map((_, i) => <Skeleton key={i} className="h-64 w-full" data-testid={`skeleton-skill-course-${i}`} />)
          ) : courses?.courses.map((course) => (
            <Card key={course.id} className="flex flex-col border-secondary/20 hover:shadow-md transition-shadow" data-testid={`card-skill-course-${course.id}`}>
              <CardHeader className="pb-3">
                <div className="flex justify-between items-start mb-2">
                  <Badge variant="outline" className="bg-background">{course.category}</Badge>
                  {course.sabReward > 0 && (
                    <Badge className="bg-secondary text-secondary-foreground font-bold flex items-center gap-1 shadow-sm px-2">
                      <span className="w-1.5 h-1.5 rounded-full bg-current animate-pulse"></span>
                      +{course.sabReward} SAB
                    </Badge>
                  )}
                </div>
                <CardTitle className="text-lg leading-tight">{course.title}</CardTitle>
              </CardHeader>
              <CardContent className="flex-1">
                <CardDescription className="line-clamp-2 mb-4 text-sm">{course.description}</CardDescription>
                <div className="grid grid-cols-2 gap-2 text-sm text-muted-foreground bg-muted/30 p-3 rounded-lg border border-border/50">
                  <div className="flex items-center gap-2 font-medium">
                    <Clock className="w-4 h-4 text-primary" /> {course.duration}
                  </div>
                  <div className="flex items-center gap-2 font-medium justify-end">
                    <Users className="w-4 h-4 text-primary" /> {course.enrolled.toLocaleString()}
                  </div>
                </div>
              </CardContent>
              <CardFooter className="pt-0">
                <Button className="w-full font-bold group" data-testid={`button-skill-enroll-${course.id}`}>
                  Start Training / प्रशिक्षण शुरू करें
                  <ArrowRight className="w-4 h-4 ml-2 group-hover:translate-x-1 transition-transform" />
                </Button>
              </CardFooter>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
}
