import { useProcessVoiceCommand } from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { useState, useRef, useEffect } from "react";
import { Mic, ArrowRight, Command, Loader2, Volume2 } from "lucide-react";
import { useLocation } from "wouter";

export function Voice() {
  const [, setLocation] = useLocation();
  const [command, setCommand] = useState("");
  const voiceMutation = useProcessVoiceCommand();
  const inputRef = useRef<HTMLInputElement>(null);

  const handleCommand = (e: React.FormEvent) => {
    e.preventDefault();
    if (!command.trim()) return;
    voiceMutation.mutate({ data: { command, language: "hindi" } });
  };

  const handleNavigate = (path: string) => {
    setLocation(path);
  };

  const fillCommand = (text: string) => {
    setCommand(text);
    if (inputRef.current) {
      inputRef.current.focus();
    }
  };

  // Clear result when command changes significantly
  useEffect(() => {
    if (voiceMutation.data && command === "") {
      voiceMutation.reset();
    }
  }, [command, voiceMutation]);

  return (
    <div className="max-w-3xl mx-auto space-y-8 py-8">
      <div className="text-center space-y-4">
        <div className="relative inline-block">
          <div className="w-24 h-24 bg-gradient-to-br from-primary to-secondary rounded-full flex items-center justify-center mx-auto shadow-xl relative z-10 border-4 border-background">
            <Mic className="w-10 h-10 text-white" />
          </div>
          {/* Decorative pulse rings */}
          <div className="absolute inset-0 bg-primary/20 rounded-full animate-ping z-0" style={{ animationDuration: '3s' }}></div>
          <div className="absolute inset-[-10px] bg-secondary/20 rounded-full animate-pulse z-0" style={{ animationDuration: '2s' }}></div>
        </div>
        
        <div>
          <h1 className="text-4xl font-bold tracking-tight text-primary">Khushi AI Voice Control</h1>
          <p className="text-lg text-muted-foreground mt-2 max-w-xl mx-auto">
            The sovereign intelligence of Bharat. Speak in Hindi, English, or Pahadi to navigate the ecosystem.
          </p>
        </div>
      </div>

      <Card className="border-2 border-primary/20 shadow-xl overflow-hidden">
        <div className="bg-primary/5 p-4 border-b border-primary/10 flex items-center gap-2 text-sm font-medium text-primary">
          <Volume2 className="w-4 h-4" />
          Voice terminal active. Waiting for command...
        </div>
        <CardContent className="p-6 md:p-8">
          <form onSubmit={handleCommand} className="flex flex-col md:flex-row gap-4">
            <div className="relative flex-1">
              <Command className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
              <Input 
                ref={inputRef}
                className="text-lg py-7 pl-12 bg-muted/30 border-primary/20 focus-visible:ring-primary shadow-inner"
                placeholder="e.g. 'Show me mandi prices for wheat', 'Transfer 50 SAB'" 
                value={command}
                onChange={(e) => setCommand(e.target.value)}
                data-testid="input-voice-command"
              />
            </div>
            <Button 
              size="lg" 
              type="submit" 
              className="h-14 px-8 text-base shadow-md" 
              disabled={voiceMutation.isPending || !command.trim()}
              data-testid="button-voice-submit"
            >
              {voiceMutation.isPending ? (
                <><Loader2 className="w-5 h-5 mr-2 animate-spin" /> Processing...</>
              ) : (
                "Process Command"
              )}
            </Button>
          </form>

          {voiceMutation.data && (
            <div className="mt-8 bg-background rounded-xl border border-primary/20 shadow-sm overflow-hidden animate-in slide-in-from-bottom-4" data-testid="voice-result-panel">
              <div className="bg-primary text-primary-foreground p-4 flex justify-between items-center">
                <h3 className="font-bold flex items-center gap-2">
                  <Activity className="w-4 h-4" /> Response Generated
                </h3>
                <Badge className="bg-white/20 hover:bg-white/20 text-white border-none font-mono">
                  Confidence: {(voiceMutation.data.confidence * 100).toFixed(0)}%
                </Badge>
              </div>
              
              <div className="p-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                  <div className="space-y-1 bg-muted/30 p-3 rounded-lg border border-border/50">
                    <p className="text-xs text-muted-foreground uppercase font-bold tracking-wider flex items-center gap-1.5">
                      <Target className="w-3 h-3"/> Detected Intent
                    </p>
                    <p className="font-medium text-base">{voiceMutation.data.intent}</p>
                  </div>
                  <div className="space-y-1 bg-muted/30 p-3 rounded-lg border border-border/50">
                    <p className="text-xs text-muted-foreground uppercase font-bold tracking-wider flex items-center gap-1.5">
                      <Zap className="w-3 h-3"/> Action Required
                    </p>
                    <p className="font-medium text-base text-primary">{voiceMutation.data.action}</p>
                  </div>
                </div>
                
                <div className="bg-secondary/10 border border-secondary/20 p-4 rounded-lg text-secondary-foreground mb-6 shadow-inner">
                  <p className="font-medium leading-relaxed">
                    "{voiceMutation.data.result}"
                  </p>
                </div>
                
                {voiceMutation.data.navigateTo && (
                  <Button 
                    onClick={() => handleNavigate(voiceMutation.data.navigateTo!)}
                    className="w-full h-12 text-base font-bold bg-primary hover:bg-primary/90 shadow-md group"
                    data-testid="button-voice-navigate"
                  >
                    Execute Navigation: {voiceMutation.data.navigateTo} 
                    <ArrowRight className="w-5 h-5 ml-2 group-hover:translate-x-1 transition-transform" />
                  </Button>
                )}
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      <div className="bg-muted/30 border rounded-xl p-6 shadow-sm">
        <p className="font-bold mb-4 text-center text-muted-foreground uppercase tracking-wider text-sm flex items-center justify-center gap-2">
          <MessageSquare className="w-4 h-4"/> Suggested Commands
        </p>
        <div className="flex flex-wrap justify-center gap-3">
          <Badge 
            variant="outline" 
            className="px-4 py-2 cursor-pointer hover:bg-primary hover:text-primary-foreground transition-colors text-sm font-normal border-primary/20 bg-background shadow-sm" 
            onClick={() => fillCommand("Take me to the admin dashboard")}
          >
            "Take me to the admin dashboard"
          </Badge>
          <Badge 
            variant="outline" 
            className="px-4 py-2 cursor-pointer hover:bg-secondary hover:text-secondary-foreground transition-colors text-sm font-normal border-secondary/20 bg-background shadow-sm" 
            onClick={() => fillCommand("Show me mandi prices for wheat today")}
          >
            "Show me mandi prices for wheat today"
          </Badge>
          <Badge 
            variant="outline" 
            className="px-4 py-2 cursor-pointer hover:bg-success hover:text-white transition-colors text-sm font-normal border-success/20 bg-background shadow-sm" 
            onClick={() => fillCommand("I want to learn Hindi from English")}
          >
            "I want to learn Hindi from English"
          </Badge>
          <Badge 
            variant="outline" 
            className="px-4 py-2 cursor-pointer hover:bg-primary hover:text-primary-foreground transition-colors text-sm font-normal border-primary/20 bg-background shadow-sm" 
            onClick={() => fillCommand("Transfer 500 SAB to my family")}
          >
            "Transfer 500 SAB to my family"
          </Badge>
        </div>
      </div>
    </div>
  );
}

// Inline icons that weren't imported
function Activity(props: any) {
  return <svg {...props} xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M22 12h-2.48a2 2 0 0 0-1.93 1.46l-2.35 8.36a.25.25 0 0 1-.48 0L9.24 2.18a.25.25 0 0 0-.48 0l-2.35 8.36A2 2 0 0 1 4.48 12H2"/></svg>
}
function Target(props: any) {
  return <svg {...props} xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="10"/><circle cx="12" cy="12" r="6"/><circle cx="12" cy="12" r="2"/></svg>
}
function Zap(props: any) {
  return <svg {...props} xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M4 14a1 1 0 0 1-.78-1.63l9.9-10.2a.5.5 0 0 1 .86.46l-1.92 6.02A1 1 0 0 0 13 10h7a1 1 0 0 1 .78 1.63l-9.9 10.2a.5.5 0 0 1-.86-.46l1.92-6.02A1 1 0 0 0 11 14z"/></svg>
}
function MessageSquare(props: any) {
  return <svg {...props} xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>
}
