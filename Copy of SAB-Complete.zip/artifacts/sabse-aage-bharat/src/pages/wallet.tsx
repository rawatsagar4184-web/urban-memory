import { useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import {
  useCreateWallet,
  useGetWallet,
  useCreateWalletGoal,
  useListWalletGoals,
  getListWalletGoalsQueryKey,
  useGetUPIQR,
  getGetUPIQRQueryKey,
} from "@workspace/api-client-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { CopyableHash } from "@/components/copyable-hash";
import { useToast } from "@/hooks/use-toast";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Progress } from "@/components/ui/progress";
import {
  KeyRound, ShieldAlert, Search, Wallet as WalletIcon, Coins, Clock,
  AlertCircle, Target, QrCode, Plus, ExternalLink,
} from "lucide-react";
import { format } from "date-fns";

export function WalletHub() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // ── Create Wallet ────────────────────────────────────────────────────────
  const [ownerName, setOwnerName] = useState("");
  const [initialBalance, setInitialBalance] = useState("");
  const createWallet = useCreateWallet();
  const [newWallet, setNewWallet] = useState<{ address: string; privateKey: string; balance: number; balanceINR: number } | null>(null);

  // ── Lookup ───────────────────────────────────────────────────────────────
  const [lookupAddress, setLookupAddress] = useState("");
  const [searchAddress, setSearchAddress] = useState("");
  const { data: walletInfo, isLoading: walletLoading, isError: walletError } = useGetWallet(searchAddress, {
    query: { enabled: !!searchAddress, queryKey: ["wallet", searchAddress] }
  });

  // ── Goals ────────────────────────────────────────────────────────────────
  const [goalWallet, setGoalWallet] = useState("");
  const [goalForm, setGoalForm] = useState({ name: "", targetAmount: "" });
  const createGoalMut = useCreateWalletGoal();
  const { data: goals, refetch: refetchGoals } = useListWalletGoals(goalWallet, {
    query: { enabled: !!goalWallet, queryKey: getListWalletGoalsQueryKey(goalWallet) }
  });

  // ── UPI QR ───────────────────────────────────────────────────────────────
  const [qrUpiId, setQrUpiId] = useState("");
  const [fetchQrId, setFetchQrId] = useState("");
  const { data: qrData } = useGetUPIQR(fetchQrId, {
    query: { enabled: !!fetchQrId, queryKey: getGetUPIQRQueryKey(fetchQrId) }
  });

  const handleCreateWallet = () => {
    if (!ownerName.trim()) {
      toast({ title: "Error", description: "Owner Name is required", variant: "destructive" }); return;
    }
    createWallet.mutate(
      { data: { ownerName: ownerName.trim(), initialBalance: initialBalance ? Number(initialBalance) : undefined } },
      {
        onSuccess: (data) => {
          setNewWallet(data);
          setOwnerName(""); setInitialBalance("");
          toast({ title: "Wallet Created", description: "आपका SAB Wallet तैयार है।" });
        },
        onError: (err: unknown) => toast({ title: "Wallet बनाने में विफल", description: (err as { message?: string }).message ?? "Error", variant: "destructive" }),
      }
    );
  };

  const handleCreateGoal = () => {
    if (!goalWallet || !goalForm.name || !goalForm.targetAmount) {
      toast({ title: "Wallet Address, नाम, और लक्ष्य राशि आवश्यक है", variant: "destructive" }); return;
    }
    createGoalMut.mutate(
      { data: { walletAddress: goalWallet, name: goalForm.name, targetAmount: Number(goalForm.targetAmount) } },
      {
        onSuccess: () => {
          toast({ title: "लक्ष्य बना!", description: `${goalForm.name} — ₹${Number(goalForm.targetAmount).toLocaleString("en-IN")}` });
          setGoalForm({ name: "", targetAmount: "" });
          queryClient.invalidateQueries({ queryKey: getListWalletGoalsQueryKey(goalWallet) });
          refetchGoals();
        },
        onError: (e) => toast({ title: "विफल", description: (e as { error?: string }).error ?? "Error", variant: "destructive" }),
      }
    );
  };

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div>
        <h2 className="text-3xl font-bold tracking-tight text-primary flex items-center gap-2">
          <WalletIcon className="w-8 h-8" /> SAB Wallet Hub
        </h2>
        <p className="text-muted-foreground mt-1">SAB Coin सॉवरेन डिजिटल वॉलेट — 100 SAB = ₹1 (स्थायी)</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">

        {/* ── Create Wallet ─────────────────────────────────────────────── */}
        <Card className="border-t-4 border-t-primary">
          <CardHeader>
            <CardTitle className="flex items-center gap-2"><WalletIcon className="w-5 h-5 text-primary" /> नया Wallet बनाएं</CardTitle>
            <CardDescription>SAB Address और Private Key generate करें</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {newWallet ? (
              <Alert className="border-secondary bg-secondary/5">
                <ShieldAlert className="h-5 w-5 text-secondary" />
                <AlertTitle className="text-secondary font-bold">⚠️ Private Key अभी save करें — फिर नहीं दिखेगी</AlertTitle>
                <AlertDescription className="space-y-3 mt-2">
                  <div className="bg-background p-3 rounded-md border space-y-2">
                    <div><Label className="text-xs text-muted-foreground">Address (Public)</Label><CopyableHash hash={newWallet.address} /></div>
                    <div><Label className="text-xs text-muted-foreground">Private Key (Secret)</Label><CopyableHash hash={newWallet.privateKey} /></div>
                    <div className="flex gap-4 pt-2 text-sm">
                      <div><span className="text-muted-foreground">Balance: </span><strong>{newWallet.balance.toLocaleString()} SAB</strong></div>
                      <div><span className="text-muted-foreground">= </span><strong>₹{newWallet.balanceINR.toLocaleString("en-IN")}</strong></div>
                    </div>
                  </div>
                  <Button variant="outline" className="w-full" onClick={() => setNewWallet(null)}>मैंने key save कर ली</Button>
                </AlertDescription>
              </Alert>
            ) : (
              <div className="space-y-3">
                <div className="space-y-1">
                  <Label>Owner Name</Label>
                  <Input placeholder="e.g. Sagar Bhai" value={ownerName} onChange={e => setOwnerName(e.target.value)} />
                </div>
                <div className="space-y-1">
                  <Label>Initial Balance (Dev only)</Label>
                  <Input type="number" placeholder="0 SAB" value={initialBalance} onChange={e => setInitialBalance(e.target.value)} />
                </div>
                <Button className="w-full bg-primary text-white" size="lg" onClick={handleCreateWallet} disabled={createWallet.isPending}>
                  {createWallet.isPending ? "Generating..." : "Wallet Generate करें"}
                </Button>
              </div>
            )}
          </CardContent>
        </Card>

        {/* ── Wallet Lookup ─────────────────────────────────────────────── */}
        <div className="space-y-4">
          <Card className="border-t-4 border-t-secondary">
            <CardHeader>
              <CardTitle className="flex items-center gap-2"><Search className="w-5 h-5 text-secondary" /> Wallet Lookup</CardTitle>
              <CardDescription>किसी भी SAB Address की जानकारी देखें</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex gap-2">
                <Input placeholder="SAB address..." value={lookupAddress} onChange={e => setLookupAddress(e.target.value)} onKeyDown={e => e.key === "Enter" && setSearchAddress(lookupAddress.trim())} />
                <Button variant="secondary" onClick={() => setSearchAddress(lookupAddress.trim())} disabled={walletLoading}>
                  {walletLoading ? "..." : <Search className="w-4 h-4" />}
                </Button>
              </div>
            </CardContent>
          </Card>

          {walletError && (
            <Alert variant="destructive"><AlertCircle className="h-4 w-4" /><AlertTitle>नहीं मिला</AlertTitle><AlertDescription>इस address का wallet नहीं मिला।</AlertDescription></Alert>
          )}

          {walletInfo && (
            <Card>
              <CardHeader className="bg-muted/30 border-b pb-3">
                <CardTitle className="text-lg">{walletInfo.ownerName}</CardTitle>
                <div className="mt-1"><CopyableHash hash={walletInfo.address} /></div>
              </CardHeader>
              <CardContent className="pt-4 space-y-3">
                <div className="bg-primary/5 rounded-xl p-4 border border-primary/10">
                  <Label className="text-xs text-primary uppercase tracking-wider font-bold">Available Balance</Label>
                  <div className="flex items-baseline gap-2 mt-1">
                    <span className="text-3xl font-bold">{walletInfo.balance.toLocaleString()}</span>
                    <span className="text-muted-foreground font-medium">SAB</span>
                  </div>
                  <p className="text-sm text-muted-foreground mt-1">= ₹{walletInfo.balanceINR.toLocaleString("en-IN")} INR</p>
                </div>
                <div className="flex gap-4 text-sm">
                  <div><span className="text-muted-foreground">Transactions: </span><strong>{walletInfo.transactionCount}</strong></div>
                  <div className="flex items-center gap-1"><Clock className="w-3 h-3 text-muted-foreground" /><span className="text-muted-foreground">{format(new Date(walletInfo.createdAt), "MMM d, yyyy")}</span></div>
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </div>

      {/* ── Savings Goals ─────────────────────────────────────────────────── */}
      <Card className="border-t-4 border-t-amber-500">
        <CardHeader>
          <CardTitle className="flex items-center gap-2"><Target className="w-5 h-5 text-amber-600" /> Piggy Bank — बचत लक्ष्य</CardTitle>
          <CardDescription>अपने SAB Wallet में बचत लक्ष्य बनाएं (Mobile, घर, शिक्षा…)</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
            <div className="space-y-1 md:col-span-2">
              <Label>Wallet Address</Label>
              <Input placeholder="SAB address..." value={goalWallet} onChange={e => setGoalWallet(e.target.value)} className="font-mono text-sm" />
            </div>
            <div className="space-y-1">
              <Label>लक्ष्य का नाम</Label>
              <Input placeholder="e.g. नया Phone" value={goalForm.name} onChange={e => setGoalForm({ ...goalForm, name: e.target.value })} />
            </div>
            <div className="space-y-1">
              <Label>लक्ष्य राशि (₹)</Label>
              <Input type="number" placeholder="15000" value={goalForm.targetAmount} onChange={e => setGoalForm({ ...goalForm, targetAmount: e.target.value })} />
            </div>
          </div>
          <Button onClick={handleCreateGoal} disabled={createGoalMut.isPending} className="bg-amber-600 hover:bg-amber-700 text-white">
            <Plus className="w-4 h-4 mr-1" /> {createGoalMut.isPending ? "बन रहा है..." : "लक्ष्य बनाएं"}
          </Button>

          {goals && goals.goals.length > 0 && (
            <div className="mt-4 space-y-3">
              <div className="text-sm font-medium text-muted-foreground uppercase tracking-wider">सक्रिय लक्ष्य ({goals.total})</div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {goals.goals.map(g => (
                  <div key={g.id} className="border rounded-lg p-3 space-y-2 bg-amber-50/50">
                    <div className="flex justify-between items-center">
                      <div className="font-medium text-amber-900">{g.name}</div>
                      <div className="text-xs font-bold text-amber-700">{g.progressPercent}%</div>
                    </div>
                    <Progress value={g.progressPercent} className="h-2 bg-amber-100 [&>div]:bg-amber-500" />
                    <div className="flex justify-between text-xs text-muted-foreground">
                      <span>₹{g.savedAmount.toLocaleString("en-IN")} बचाए</span>
                      <span>लक्ष्य: ₹{g.targetAmount.toLocaleString("en-IN")}</span>
                    </div>
                    <div className="text-[10px] text-muted-foreground font-mono">{g.id}</div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* ── UPI QR ────────────────────────────────────────────────────────── */}
      <Card className="border-t-4 border-t-green-600">
        <CardHeader>
          <CardTitle className="flex items-center gap-2"><QrCode className="w-5 h-5 text-green-700" /> SAB Pay UPI — Payment Link</CardTitle>
          <CardDescription>UPI ID से payment link और deep link generate करें</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex gap-2 max-w-md">
            <Input placeholder="e.g. @sabpay या sagar@sabpay" value={qrUpiId} onChange={e => setQrUpiId(e.target.value)} />
            <Button onClick={() => setFetchQrId(qrUpiId.trim())} disabled={!qrUpiId.trim()} className="bg-green-700 hover:bg-green-800 text-white">
              <QrCode className="w-4 h-4 mr-1" /> Generate
            </Button>
          </div>

          {qrData && (
            <div className="max-w-sm border rounded-xl p-4 bg-green-50 space-y-3">
              <div className="text-center">
                <div className="text-xs text-muted-foreground uppercase tracking-wider">SAB Pay</div>
                <div className="text-lg font-bold text-green-800">{qrData.upiId}</div>
                <div className="text-sm text-muted-foreground">{qrData.displayName}</div>
              </div>
              <div className="bg-white rounded-lg p-3 border border-green-200 text-center">
                <div className="grid grid-cols-7 gap-0.5 mx-auto w-36">
                  {Array.from({ length: 49 }, (_, i) => (
                    <div key={i} className={`w-4 h-4 rounded-sm ${Math.sin(i * 2.7 + qrData.upiId.length) > 0.1 ? "bg-green-800" : "bg-white"}`} />
                  ))}
                </div>
                <div className="text-[10px] text-muted-foreground mt-2 font-mono">UPI Deep Link QR (Dev Visual)</div>
              </div>
              <div className="bg-white border rounded p-2 font-mono text-xs break-all text-green-900">{qrData.upiUri}</div>
              <Button
                variant="outline"
                className="w-full border-green-600 text-green-700 hover:bg-green-50"
                onClick={() => { navigator.clipboard.writeText(qrData.upiUri); toast({ title: "UPI Link Copied!" }); }}
              >
                <ExternalLink className="w-4 h-4 mr-1" /> UPI Link Copy करें
              </Button>
              <div className="text-[10px] text-center text-muted-foreground">
                Real QR scan: Uttarakhand server पर deploy होने पर live होगा
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* ── Info Footer ───────────────────────────────────────────────────── */}
      <div className="text-xs text-muted-foreground border-t pt-4 flex items-center gap-4">
        <div className="flex items-center gap-1"><Coins className="w-3 h-3" /> 100 SAB = ₹1 (स्थायी दर — कभी नहीं बदलेगी)</div>
        <div className="flex items-center gap-1"><KeyRound className="w-3 h-3" /> End-to-end encrypted — SHA-256 blockchain</div>
      </div>
    </div>
  );
}
