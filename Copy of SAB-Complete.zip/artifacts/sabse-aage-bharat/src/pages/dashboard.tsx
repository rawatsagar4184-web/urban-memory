import { useEffect, useState, useRef } from "react";
import { useGetChainStats, getGetChainStatsQueryKey } from "@workspace/api-client-react";
import { useLocation } from "wouter";

const MODULES = [
  { id: "banking",    label: "BANKING / CORE MODULE",        route: "/banking",  status: "ACTIVE"  },
  { id: "investment", label: "INVESTMENT MODULE [FD/RD/SI]", route: "/banking",  status: "ACTIVE"  },
  { id: "trading",    label: "TRADING MODULE [LIVE]",        route: "/exchange", status: "ACTIVE"  },
  { id: "wallet",     label: "WALLET / SAB PAY MODULE",      route: "/wallet",   status: "ACTIVE"  },
  { id: "picnic",     label: "PICNIC / TRAVEL MODULE",       route: "#",         status: "PENDING" },
  { id: "user",       label: "USER MANAGEMENT MODULE",       route: "/admin",    status: "ACTIVE"  },
  { id: "security",   label: "SECURITY [BIKER] MODULE",      route: "/threat",   status: "ACTIVE"  },
  { id: "nativity",   label: "NATIVITY [BIO-LINK] MODULE",   route: "#",         status: "PENDING" },
  { id: "analytics",  label: "DATA ANALYTICS MODULE",        route: "#",         status: "PENDING" },
  { id: "agric",      label: "AGRIC COMMAND MODULE",         route: "#",         status: "PENDING" },
  { id: "ecological", label: "ECOLOGICAL IMPACT HUB",        route: "#",         status: "PENDING" },
  { id: "loan",       label: "LOAN MODULE [COMING SOON]",    route: "#",         status: "OFFLINE" },
];

const HEX_NODES = [
  { label: "BANK",   angle: 270 },
  { label: "INVEST", angle: 330 },
  { label: "TRADE",  angle: 30  },
  { label: "WALLET", angle: 90  },
  { label: "TRAVEL", angle: 150 },
  { label: "AGRIC",  angle: 210 },
];

const EXTRA_NODES = [
  { label: "SECURITY", x: 240, y: 80,  color: "#00ff41" },
  { label: "NATIVITY", x: 80,  y: 80,  color: "#FFB300" },
  { label: "ANALYTICS",x: 240, y: 240, color: "#FFB300" },
];

function HexNodeMap() {
  const cx = 160; const cy = 160; const r = 100;
  const nodes = HEX_NODES.map(n => {
    const rad = (n.angle * Math.PI) / 180;
    return { ...n, x: cx + r * Math.cos(rad), y: cy + r * Math.sin(rad) };
  });
  const active = ["BANK","INVEST","TRADE","WALLET"];
  return (
    <svg viewBox="0 0 320 320" className="w-full max-w-xs mx-auto" style={{ filter: "drop-shadow(0 0 8px #00ff41)" }}>
      {nodes.map((n, i) => <line key={i} x1={cx} y1={cy} x2={n.x} y2={n.y} stroke="#00ff4133" strokeWidth="1" />)}
      {EXTRA_NODES.map((n, i) => <line key={`e${i}`} x1={cx} y1={cy} x2={n.x} y2={n.y} stroke={`${n.color}22`} strokeWidth="1" strokeDasharray="3,3" />)}
      {nodes.map((n, i) => (
        <g key={i}>
          <circle cx={n.x} cy={n.y} r="22" fill="#050E05" stroke={active.includes(n.label) ? "#00ff41" : "#FFB300"} strokeWidth="1.5" />
          <text x={n.x} y={n.y + 4} textAnchor="middle" fill={active.includes(n.label) ? "#00ff41" : "#FFB300"} fontSize="7" fontFamily="monospace" fontWeight="bold">{n.label}</text>
        </g>
      ))}
      {EXTRA_NODES.map((n, i) => (
        <g key={`en${i}`}>
          <circle cx={n.x} cy={n.y} r="18" fill="#050E05" stroke={n.color} strokeWidth="1" />
          <text x={n.x} y={n.y + 3} textAnchor="middle" fill={n.color} fontSize="6" fontFamily="monospace">{n.label}</text>
        </g>
      ))}
      <polygon
        points={`${cx},${cy-32} ${cx+28},${cy-16} ${cx+28},${cy+16} ${cx},${cy+32} ${cx-28},${cy+16} ${cx-28},${cy-16}`}
        fill="#0D2A0D" stroke="#00ff41" strokeWidth="2"
        style={{ filter: "drop-shadow(0 0 8px #00ff41)" }}
      />
      <text x={cx} y={cy-5} textAnchor="middle" fill="#FFB300" fontSize="8" fontFamily="monospace" fontWeight="bold">SAB</text>
      <text x={cx} y={cx+6} textAnchor="middle" fill="#00ff41" fontSize="6" fontFamily="monospace">MASTER</text>
    </svg>
  );
}

function Blink({ children }: { children: React.ReactNode }) {
  const [on, setOn] = useState(true);
  useEffect(() => { const t = setInterval(() => setOn(v => !v), 600); return () => clearInterval(t); }, []);
  return <span style={{ opacity: on ? 1 : 0 }}>{children}</span>;
}

function TypeWriter({ text, speed = 25 }: { text: string; speed?: number }) {
  const [out, setOut] = useState("");
  useEffect(() => {
    setOut("");
    let i = 0;
    const t = setInterval(() => { if (i < text.length) { setOut(text.slice(0, ++i)); } else clearInterval(t); }, speed);
    return () => clearInterval(t);
  }, [text, speed]);
  return <span>{out}<Blink>█</Blink></span>;
}

const BOOT_MSGS = [
  "Sagar Bhai, system online. SAB Network: 100% uptime.",
  "346 SAB Coins minted. Banking module fully operational.",
  "Data Analytics module — Pending deployment.",
  "Security threat scan: 0 critical. All systems nominal.",
  "Awaiting command. आप बोलिए, मैं सुन रहा हूं...",
];

function WaveBar({ heights }: { heights: number[] }) {
  return (
    <div className="flex items-end gap-[2px] h-8">
      {heights.map((h, i) => (
        <div key={i} style={{ width: 4, height: h, background: "#00ff41", borderRadius: 2, transition: "height 0.08s" }} />
      ))}
    </div>
  );
}

export function Dashboard() {
  const [, navigate] = useLocation();
  const { data: stats } = useGetChainStats({ query: { queryKey: getGetChainStatsQueryKey(), refetchInterval: 5000 } });
  const [time, setTime] = useState(new Date());
  const [chatIdx, setChatIdx] = useState(0);
  const [cmdInput, setCmdInput] = useState("");
  const [cmdHistory, setCmdHistory] = useState<string[]>([]);
  const [listening, setListening] = useState(false);
  const [waveH, setWaveH] = useState(Array.from({ length: 12 }, () => 8));
  const chatEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => { const t = setInterval(() => setTime(new Date()), 1000); return () => clearInterval(t); }, []);
  useEffect(() => {
    if (chatIdx < BOOT_MSGS.length - 1) {
      const t = setTimeout(() => setChatIdx(i => i + 1), 2400);
      return () => clearTimeout(t);
    }
    return undefined;
  }, [chatIdx]);
  useEffect(() => { chatEndRef.current?.scrollIntoView({ behavior: "smooth" }); }, [chatIdx, cmdHistory]);
  useEffect(() => {
    if (!listening) { setWaveH(Array.from({ length: 12 }, () => 8)); return; }
    const t = setInterval(() => setWaveH(Array.from({ length: 12 }, () => 4 + Math.random() * 22)), 80);
    return () => clearInterval(t);
  }, [listening]);

  const runCmd = (raw: string) => {
    const c = raw.trim().toLowerCase();
    if (!c) return;
    let reply = "अज्ञात — 'help' टाइप करें।";
    if (c === "help") reply = "status | banking | wallet | exchange | threat | admin | modules | clear";
    else if (c === "status") reply = `SYSTEM: ${stats?.isSystemFrozen ? "⚠ FROZEN" : "✓ ONLINE"} | BLOCKS: ${stats?.totalBlocks ?? "?"} | WALLETS: ${stats?.totalWallets ?? "?"} | SAB: ${stats?.totalSABInCirculation?.toLocaleString() ?? "?"}`;
    else if (["banking","wallet","exchange","threat","admin"].includes(c)) { navigate(`/${c}`); return; }
    else if (c === "clear") { setCmdHistory([]); setCmdInput(""); return; }
    else if (c === "modules") reply = MODULES.map(m => `[${m.status.padEnd(7)}] ${m.label}`).join("\n");
    setCmdHistory(h => [...h, `> ${raw}`, `[A1] ${reply}`]);
    setCmdInput("");
  };

  const G = "#00ff41"; const A = "#FFB300"; const D = "#00ff4166"; const S = "#FF6B35";

  return (
    <div style={{ background: "#050E05", minHeight: "100vh", fontFamily: "'Courier New', monospace", position: "relative" }}>
      <div style={{ position: "fixed", inset: 0, pointerEvents: "none", backgroundImage: "repeating-linear-gradient(0deg,transparent,transparent 2px,rgba(0,255,65,0.015) 2px,rgba(0,255,65,0.015) 4px)", zIndex: 50 }} />

      <div className="p-3 space-y-2" style={{ position: "relative", zIndex: 1 }}>

        {/* HEADER */}
        <div className="flex items-center justify-between border px-3 py-1.5 rounded-sm" style={{ borderColor: "#00ff4144", background: "#0A150A" }}>
          <div className="flex items-center gap-3">
            <span className="text-base font-bold" style={{ color: S }}>⊕ सबसे आगे भारत</span>
            <span className="text-xs" style={{ color: D }}>MASTER CONTROL v2.0</span>
          </div>
          <div className="text-right text-xs">
            <div style={{ color: G }}>{time.toLocaleTimeString("en-IN", { hour12: false })}</div>
            <div style={{ color: D }}>{time.toLocaleDateString("en-IN")}</div>
          </div>
        </div>

        {/* STATUS BAR */}
        <div className="border rounded-sm px-3 py-1.5 text-xs space-y-0.5" style={{ borderColor: "#00ff4133", background: "#0A150A" }}>
          <div style={{ color: G }}>
            MASTER CONTROL: <span style={{ color: D }}>●●●●●● sabseagebharat.com</span>{" "}
            <span style={{ color: A }}>[LOGGED IN: Temporary]</span>
          </div>
          <div style={{ color: D }}>
            SYSTEM STATUS: <span style={{ color: G }}>ON</span> &nbsp;|&nbsp;
            SAB COIN: <Blink><span style={{ color: G }}>ACTIVE</span></Blink> &nbsp;|&nbsp;
            NETWORK: <span style={{ color: stats?.isSystemFrozen ? "#ff4444" : G }}>{stats?.isSystemFrozen ? "⚠ FROZEN" : "● NOMINAL"}</span> &nbsp;|&nbsp;
            USER ACTIVITY: <span style={{ color: G }}>{stats?.totalWallets ?? 0} wallets active</span>
          </div>
        </div>

        {/* MAIN 3-COL */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-2">

          {/* LEFT: MODULE COMMANDER */}
          <div className="border rounded-sm p-3" style={{ borderColor: "#00ff4133", background: "#0A150A" }}>
            <div className="text-xs font-bold mb-2 pb-1 border-b" style={{ color: A, borderColor: "#FFB30033" }}>
              ⬡ MASTER WORKFLOW COMMANDER
            </div>
            <div className="space-y-1">
              {MODULES.map((m, i) => {
                const col = m.status === "ACTIVE" ? G : m.status === "PENDING" ? A : "#444";
                return (
                  <div key={m.id} className="flex items-center gap-2 cursor-pointer hover:opacity-80"
                    style={{ color: col, animationDelay: `${i * 0.05}s` }}
                    onClick={() => m.route !== "#" && navigate(m.route)}>
                    <span className="text-xs">{m.status === "ACTIVE" ? "☑" : m.status === "PENDING" ? "☐" : "✕"}</span>
                    <span className="text-xs flex-1">{m.label}</span>
                    <span className="text-[9px] border px-1 rounded-sm shrink-0"
                      style={{ borderColor: col, color: col }}>{m.status}</span>
                  </div>
                );
              })}
            </div>
            <div className="mt-2 pt-1.5 border-t text-[10px]" style={{ borderColor: "#00ff4122", color: D }}>
              ACTIVE: {MODULES.filter(m => m.status === "ACTIVE").length} &nbsp;|&nbsp;
              PENDING: {MODULES.filter(m => m.status === "PENDING").length} &nbsp;|&nbsp;
              OFFLINE: {MODULES.filter(m => m.status === "OFFLINE").length}
            </div>
          </div>

          {/* CENTER: HEX MAP */}
          <div className="border rounded-sm p-3 flex flex-col items-center justify-center gap-2" style={{ borderColor: "#00ff4133", background: "#0A150A" }}>
            <div className="text-xs font-bold" style={{ color: A }}>⬡ SAB NETWORK NODE MAP</div>
            <HexNodeMap />
            <div className="text-[10px] text-center" style={{ color: D }}>
              <Blink><span style={{ color: G }}>●</span></Blink> ALL NODES SYNCHRONIZED &nbsp;|&nbsp; CHAIN SECURE
            </div>
          </div>

          {/* RIGHT: QUICK ACCESS */}
          <div className="border rounded-sm p-3" style={{ borderColor: "#00ff4133", background: "#0A150A" }}>
            <div className="text-xs font-bold mb-2 pb-1 border-b" style={{ color: A, borderColor: "#FFB30033" }}>
              ⬡ QUICK ACCESS PORTAL
            </div>
            <div className="space-y-1">
              {[
                { label: "BANKING / CORE",     route: "/banking",  st: "ACTIVE",  icon: "🏦" },
                { label: "SAB WALLET",          route: "/wallet",   st: "ACTIVE",  icon: "💎" },
                { label: "EXCHANGE",            route: "/exchange", st: "ACTIVE",  icon: "⚡" },
                { label: "BLOCKCHAIN EXPLORER", route: "/explorer", st: "ACTIVE",  icon: "⛓" },
                { label: "ADMIN PANEL",         route: "/admin",    st: "ACTIVE",  icon: "🛡" },
                { label: "THREAT MONITOR",      route: "/threat",   st: "ACTIVE",  icon: "🔒" },
                { label: "TRAVEL MODULE",       route: "#",         st: "PENDING", icon: "🚂" },
                { label: "AGRIC COMMAND",       route: "#",         st: "PENDING", icon: "🌾" },
              ].map(n => {
                const col = n.st === "ACTIVE" ? G : A;
                return (
                  <div key={n.label} className="flex items-center gap-2 p-1.5 rounded-sm cursor-pointer hover:bg-green-950/30"
                    style={{ color: col }} onClick={() => n.route !== "#" && navigate(n.route)}>
                    <span>{n.icon}</span>
                    <span className="text-xs flex-1">{n.label}</span>
                    <span className="text-[9px] border px-1 rounded-sm" style={{ borderColor: col, color: col }}>
                      {n.st === "ACTIVE" ? "▶ ENTER" : "PENDING"}
                    </span>
                  </div>
                );
              })}
            </div>
            <div className="mt-2 pt-1.5 border-t text-[10px] space-y-0.5" style={{ borderColor: "#00ff4122" }}>
              <div style={{ color: D }}>TEMPORARY PATH ACTIVE</div>
              <div style={{ color: G }}>● sabseagebharat.com</div>
              <div style={{ color: A }}>Uttarakhand Server: PENDING MIGRATION</div>
            </div>
          </div>
        </div>

        {/* AI COMMAND HUB */}
        <div className="border rounded-sm" style={{ borderColor: "#00ff4155", background: "#0A150A" }}>
          <div className="border-b px-3 py-1 flex items-center gap-2" style={{ borderColor: "#00ff4133" }}>
            <span className="text-xs font-bold" style={{ color: A }}>⬡ AI CONVERSATION &amp; UNIFIED COMMAND HUB</span>
            <Blink><span className="text-[10px]" style={{ color: G }}>[ONLINE]</span></Blink>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-3 p-3">
            {/* Voice Avatar */}
            <div className="flex flex-col items-center justify-center gap-3 border rounded-sm p-4" style={{ borderColor: "#00ff4133" }}>
              <div className="relative cursor-pointer" onClick={() => setListening(l => !l)}>
                <div className="w-20 h-20 rounded-full border-2 flex items-center justify-center"
                  style={{ borderColor: listening ? G : A, background: "#0D2A0D", boxShadow: listening ? `0 0 24px ${G}88` : `0 0 8px ${A}44` }}>
                  <span className="text-4xl">{listening ? "🎙" : "🎤"}</span>
                </div>
                {listening && <div className="absolute -inset-2 rounded-full border-2 animate-ping opacity-30" style={{ borderColor: G }} />}
              </div>
              {listening && <WaveBar heights={waveH} />}
              <div className="text-xs text-center" style={{ color: listening ? G : D }}>
                {listening ? <TypeWriter text="सुन रहा हूं..." /> : "TAP TO ACTIVATE"}
              </div>
              <div className="text-[10px] text-center" style={{ color: D }}>
                A1 — SAB AI COMMANDER<br />भारत की डिजिटल आवाज़
              </div>
            </div>

            {/* Terminal Chat */}
            <div className="border rounded-sm p-2 flex flex-col" style={{ borderColor: "#00ff4133", minHeight: "200px" }}>
              <div className="flex-1 overflow-y-auto space-y-1 text-xs mb-2" style={{ maxHeight: "170px" }}>
                {BOOT_MSGS.slice(0, chatIdx + 1).map((msg, i) => (
                  <div key={i}>
                    <span style={{ color: A }}>[A1]: </span>
                    <span style={{ color: G }}>{i === chatIdx ? <TypeWriter text={msg} /> : msg}</span>
                  </div>
                ))}
                {cmdHistory.map((line, i) => (
                  <div key={`h${i}`} className="text-xs whitespace-pre-wrap"
                    style={{ color: line.startsWith(">") ? A : G }}>{line}</div>
                ))}
                <div ref={chatEndRef} />
              </div>
              <div className="flex items-center gap-1 border-t pt-1" style={{ borderColor: "#00ff4122" }}>
                <span className="text-xs" style={{ color: G }}>&gt;</span>
                <input
                  className="flex-1 bg-transparent outline-none text-xs"
                  style={{ color: G, caretColor: G }}
                  placeholder="command / query टाइप करें..."
                  value={cmdInput}
                  onChange={e => setCmdInput(e.target.value)}
                  onKeyDown={e => e.key === "Enter" && runCmd(cmdInput)}
                />
                <button className="text-[10px] border px-1.5 py-0.5 rounded-sm" style={{ borderColor: G, color: G }}
                  onClick={() => runCmd(cmdInput)}>SEND</button>
              </div>
            </div>

            {/* Vitals */}
            <div className="border rounded-sm p-2 space-y-2" style={{ borderColor: "#00ff4133" }}>
              <div className="text-[10px] font-bold" style={{ color: A }}>SYSTEM VITALS</div>
              <div className="grid grid-cols-2 gap-1.5">
                {[
                  { label: "BLOCKS",    value: String(stats?.totalBlocks ?? 0),                                           col: G },
                  { label: "WALLETS",   value: String(stats?.totalWallets ?? 0),                                          col: G },
                  { label: "SAB COINS", value: (stats?.totalSABInCirculation ?? 0).toLocaleString(),                      col: A },
                  { label: "INR VALUE", value: `₹${((stats?.totalSABInCirculation ?? 0) / 100).toLocaleString()}`,        col: S },
                ].map(v => (
                  <div key={v.label} className="border rounded-sm p-1.5 text-center" style={{ borderColor: `${v.col}44`, background: `${v.col}08` }}>
                    <div className="text-[9px]" style={{ color: D }}>{v.label}</div>
                    <div className="text-sm font-bold" style={{ color: v.col }}>{v.value}</div>
                  </div>
                ))}
              </div>
              <div className="space-y-1.5">
                {[
                  { label: "CPU LOAD",   pct: 23,  col: G },
                  { label: "MEMORY",     pct: 41,  col: A },
                  { label: "CHAIN SYNC", pct: 100, col: G },
                  { label: "SECURITY",   pct: 97,  col: G },
                ].map(b => (
                  <div key={b.label}>
                    <div className="flex justify-between text-[9px] mb-0.5">
                      <span style={{ color: D }}>{b.label}</span>
                      <span style={{ color: b.col }}>{b.pct}%</span>
                    </div>
                    <div className="h-1 rounded-full" style={{ background: "#1A3A1A" }}>
                      <div className="h-1 rounded-full" style={{ width: `${b.pct}%`, background: b.col, boxShadow: `0 0 4px ${b.col}` }} />
                    </div>
                  </div>
                ))}
              </div>
              <div className="border-t pt-1.5 text-[10px] text-center" style={{ borderColor: "#00ff4122", color: D }}>
                <Blink>▶</Blink> <span style={{ color: G }}>UTTARAKHAND SERVER: MIGRATION READY</span>
              </div>
            </div>
          </div>
        </div>

        {/* FOOTER NAV */}
        <div className="grid grid-cols-3 border rounded-sm overflow-hidden" style={{ borderColor: "#00ff4133" }}>
          {[
            { label: "विवरण [STATUS]",     action: () => runCmd("status") },
            { label: "क्विक लोड [BANKING]", action: () => navigate("/banking") },
            { label: "सेटिंग [ADMIN]",      action: () => navigate("/admin") },
          ].map((b, i) => (
            <button key={i} onClick={b.action}
              className="py-2 text-xs font-bold border-r last:border-r-0 transition-all hover:bg-green-950/50"
              style={{ borderColor: "#00ff4133", color: G }}>
              {b.label}
            </button>
          ))}
        </div>

      </div>

      <style>{`@keyframes pulse{0%,100%{opacity:1}50%{opacity:.3}}`}</style>
    </div>
  );
}
