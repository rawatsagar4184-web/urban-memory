import { useState, useRef } from "react";
import { useLocation } from "wouter";
import {
  Search, Mic, QrCode, Clock, MapPin, Briefcase, Plus,
  Home, Bell, Settings, ChevronRight, TrendingUp,
  BookOpen, Globe, Swords, BarChart2, Leaf, Zap,
} from "lucide-react";

// ── Quick action tiles ────────────────────────────────────────────────────
const QUICK = [
  { icon: Clock,     label: "आज के कार्य",    route: "/admin"    },
  { icon: MapPin,    label: "लोकेशन",          route: "/gov"      },
  { icon: Briefcase, label: "कार्य और यात्रा", route: "/skills"   },
  { icon: Plus,      label: "नया जोड़ें",       route: "/admin"    },
];

// ── News categories ───────────────────────────────────────────────────────
const CATS = ["आपके लिए","संस्कृति","विश्व","खेल","व्यापार","रक्षा","विज्ञान","कृषि"];

// ── Mock news cards ───────────────────────────────────────────────────────
const NEWS: Record<string, { cat: string; badge: string; title: string; sub: string; bg: string; route: string }[]> = {
  "आपके लिए": [
    { cat:"संस्कृति", badge:"समय की कहानी",   title:"श्री राम दरबार — संस्कृति, परंपरा और कला का भव्य विवरण।",  sub:"भारतीय कला और संस्कृति का अनूठा संगम", bg:"from-orange-800 to-orange-500", route:"/academy"  },
    { cat:"वंदे भारत",badge:"वंदे भारत",       title:"परंपरा और आधुनिकता का शानदार संगम — एक झलक",              sub:"रेल मंत्रालय, भारत सरकार",              bg:"from-blue-800 to-blue-500",   route:"/gov"      },
    { cat:"कृषि",     badge:"किसान हित",       title:"प्राकृतिक खेती से दोगुनी आय — उत्तराखंड के किसानों की कहानी", sub:"SAB कृषि मित्र विशेष रिपोर्ट",      bg:"from-green-800 to-green-600", route:"/krishi"   },
    { cat:"SAB",      badge:"SAB Coin",         title:"SAB Pay से अब UPI payment — 100 SAB = ₹1 की दर स्थायी",    sub:"SAB Blockchain Network",                bg:"from-amber-700 to-amber-500", route:"/wallet"   },
    { cat:"शिक्षा",  badge:"IAS तैयारी",      title:"उत्तराखंड के युवाओं की IAS सफलता — कैसे बदली ज़िंदगी",     sub:"SAB IAS/IPS Academy",                  bg:"from-purple-800 to-purple-600", route:"/academy" },
    { cat:"सुरक्षा", badge:"साइबर सुरक्षा",  title:"डिजिटल India में अपना डेटा कैसे सुरक्षित रखें",            sub:"SAB Cyber Shield टीम",                bg:"from-red-900 to-red-700",     route:"/security" },
  ],
  "संस्कृति": [
    { cat:"संस्कृति", badge:"धरोहर",   title:"उत्तराखंड की लोक परंपराएं — जीवंत विरासत", sub:"SAB Culture Hub", bg:"from-orange-700 to-red-600",  route:"/academy" },
    { cat:"कला",      badge:"कला मेला", title:"पहाड़ी लोक नृत्य और संगीत का महोत्सव",     sub:"SAB Cultural Events",bg:"from-amber-700 to-yellow-600",route:"/creator" },
  ],
  "विश्व": [
    { cat:"विश्व",  badge:"अंतर्राष्ट्रीय", title:"भारत की वैश्विक कूटनीति — नई ऊंचाइयां",  sub:"विदेश मंत्रालय", bg:"from-blue-900 to-cyan-700",  route:"/gov"      },
    { cat:"G20",   badge:"G20 Summit",       title:"G20 में भारत की भूमिका — विश्व नेतृत्व", sub:"SAB World Desk", bg:"from-indigo-800 to-blue-700", route:"/gov"      },
  ],
  "खेल": [
    { cat:"खेल",    badge:"क्रिकेट",   title:"Team India की शानदार जीत — भारत ने रचा इतिहास", sub:"SAB Sports Desk", bg:"from-green-700 to-emerald-500",route:"/social" },
    { cat:"कुश्ती", badge:"ओलंपिक",   title:"उत्तराखंड के पहलवान ने जीता स्वर्ण",            sub:"SAB Sports Live", bg:"from-yellow-700 to-orange-600",route:"/social" },
  ],
  "व्यापार": [
    { cat:"व्यापार",badge:"SAB Economy",title:"SAB Exchange पर आज के प्रमुख क्रिप्टो रेट",    sub:"SAB Exchange Live",bg:"from-emerald-800 to-teal-600",  route:"/exchange" },
    { cat:"MSM",    badge:"MSME हित",   title:"छोटे व्यापारियों के लिए सरकारी योजनाएं",         sub:"SAB Business Hub", bg:"from-blue-700 to-indigo-700",  route:"/skills"   },
  ],
  "रक्षा": [
    { cat:"सेना",  badge:"वीर भूमि",  title:"उत्तराखंड के जवानों की वीरगाथा",            sub:"SAB Defence Desk", bg:"from-gray-800 to-slate-700",   route:"/security" },
    { cat:"DRDO",  badge:"रक्षा तकनीक",title:"DRDO का नया मिसाइल सिस्टम — भारत की शक्ति", sub:"SAB Tech News",    bg:"from-stone-800 to-zinc-700",   route:"/security" },
  ],
  "विज्ञान": [
    { cat:"ISRO",  badge:"अंतरिक्ष",  title:"ISRO का अगला मिशन — चंद्रयान-4 की तैयारी",  sub:"SAB Science Desk", bg:"from-violet-900 to-purple-700", route:"/academy"  },
    { cat:"AI",    badge:"AI क्रांति", title:"भारत में Artificial Intelligence की नई लहर",  sub:"SAB Tech",         bg:"from-blue-900 to-violet-700",  route:"/voice"    },
  ],
  "कृषि": [
    { cat:"कृषि",  badge:"फसल", title:"खरीफ सीजन में बेहतर उपज के टिप्स", sub:"SAB Krishi Mitra", bg:"from-lime-800 to-green-600",    route:"/krishi" },
    { cat:"MSP",   badge:"MSP", title:"2025-26 के लिए MSP दरें घोषित",    sub:"कृषि मंत्रालय",   bg:"from-green-900 to-emerald-700", route:"/krishi" },
  ],
};

// ── Bottom nav ────────────────────────────────────────────────────────────
const BOTTOM_NAV = [
  { icon: Home,      label: "होम",       route: "/"        },
  { icon: Search,    label: "खोज",       route: "/academy" },
  { icon: Bell,      label: "सूचनाएं",  route: "/social"  },
  { icon: Zap,       label: "AI खुशी",  route: "/voice"   },
  { icon: Settings,  label: "सेटिंग्स", route: "/admin"   },
];

// ── Search suggestions ────────────────────────────────────────────────────
const SUGGESTIONS = [
  { q: "बैंक खाता खोलें",     route: "/banking"  },
  { q: "SAB Wallet balance",   route: "/wallet"   },
  { q: "IAS परीक्षा तैयारी",  route: "/academy"  },
  { q: "किसान योजनाएं",        route: "/krishi"   },
  { q: "UPI payment",          route: "/wallet"   },
  { q: "Cyber security tips",  route: "/security" },
];

export function SABHome() {
  const [, navigate] = useLocation();
  const [activeCat, setActiveCat] = useState("आपके लिए");
  const [query, setQuery] = useState("");
  const [showSuggest, setShowSuggest] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  const news = NEWS[activeCat] ?? NEWS["आपके लिए"];
  const filtered = query
    ? SUGGESTIONS.filter(s => s.q.toLowerCase().includes(query.toLowerCase()))
    : SUGGESTIONS;

  const greet = () => {
    const h = new Date().getHours();
    if (h < 12) return "शुभ प्रभात 🌅";
    if (h < 17) return "शुभ दोपहर ☀️";
    return "शुभ संध्या 🌙";
  };

  return (
    <div className="min-h-screen bg-[#F5F0EB] flex flex-col" style={{ fontFamily: "'Noto Sans Devanagari', sans-serif" }}>

      {/* ── HERO / HEADER SECTION ─────────────────────────────────────────── */}
      <div className="relative overflow-hidden" style={{ minHeight: 260 }}>
        {/* Mountain sunset gradient background */}
        <div className="absolute inset-0"
          style={{ background: "linear-gradient(180deg, #1A1F5C 0%, #3D2B6B 20%, #8B2E2E 45%, #CC5200 65%, #FF8C00 78%, #FFB347 88%, #FFC87A 100%)" }} />
        {/* Mountain silhouette */}
        <svg className="absolute bottom-0 left-0 w-full" viewBox="0 0 400 80" preserveAspectRatio="none">
          <path d="M0,80 L0,50 L40,20 L80,45 L120,15 L160,40 L200,10 L240,35 L280,5 L320,30 L360,18 L400,38 L400,80 Z" fill="#1a0a0055" />
          <path d="M0,80 L0,60 L50,35 L90,55 L130,28 L170,52 L210,22 L250,48 L290,18 L330,42 L370,28 L400,50 L400,80 Z" fill="#00000033" />
        </svg>
        {/* Light overlay at top */}
        <div className="absolute inset-0" style={{ background: "linear-gradient(180deg, rgba(26,31,92,0.3) 0%, transparent 50%)" }} />

        {/* Content over hero */}
        <div className="relative z-10 px-4 pt-4 pb-6">
          {/* Top bar */}
          <div className="flex items-center justify-between mb-4">
            <div>
              <div className="text-white text-xl font-bold drop-shadow-lg">सबसे आगे भारत</div>
              <div className="text-orange-200 text-sm font-medium">AI खुशी 🪔</div>
            </div>
            <div className="flex items-center gap-2">
              <button className="bg-white/20 backdrop-blur-sm border border-white/30 rounded-full px-3 py-1.5 text-white text-xs font-medium flex items-center gap-1.5 hover:bg-white/30 transition-all"
                onClick={() => navigate("/voice")}>
                🪴 प्रसाद लें
              </button>
            </div>
          </div>

          {/* Search bar */}
          <div className="relative">
            <div className="bg-white rounded-2xl shadow-xl flex items-center gap-2 px-4 py-3">
              <button onClick={() => navigate("/wallet")} className="shrink-0">
                <QrCode className="w-5 h-5 text-[#FF6B35]" />
              </button>
              <input
                ref={inputRef}
                value={query}
                onChange={e => setQuery(e.target.value)}
                onFocus={() => setShowSuggest(true)}
                onBlur={() => setTimeout(() => setShowSuggest(false), 150)}
                onKeyDown={e => { if (e.key === "Enter" && filtered[0]) navigate(filtered[0].route); }}
                placeholder="कमांड, सेवाएं या जानकारी खोजें"
                className="flex-1 text-sm text-gray-700 placeholder-gray-400 outline-none bg-transparent"
              />
              <button onClick={() => navigate("/voice")} className="shrink-0">
                <Mic className="w-5 h-5 text-[#1A1F5C]" />
              </button>
            </div>
            {/* Search suggestions dropdown */}
            {showSuggest && filtered.length > 0 && (
              <div className="absolute top-full mt-1 left-0 right-0 bg-white rounded-xl shadow-2xl border border-gray-100 overflow-hidden z-50">
                {filtered.map((s, i) => (
                  <button key={i} className="w-full flex items-center gap-3 px-4 py-2.5 text-sm text-left hover:bg-orange-50 transition-colors"
                    onMouseDown={() => navigate(s.route)}>
                    <Search className="w-3.5 h-3.5 text-gray-400 shrink-0" />
                    <span className="text-gray-700">{s.q}</span>
                    <ChevronRight className="w-3.5 h-3.5 text-gray-300 ml-auto" />
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Quick action tiles */}
          <div className="flex gap-3 mt-4 justify-center">
            {QUICK.map((q) => {
              const Icon = q.icon;
              return (
                <button key={q.label} onClick={() => navigate(q.route)}
                  className="flex flex-col items-center gap-1 group">
                  <div className="w-12 h-12 rounded-full bg-white/20 backdrop-blur-sm border border-white/30 flex items-center justify-center group-hover:bg-white/35 transition-all shadow-lg">
                    <Icon className="w-5 h-5 text-white" />
                  </div>
                  <span className="text-white text-[10px] font-medium drop-shadow text-center max-w-[52px] leading-tight">{q.label}</span>
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* ── NEWS SECTION ──────────────────────────────────────────────────── */}
      <div className="flex-1 bg-[#F5F0EB] rounded-t-2xl -mt-3 relative z-10">

        {/* Category tabs */}
        <div className="overflow-x-auto no-scrollbar border-b border-orange-200/60 bg-white rounded-t-2xl shadow-sm">
          <div className="flex px-2 pt-1">
            {CATS.map(c => (
              <button key={c} onClick={() => setActiveCat(c)}
                className={`shrink-0 px-3 py-2.5 text-sm font-medium transition-all whitespace-nowrap ${
                  activeCat === c
                    ? "text-[#FF6B35] border-b-2 border-[#FF6B35]"
                    : "text-gray-500 hover:text-gray-700"
                }`}>
                {c}
              </button>
            ))}
            <button className="shrink-0 px-2 py-2.5 text-gray-400">•••</button>
          </div>
        </div>

        {/* Section header */}
        <div className="flex items-center justify-between px-4 py-3 bg-white border-b border-gray-100">
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 rounded-full bg-[#FF6B35] animate-pulse" />
            <span className="text-sm font-bold text-gray-800">{greet()}</span>
          </div>
          <button className="text-xs text-[#1A1F5C] font-medium flex items-center gap-1 border border-[#1A1F5C]/20 rounded-full px-3 py-1"
            onClick={() => setActiveCat(CATS[(CATS.indexOf(activeCat) + 1) % CATS.length])}>
            और देखें <ChevronRight className="w-3 h-3" />
          </button>
        </div>

        {/* News cards grid */}
        <div className="px-3 py-3 grid grid-cols-2 gap-3 pb-24">
          {news.map((item, i) => (
            <button key={i} onClick={() => navigate(item.route)}
              className="rounded-2xl overflow-hidden shadow-md bg-white text-left hover:scale-[1.02] transition-transform active:scale-95">
              {/* Card image area */}
              <div className={`h-24 bg-gradient-to-br ${item.bg} relative flex items-end p-2`}>
                <span className="text-[9px] bg-white/20 backdrop-blur-sm text-white px-1.5 py-0.5 rounded-full font-medium border border-white/30">
                  {item.badge}
                </span>
              </div>
              {/* Card text */}
              <div className="p-2.5 space-y-1">
                <div className="text-[10px] text-[#FF6B35] font-semibold uppercase tracking-wide">{item.cat}</div>
                <div className="text-xs font-bold text-gray-800 leading-snug line-clamp-3">{item.title}</div>
                <div className="text-[10px] text-gray-400 truncate">{item.sub}</div>
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* ── FLOATING SERVICES RIBBON ─────────────────────────────────────── */}
      <div className="fixed left-0 right-0 z-30" style={{ bottom: 64 }}>
        <div className="mx-3">
          <div className="bg-white/95 backdrop-blur-md rounded-2xl shadow-lg border border-gray-100 px-4 py-2.5 flex items-center justify-around">
            {[
              { icon: "🏦", label: "Banking",  route: "/banking"  },
              { icon: "💎", label: "Wallet",   route: "/wallet"   },
              { icon: "📚", label: "शिक्षा",  route: "/academy"  },
              { icon: "🌾", label: "Krishi",   route: "/krishi"   },
              { icon: "⚡", label: "Exchange", route: "/exchange" },
              { icon: "🛡", label: "Command",  route: "/command"  },
            ].map(s => (
              <button key={s.label} onClick={() => navigate(s.route)}
                className="flex flex-col items-center gap-0.5 hover:opacity-75 transition-opacity">
                <span className="text-lg">{s.icon}</span>
                <span className="text-[9px] text-gray-500 font-medium">{s.label}</span>
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* ── BOTTOM NAV ───────────────────────────────────────────────────── */}
      <div className="fixed bottom-0 left-0 right-0 z-40 bg-white border-t border-gray-200 shadow-xl">
        <div className="flex items-center justify-around px-2 py-2">
          {BOTTOM_NAV.map(n => {
            const Icon = n.icon;
            const active = n.route === "/";
            return (
              <button key={n.label} onClick={() => navigate(n.route)}
                className={`flex flex-col items-center gap-0.5 px-3 py-1 rounded-xl transition-all ${active ? "text-[#FF6B35]" : "text-gray-500"}`}>
                <Icon className={`w-5 h-5 ${active ? "fill-orange-100" : ""}`} />
                <span className="text-[10px] font-medium">{n.label}</span>
                {active && <div className="w-1 h-1 rounded-full bg-[#FF6B35]" />}
              </button>
            );
          })}
        </div>
      </div>

      <style>{`
        .no-scrollbar::-webkit-scrollbar { display: none; }
        .no-scrollbar { -ms-overflow-style: none; scrollbar-width: none; }
        .line-clamp-3 { display: -webkit-box; -webkit-line-clamp: 3; -webkit-box-orient: vertical; overflow: hidden; }
      `}</style>
    </div>
  );
}
