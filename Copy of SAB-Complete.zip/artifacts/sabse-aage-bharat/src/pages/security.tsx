import { useGetSecurityStatus, useGetDisasterAlert } from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { ShieldAlert, ShieldCheck, Activity, AlertTriangle, Lock, Server, Network, Shield } from "lucide-react";

export function Security() {
  const { data: status, isLoading: loadingStatus } = useGetSecurityStatus();
  const { data: alerts, isLoading: loadingAlerts } = useGetDisasterAlert();

  return (
    <div className="space-y-8">
      <div className="flex items-center gap-3">
        <Shield className="w-10 h-10 text-primary" />
        <div>
          <h1 className="text-3xl font-bold tracking-tight text-primary">Bharat Cyber Wall</h1>
          <p className="text-muted-foreground mt-1">National security dashboard and real-time sovereign defense.</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* CYBER WALL STATUS - SPANS 7 COLS */}
        <div className="lg:col-span-7 space-y-6">
          <Card className="border-primary/30 shadow-lg overflow-hidden relative">
            {/* Animated scanning line effect overlay */}
            <div className="absolute inset-0 bg-[linear-gradient(transparent_0%,rgba(26,31,92,0.05)_50%,transparent_100%)] bg-[length:100%_4px] pointer-events-none opacity-50"></div>
            
            <CardHeader className="bg-primary/5 pb-4 border-b border-primary/10">
              <div className="flex justify-between items-center">
                <CardTitle className="flex items-center gap-2 text-primary text-xl">
                  <ShieldCheck className="w-6 h-6" />
                  Cyber Defense Matrix
                </CardTitle>
                {status?.cyberWallActive ? (
                  <Badge className="bg-success hover:bg-success text-white px-3 py-1 flex items-center gap-1.5 shadow-sm animate-in fade-in zoom-in" data-testid="badge-wall-active">
                    <span className="w-2 h-2 rounded-full bg-white animate-pulse"></span>
                    ACTIVE & SECURE
                  </Badge>
                ) : (
                  <Badge variant="destructive" className="animate-pulse">WARNING: WALL OFFLINE</Badge>
                )}
              </div>
            </CardHeader>
            <CardContent className="pt-6">
              {loadingStatus ? (
                <Skeleton className="h-64 w-full" data-testid="skeleton-security-status" />
              ) : status && (
                <div className="space-y-8">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="bg-background border rounded-lg p-4 flex items-start gap-4">
                      <div className="bg-destructive/10 p-3 rounded-full shrink-0">
                        <ShieldAlert className="w-6 h-6 text-destructive" />
                      </div>
                      <div>
                        <p className="text-xs text-muted-foreground font-bold uppercase tracking-wider mb-1">Threats Blocked</p>
                        <p className="text-3xl font-black text-foreground" data-testid="stat-ddos">{status.ddosBlocked.toLocaleString()}</p>
                        <p className="text-xs text-destructive font-medium mt-1">DDoS / Intrusion</p>
                      </div>
                    </div>
                    
                    <div className="bg-background border rounded-lg p-4 flex items-start gap-4">
                      <div className="bg-success/10 p-3 rounded-full shrink-0">
                        <Network className="w-6 h-6 text-success" />
                      </div>
                      <div>
                        <p className="text-xs text-muted-foreground font-bold uppercase tracking-wider mb-1">Active P2P Nodes</p>
                        <p className="text-3xl font-black text-success" data-testid="stat-nodes">{status.nodesOnline.toLocaleString()}</p>
                        <p className="text-xs text-muted-foreground mt-1">Global coverage</p>
                      </div>
                    </div>
                  </div>

                  <div className="grid grid-cols-3 gap-4 border-t pt-6">
                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <Lock className="w-4 h-4 text-primary" />
                        <p className="text-xs text-muted-foreground font-bold uppercase tracking-wider">Encryption</p>
                      </div>
                      <p className="font-bold font-mono text-lg">{status.encryptionLevel}</p>
                    </div>
                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <Server className="w-4 h-4 text-primary" />
                        <p className="text-xs text-muted-foreground font-bold uppercase tracking-wider">Compression</p>
                      </div>
                      <p className="font-bold font-mono text-lg">{status.compressionRatio}</p>
                    </div>
                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <Activity className="w-4 h-4 text-success" />
                        <p className="text-xs text-muted-foreground font-bold uppercase tracking-wider">System State</p>
                      </div>
                      <p className="font-bold text-success capitalize">{status.backupStatus}</p>
                    </div>
                  </div>

                  <div className="bg-muted/50 p-3 rounded-md border border-border/50 text-xs flex items-center justify-between">
                    <span className="text-muted-foreground">Last threat neutralized:</span>
                    <span className="font-mono font-medium">{new Date(status.lastThreatAt).toLocaleString()}</span>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* DISASTER ALERTS - SPANS 5 COLS */}
        <div className="lg:col-span-5">
          <Card className="border-destructive/20 h-full flex flex-col shadow-md">
            <CardHeader className="bg-destructive/5 pb-4 border-b border-destructive/10">
              <CardTitle className="flex items-center gap-2 text-destructive text-lg">
                <AlertTriangle className="w-5 h-5" />
                National Disaster Alerts
              </CardTitle>
              <CardDescription>Real-time early warning system / वास्तविक समय चेतावनी</CardDescription>
            </CardHeader>
            <CardContent className="pt-4 flex-1 overflow-auto">
              {loadingAlerts ? (
                <div className="space-y-4">
                  <Skeleton className="h-24 w-full" />
                  <Skeleton className="h-24 w-full" />
                </div>
              ) : alerts?.alerts && alerts.alerts.length > 0 ? (
                <div className="space-y-4">
                  {alerts.alerts.map((alert) => (
                    <div key={alert.id} className={`p-4 rounded-lg border-l-4 shadow-sm relative overflow-hidden ${
                      alert.severity === 'critical' ? 'bg-destructive/5 border-l-destructive border-y-border border-r-border text-foreground' :
                      alert.severity === 'high' ? 'bg-orange-500/5 border-l-orange-500 border-y-border border-r-border text-foreground' :
                      'bg-yellow-500/5 border-l-yellow-500 border-y-border border-r-border text-foreground'
                    }`} data-testid={`alert-card-${alert.id}`}>
                      {alert.severity === 'critical' && <div className="absolute top-0 right-0 w-16 h-16 bg-destructive/10 rounded-bl-full -mr-8 -mt-8 pointer-events-none"></div>}
                      
                      <div className="flex justify-between items-start mb-2 relative z-10">
                        <h3 className="font-bold capitalize text-base flex items-center gap-2">
                          {alert.type}
                        </h3>
                        <Badge variant="outline" className={`uppercase font-bold text-[10px] ${
                          alert.severity === 'critical' ? 'text-destructive border-destructive bg-destructive/10' :
                          alert.severity === 'high' ? 'text-orange-600 border-orange-500 bg-orange-500/10' :
                          'text-yellow-600 border-yellow-500 bg-yellow-500/10'
                        }`}>{alert.severity}</Badge>
                      </div>
                      <p className="text-sm font-semibold mb-1 flex items-center gap-1.5 relative z-10">
                        <span className="w-1.5 h-1.5 rounded-full bg-current"></span>
                        {alert.location}
                      </p>
                      <p className="text-sm text-muted-foreground leading-relaxed relative z-10">{alert.message}</p>
                      <p className="text-[10px] font-mono opacity-60 mt-3 pt-2 border-t relative z-10">{new Date(alert.timestamp).toLocaleString()}</p>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="flex flex-col items-center justify-center h-full min-h-[300px] text-muted-foreground" data-testid="no-alerts-state">
                  <div className="w-16 h-16 bg-success/10 rounded-full flex items-center justify-center mb-4">
                    <ShieldCheck className="w-8 h-8 text-success" />
                  </div>
                  <p className="font-bold text-foreground">No Active Alerts</p>
                  <p className="text-sm mt-1">The nation is secure.</p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
