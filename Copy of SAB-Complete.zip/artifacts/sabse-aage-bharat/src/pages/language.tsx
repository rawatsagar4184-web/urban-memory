import { useGetLanguageCourses, useTranslateText } from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Languages, ArrowRightLeft } from "lucide-react";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { useState } from "react";

const translateSchema = z.object({
  text: z.string().min(1, "Text is required"),
  targetLanguage: z.string().min(1, "Language is required"),
});

export function Language() {
  const { data: courses, isLoading: loadingCourses } = useGetLanguageCourses();
  const translateMutation = useTranslateText();
  const [translationResult, setTranslationResult] = useState<{ translated: string; confidence: number } | null>(null);

  const form = useForm<z.infer<typeof translateSchema>>({
    resolver: zodResolver(translateSchema),
    defaultValues: {
      text: "",
      targetLanguage: "hindi",
    },
  });

  const onSubmit = (values: z.infer<typeof translateSchema>) => {
    translateMutation.mutate({ 
      data: { text: values.text, targetLanguage: values.targetLanguage } 
    }, {
      onSuccess: (data) => {
        setTranslationResult({ translated: data.translated, confidence: data.confidence });
      }
    });
  };

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold tracking-tight text-primary">Global Language Academy</h1>
        <p className="text-muted-foreground mt-2">Hindi-first language courses and real-time sovereign translation.</p>
      </div>

      <Card className="bg-gradient-to-r from-primary/10 to-secondary/10 border-none shadow-md">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Languages className="w-5 h-5 text-secondary" />
            Real-time Translation / वास्तविक समय अनुवाद
          </CardTitle>
          <CardDescription>Powered by Khushi AI - translating global languages to Bharatiya bhashas</CardDescription>
        </CardHeader>
        <CardContent>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-[1fr_auto_1fr] gap-4 items-center">
                <FormField
                  control={form.control}
                  name="text"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Enter Text (English)</FormLabel>
                      <FormControl>
                        <Input placeholder="Type something to translate..." {...field} data-testid="input-translate-text" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <div className="hidden md:flex mt-6 justify-center">
                  <div className="bg-background p-2 rounded-full shadow-sm">
                    <ArrowRightLeft className="w-5 h-5 text-muted-foreground" />
                  </div>
                </div>

                <FormField
                  control={form.control}
                  name="targetLanguage"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Target Language</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger data-testid="select-target-lang">
                            <SelectValue placeholder="Select a language" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="hindi">Hindi / हिन्दी</SelectItem>
                          <SelectItem value="pahadi">Pahari / पहाड़ी</SelectItem>
                          <SelectItem value="marathi">Marathi / मराठी</SelectItem>
                          <SelectItem value="bengali">Bengali / मराठी</SelectItem>
                          <SelectItem value="tamil">Bengali / বাংলা</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              
              <Button type="submit" disabled={translateMutation.isPending} className="w-full md:w-auto" data-testid="button-translate">
                Translate Now / अनुवाद करें
              </Button>
            </form>
          </Form>

          {translationResult && (
            <div className="mt-6 p-6 bg-background rounded-lg border border-primary/20 shadow-inner" data-testid="result-translation">
              <p className="text-sm text-muted-foreground mb-1 uppercase tracking-wider font-bold">Result</p>
              <p className="text-2xl font-bold text-primary mb-2">{translationResult.translated}</p>
              <p className="text-xs text-success font-mono flex items-center gap-1">
                AI Confidence: {(translationResult.confidence * 100).toFixed(1)}%
              </p>
            </div>
          )}
        </CardContent>
      </Card>

      <div>
        <h2 className="text-xl font-semibold mb-6 flex items-center gap-2">
          Language Courses / भाषा पाठ्यक्रम
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {loadingCourses ? (
            Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-48 w-full" data-testid={`skeleton-course-${i}`} />)
          ) : courses?.courses.map((course) => (
            <Card key={course.id} className="hover:shadow-lg transition-all" data-testid={`card-lang-course-${course.id}`}>
              <CardHeader className="text-center pb-2">
                <div className="text-6xl mb-4" data-testid={`flag-${course.id}`}>{course.flag}</div>
                <CardTitle>{course.language}</CardTitle>
                <Badge variant="outline" className="w-fit mx-auto mt-2">{course.level}</Badge>
              </CardHeader>
              <CardContent className="text-center">
                <p className="text-xs text-muted-foreground mb-4 line-clamp-2">{course.description}</p>
                <p className="text-sm font-semibold mb-4">{course.enrolled.toLocaleString()} learners</p>
                <Button className="w-full" variant="secondary" data-testid={`button-learn-${course.id}`}>Start Learning</Button>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
}
