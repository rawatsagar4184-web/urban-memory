import { useState, useEffect } from "react";
import { useGetSystemStatus, getGetSystemStatusQueryKey, useKillSwitch } from "@workspace/api-client-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { ShieldAlert, Power, Play, Save, Activity, Server, Users, Wifi } from "lucide-react";
import { useQueryClient } from "@tanstack/react-query";
import SABSovereignGate from "@/components/SABSovereignGate";

/* Live user stats from server */
interface SAB_LiveStats {
  liveCount: number;
  totalSessions: number;
  pages: Record<string, number>;
  updatedAt: string;
}

function useLiveStats() {
  const [stats, setStats] = useState<SAB_LiveStats | null>(null);
  useEffect(() => {
    let active = true;
    const poll = async () => {
      try {
        const res = await fetch("/api/admin/live");
        if (res.ok && active) setStats(await res.json() as SAB_LiveStats);
      } catch { /* offline */ }
    };
    void poll();
    const t = setInterval(() => { void poll(); }, 10_000);
    return () => { active = false; clearInterval(t); };
  }, []);
  return stats;
}

function LiveUserPanel({ stats }: { stats: SAB_LiveStats | null }) {
  return (
    <Card className="border-2 border-primary/30 bg-gradient-to-br from-primary/5 to-secondary/5">
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center gap-2 text-primary text-lg">
          <Users className="w-5 h-5 text-secondary" />
          Live Users — अभी App पर
        </CardTitle>
        <CardDescription>Real-time active session count (10-minute window)</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="flex items-end gap-3 mb-4">
          <span className="text-6xl font-black text-secondary tabular-nums">
            {stats?.liveCount ?? "—"}
          </span>
          <div className="pb-2">
            <div className="flex items-center gap-1 text-green-500 text-sm font-medium">
              <Wifi className="w-3 h-3" />
              Live
            </div>
            <div className="text-xs text-muted-foreground">active users</div>
          </div>
        </div>

        {stats && (
          <>
            <div className="grid grid-cols-2 gap-2 mb-3">
              <div className="bg-background rounded-lg p-3 border">
                <div className="text-xs text-muted-foreground mb-1">Total Sessions</div>
                <div className="font-bold text-foreground">{stats.totalSessions}</div>
              </div>
              <div className="bg-background rounded-lg p-3 border">
                <div className="text-xs text-muted-foreground mb-1">Active Pages</div>
                <div className="font-bold text-foreground">{Object.keys(stats.pages).length}</div>
              </div>
            </div>

            {Object.keys(stats.pages).length > 0 && (
              <div className="space-y-1">
                <div className="text-xs text-muted-foreground font-medium mb-2">Page Breakdown</div>
                {Object.entries(stats.pages)
                  .sort((a, b) => b[1] - a[1])
                  .map(([page, count]) => (
                    <div key={page} className="flex items-center gap-2 text-xs">
                      <div
                        className="h-1.5 rounded-full bg-primary/60 flex-shrink-0"
                        style={{ width: `${Math.max(8, (count / (stats.liveCount || 1)) * 80)}px` }}
                      />
                      <span className="text-muted-foreground font-mono">{page}</span>
                      <span className="ml-auto font-bold text-foreground">{count}</span>
                    </div>
                  ))}
              </div>
            )}

            <div className="text-xs text-muted-foreground mt-3 pt-2 border-t">
              Updated: {new Date(stats.updatedAt).toLocaleTimeString("hi-IN")}
            </div>
          </>
        )}

        {!stats && (
          <Alert>
            <AlertDescription className="text-xs">
              Server से data load हो रहा है...
            </AlertDescription>
          </Alert>
        )}
      </CardContent>
    </Card>
  );
}

function AdminPanelInner() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [ownerKey, setOwnerKey] = useState("");
  const liveStats = useLiveStats();

  const { data: status, isLoading } = useGetSystemStatus({
    query: { queryKey: getGetSystemStatusQueryKey(), refetchInterval: 5000 }
  });

  const killSwitch = useKillSwitch();

  const handleAction = (action: "freeze" | "unfreeze" | "backup") => {
    if (!ownerKey) {
      toast({ title: "Authentication Required", description: "Please enter the OWNER_MASTER_KEY", variant: "destructive" });
      return;
    }
    killSwitch.mutate({ data: { action, ownerKey } }, {
      onSuccess: (res) => {
        toast({ title: "Command Executed", description: res.message });
        queryClient.invalidateQueries({ queryKey: ["/api/admin/status"] });
        queryClient.invalidateQueries({ queryKey: ["/api/blockchain/stats"] });
        if (action !== "backup") setOwnerKey("");
      },
      onError: (err: unknown) => {
        const msg = err instanceof Error ? err.message : "Invalid Key or system error";
        toast({ title: "Command Failed", description: msg, variant: "destructive" });
      }
    });
  };

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500 max-w-4xl mx-auto">
      <div>
        <h2 className="text-3xl font-bold tracking-tight text-foreground flex items-center gap-3">
          <ShieldAlert className="w-8 h-8 text-primary" />
          Owner Control Panel
        </h2>
        <p className="text-muted-foreground mt-2">Sagar Bhai का सर्वोच्च नियंत्रण केंद्र — SAB Network</p>
      </div>

      {/* Live Users — top row */}
      <LiveUserPanel stats={liveStats} />

      {/* System diagnostics */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="md:col-span-2 bg-slate-900 text-slate-50 border-slate-800 shadow-xl">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-slate-100">
              <Server className="w-5 h-5" />
              System Diagnostics
            </CardTitle>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="text-slate-400">Loading diagnostics...</div>
            ) : status ? (
              <div className="grid grid-cols-2 gap-y-6 gap-x-4 font-mono text-sm">
                <div>
                  <p className="text-slate-500 mb-1">System Name</p>
                  <p className="font-bold text-slate-200">{status.systemName}</p>
                </div>
                <div>
                  <p className="text-slate-500 mb-1">Network Owner</p>
                  <p className="font-bold text-secondary">{status.owner}</p>
                </div>
                <div>
                  <p className="text-slate-500 mb-1">Mode</p>
                  <p className="font-bold text-slate-200 uppercase">{status.mode}</p>
                </div>
                <div>
                  <p className="text-slate-500 mb-1">Uptime</p>
                  <p className="font-bold text-slate-200">{Math.floor(status.uptime / 60)} minutes</p>
                </div>
                <div>
                  <p className="text-slate-500 mb-1">Total Blocks</p>
                  <p className="font-bold text-slate-200">{status.totalBlocks}</p>
                </div>
                <div>
                  <p className="text-slate-500 mb-1">Version</p>
                  <p className="font-bold text-slate-200">{status.version}</p>
                </div>
              </div>
            ) : null}
          </CardContent>
        </Card>

        <Card className={`border-2 flex flex-col justify-center items-center p-6 text-center ${status?.isFrozen ? "border-destructive bg-destructive/10" : "border-green-500 bg-green-500/10"}`}>
          <div className="mb-4">
            {status?.isFrozen ? (
              <div className="rounded-full bg-destructive/20 p-4">
                <Power className="w-12 h-12 text-destructive" />
              </div>
            ) : (
              <div className="rounded-full bg-green-500/20 p-4">
                <Activity className="w-12 h-12 text-green-500" />
              </div>
            )}
          </div>
          <h3 className="text-xl font-bold uppercase tracking-widest mb-1">
            {status?.isFrozen ? "System Frozen" : "System Active"}
          </h3>
          <p className="text-sm text-muted-foreground">
            {status?.isFrozen ? "All transactions halted." : "Network running normally."}
          </p>
        </Card>
      </div>

      {/* Kill-switch */}
      <Card className="border-t-4 border-t-destructive shadow-lg overflow-hidden">
        <div className="bg-destructive/10 px-6 py-4 border-b border-destructive/20">
          <CardTitle className="text-destructive flex items-center gap-2 text-xl">
            <ShieldAlert className="w-6 h-6" />
            Kill-Switch & Emergency Protocols
          </CardTitle>
          <CardDescription className="text-foreground/80 mt-1 font-medium">
            Requires Master Key to execute any command.
          </CardDescription>
        </div>
        <CardContent className="p-6 space-y-6">
          <div className="space-y-2">
            <Label htmlFor="ownerKey" className="font-bold text-foreground">OWNER_MASTER_KEY</Label>
            <Input
              id="ownerKey"
              type="password"
              placeholder="Enter master key..."
              value={ownerKey}
              onChange={e => setOwnerKey(e.target.value)}
              className="font-mono text-lg"
            />
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-4 border-t">
            <Button
              variant="destructive"
              className="h-16 text-lg font-bold"
              onClick={() => handleAction("freeze")}
              disabled={killSwitch.isPending || status?.isFrozen}
            >
              <Power className="w-5 h-5 mr-2" /> HALT NETWORK
            </Button>
            <Button
              className="h-16 text-lg font-bold bg-green-600 hover:bg-green-700 text-white"
              onClick={() => handleAction("unfreeze")}
              disabled={killSwitch.isPending || !status?.isFrozen}
            >
              <Play className="w-5 h-5 mr-2" /> RESUME NETWORK
            </Button>
            <Button
              className="h-16 text-lg font-bold bg-primary hover:bg-primary/90 text-primary-foreground"
              onClick={() => handleAction("backup")}
              disabled={killSwitch.isPending}
            >
              <Save className="w-5 h-5 mr-2" /> FORCE BACKUP
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

export function AdminPanel() {
  return (
    <SABSovereignGate>
      <AdminPanelInner />
    </SABSovereignGate>
  );
}
