import { useState } from "react";
import { useTransferSAB } from "@workspace/api-client-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { ArrowRightLeft, CheckCircle2, IndianRupee } from "lucide-react";
import { CopyableHash } from "@/components/copyable-hash";

export function Transfer() {
  const { toast } = useToast();
  const transferSAB = useTransferSAB();
  
  const [fromAddress, setFromAddress] = useState("");
  const [toAddress, setToAddress] = useState("");
  const [amount, setAmount] = useState("");
  const [privateKey, setPrivateKey] = useState("");
  const [result, setResult] = useState<any>(null);

  const handleTransfer = () => {
    if (!fromAddress || !toAddress || !amount || !privateKey) {
      toast({ title: "Missing Fields", description: "All fields are required.", variant: "destructive" });
      return;
    }

    const numAmount = Number(amount);
    if (isNaN(numAmount) || numAmount <= 0) {
      toast({ title: "Invalid Amount", description: "Please enter a valid positive number.", variant: "destructive" });
      return;
    }

    transferSAB.mutate({
      data: {
        fromAddress: fromAddress.trim(),
        toAddress: toAddress.trim(),
        amount: numAmount,
        privateKey: privateKey.trim()
      }
    }, {
      onSuccess: (data) => {
        setResult(data);
        toast({ title: "Transfer Successful", description: `Sent ${numAmount} SAB successfully.` });
        setFromAddress("");
        setToAddress("");
        setAmount("");
        setPrivateKey("");
      },
      onError: (err: any) => {
        toast({ title: "Transfer Failed", description: err.message || "An error occurred", variant: "destructive" });
      }
    });
  };

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500 max-w-2xl mx-auto">
      <div>
        <h2 className="text-3xl font-bold tracking-tight text-foreground">Transfer SAB</h2>
        <p className="text-muted-foreground mt-2">Send SAB Coins securely across the indigenous network.</p>
      </div>

      <Card className="border-t-4 border-t-primary shadow-lg">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <ArrowRightLeft className="w-5 h-5 text-primary" />
            New Transaction
          </CardTitle>
          <CardDescription>Fixed Rate: 100 SAB = Rs.1</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {result && (
            <Alert className="bg-success/10 border-success text-success-foreground mb-6">
              <CheckCircle2 className="h-5 w-5 text-success" />
              <AlertTitle className="text-success font-bold">Transaction Confirmed!</AlertTitle>
              <AlertDescription className="mt-3 space-y-2 text-foreground">
                <div className="flex justify-between border-b border-success/20 pb-2">
                  <span className="text-muted-foreground">Block Index:</span>
                  <span className="font-bold">{result.blockIndex}</span>
                </div>
                <div className="flex justify-between items-center border-b border-success/20 pb-2">
                  <span className="text-muted-foreground">Transaction ID:</span>
                  <CopyableHash hash={result.transactionId} />
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Fee Paid:</span>
                  <span className="font-mono">{result.fee} SAB</span>
                </div>
              </AlertDescription>
            </Alert>
          )}

          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="fromAddress">Sender Address (From)</Label>
              <Input 
                id="fromAddress" 
                placeholder="SAB..." 
                value={fromAddress}
                onChange={e => setFromAddress(e.target.value)}
                data-testid="input-from-address"
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="toAddress">Recipient Address (To)</Label>
              <Input 
                id="toAddress" 
                placeholder="SAB..." 
                value={toAddress}
                onChange={e => setToAddress(e.target.value)}
                data-testid="input-to-address"
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="amount">Amount (SAB)</Label>
                <div className="relative">
                  <Input 
                    id="amount" 
                    type="number" 
                    placeholder="0.00" 
                    value={amount}
                    onChange={e => setAmount(e.target.value)}
                    className="pr-16 text-lg font-mono font-bold"
                    data-testid="input-amount"
                  />
                  <div className="absolute inset-y-0 right-0 flex items-center pr-3 pointer-events-none text-muted-foreground font-bold">
                    SAB
                  </div>
                </div>
              </div>
              <div className="space-y-2">
                <Label>INR Equivalent</Label>
                <div className="h-10 px-3 flex items-center gap-1 bg-muted/50 rounded-md border text-muted-foreground font-mono">
                  <IndianRupee className="w-4 h-4" />
                  {amount ? (Number(amount) / 100).toFixed(2) : "0.00"}
                </div>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="privateKey" className="text-destructive font-bold flex items-center gap-1">
                Private Key
              </Label>
              <Input 
                id="privateKey" 
                type="password" 
                placeholder="Enter sender's private key to sign" 
                value={privateKey}
                onChange={e => setPrivateKey(e.target.value)}
                data-testid="input-private-key"
              />
              <p className="text-xs text-muted-foreground">Required to cryptographically sign the transaction.</p>
            </div>

            <Button 
              className="w-full h-14 text-lg font-bold" 
              size="lg" 
              onClick={handleTransfer}
              disabled={transferSAB.isPending}
              data-testid="button-submit-transfer"
            >
              {transferSAB.isPending ? "Processing..." : "Transfer Now"}
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
