import { useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import {
  useFetchThreatLog,
  getFetchThreatLogQueryKey,
  useFetchThreatStats,
  getFetchThreatStatsQueryKey,
  useFetchBlacklist,
  getFetchBlacklistQueryKey,
  useRemoveFromBlacklist,
  useFetchCertReport,
  getFetchCertReportQueryKey,
} from "@workspace/api-client-react";
import { useToast } from "@/hooks/use-toast";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  ShieldAlert,
  Server,
  Activity,
  FileText,
  Trash2,
  AlertTriangle,
  Siren,
  Globe,
  Database,
  Lock
} from "lucide-react";
import { format } from "date-fns";

export function ThreatIntelligence() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: stats } = useFetchThreatStats({
    query: { queryKey: getFetchThreatStatsQueryKey(), refetchInterval: 5000 },
  });

  const { data: threats } = useFetchThreatLog({
    query: { queryKey: getFetchThreatLogQueryKey(), refetchInterval: 5000 },
  });

  const { data: blacklist, refetch: refetchBlacklist } = useFetchBlacklist({
    query: { queryKey: getFetchBlacklistQueryKey(), refetchInterval: 10000 },
  });

  const removeFromBlacklist = useRemoveFromBlacklist();

  const { data: certReportData, refetch: refetchCert, isFetching: certLoading } = useFetchCertReport(
    undefined,
    { query: { queryKey: getFetchCertReportQueryKey(), enabled: false } }
  );

  const [certReportOpen, setCertReportOpen] = useState(false);

  const handleRemoveIP = (ip: string) => {
    removeFromBlacklist.mutate(
      { ip },
      {
        onSuccess: () => {
          toast({ title: "IP हटाया गया", description: `${ip} blacklist से हटाया गया।` });
          refetchBlacklist();
          queryClient.invalidateQueries({ queryKey: getFetchBlacklistQueryKey() });
        },
        onError: () => {
          toast({ title: "Error", description: "IP हटाने में समस्या हुई।", variant: "destructive" });
        },
      }
    );
  };

  const handleGenerateReport = async () => {
    const result = await refetchCert();
    if (result.data) {
      setCertReportOpen(true);
    } else {
      toast({ title: "रिपोर्ट विफल", description: "CERT-In रिपोर्ट जनरेट नहीं हो सकी।", variant: "destructive" });
    }
  };

  const getLayerColor = (layer: number) => {
    switch (layer) {
      case 1: return "bg-emerald-500/20 text-emerald-700 border-emerald-500/50";
      case 2: return "bg-yellow-500/20 text-yellow-700 border-yellow-500/50";
      case 3: return "bg-orange-500/20 text-orange-700 border-orange-500/50";
      case 4: return "bg-red-500/20 text-red-700 border-red-500/50";
      case 5: return "bg-rose-900/20 text-rose-800 border-rose-900/50 font-bold";
      default: return "bg-muted text-muted-foreground";
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h2 className="text-3xl font-bold tracking-tight text-red-700 dark:text-red-500 flex items-center gap-2">
            <ShieldAlert className="w-8 h-8" />
            Bharat Cyber Shield
          </h2>
          <p className="text-muted-foreground mt-1">
            5-Layer Threat Intelligence Dashboard (भारत साइबर कवच)
          </p>
        </div>
        <div className="flex items-center gap-3">
          <Button variant="outline" className="border-primary text-primary" onClick={handleGenerateReport} disabled={certLoading}>
            <FileText className="w-4 h-4 mr-2" />
            {certLoading ? "तैयार हो रही है..." : "CERT-In Report"}
          </Button>
        </div>
      </div>

      <div className="bg-yellow-500/10 border border-yellow-500/50 rounded-lg p-3 text-sm text-yellow-700 dark:text-yellow-500 flex items-center gap-2 font-medium">
        <Activity className="w-4 h-4" />
        Development Mode — No actual IPs are being monitored. Data is simulated for demonstration.
      </div>

      {/* 10-Layer Architecture Visual */}
      <Card className="bg-slate-950 text-slate-300 border-slate-800">
        <CardHeader className="pb-2">
          <CardTitle className="text-slate-100 flex items-center gap-2">
            <Server className="w-5 h-5" /> 10-Layer Defense Architecture (भारत साइबर कवच)
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          {/* Row 1: L1–L5 */}
          <div className="grid grid-cols-5 gap-1 text-[10px] font-mono text-center">
            {[
              { l: "L1", label: "Edge", sub: "Rate+Geo", color: "emerald", Icon: Globe },
              { l: "L2", label: "WAF", sub: "19 UA Sigs", color: "yellow", Icon: AlertTriangle },
              { l: "L3", label: "Auth", sub: "Token+Session", color: "orange", Icon: Lock },
              { l: "L4", label: "DB Shield", sub: "SQLi+Traversal", color: "red", Icon: Database },
              { l: "L5", label: "Honeypot", sub: "15 Decoys", color: "rose", Icon: Siren },
            ].map(({ l, label, sub, color, Icon }) => (
              <div key={l} className={`bg-${color}-950/50 border border-${color}-500/30 p-2 rounded-md`}>
                <Icon className={`w-4 h-4 mx-auto mb-1 text-${color}-500`} />
                <div className={`text-${color}-400 font-bold`}>{l}: {label}</div>
                <div className="opacity-60 mt-0.5 text-[9px]">{sub}</div>
              </div>
            ))}
          </div>
          <div className="text-center text-slate-600 text-xs">↓ हमला बढ़ता है तो अगली परत ↓</div>
          {/* Row 2: L6–L10 */}
          <div className="grid grid-cols-5 gap-1 text-[10px] font-mono text-center">
            {[
              { l: "L6", label: "Fingerprint", sub: "Header Anomaly", color: "purple" },
              { l: "L7", label: "Behavior", sub: "Bot Patterns", color: "violet" },
              { l: "L8", label: "Canary", sub: "8 Trap Paths", color: "fuchsia" },
              { l: "L9", label: "Time-Pattern", sub: "Off-Hour Burst", color: "pink" },
              { l: "L10", label: "Crypto PoW", sub: "Auto-Blacklist", color: "red" },
            ].map(({ l, label, sub, color }) => (
              <div key={l} className={`bg-${color}-950/50 border border-${color}-500/40 p-2 rounded-md shadow-[0_0_8px_rgba(139,0,0,0.15)]`}>
                <Activity className={`w-4 h-4 mx-auto mb-1 text-${color}-400`} />
                <div className={`text-${color}-300 font-bold`}>{l}: {label}</div>
                <div className="opacity-60 mt-0.5 text-[9px]">{sub}</div>
              </div>
            ))}
          </div>
          <div className="pt-2 border-t border-slate-800 text-[10px] opacity-50 font-mono space-y-0.5">
            <div>Honeypot: /api/admin/secret, /api/.env, /api/credentials, /api/owner/masterkey (+11 more)</div>
            <div>Canary: /api/banking/export, /api/wallet/dump, /api/users/list (+5 more) — L8 auto-blacklist trigger</div>
          </div>
        </CardContent>
      </Card>

      {/* Stats — 8 metrics */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <Card className="border-red-200 bg-red-50">
          <CardContent className="p-3">
            <div className="text-xs font-medium text-red-700 uppercase tracking-wider">कुल खतरे</div>
            <div className="text-2xl font-bold text-red-600 mt-1">{stats?.totalThreats ?? "0"}</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-3">
            <div className="text-xs font-medium text-muted-foreground uppercase">Blacklisted IPs</div>
            <div className="text-2xl font-bold text-primary mt-1">{stats?.blacklistedIPs ?? "0"}</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-3">
            <div className="text-xs font-medium text-muted-foreground uppercase">Honeypot Hits</div>
            <div className="text-2xl font-bold text-primary mt-1">{stats?.honeypotHits ?? "0"}</div>
          </CardContent>
        </Card>
        <Card className="border-fuchsia-200 bg-fuchsia-50">
          <CardContent className="p-3">
            <div className="text-xs font-medium text-fuchsia-700 uppercase">Canary Triggered</div>
            <div className="text-2xl font-bold text-fuchsia-700 mt-1">{(stats as { canaryHits?: number } | undefined)?.canaryHits ?? "0"}</div>
          </CardContent>
        </Card>
        <Card className="border-violet-200 bg-violet-50">
          <CardContent className="p-3">
            <div className="text-xs font-medium text-violet-700 uppercase">Bot Behavior</div>
            <div className="text-2xl font-bold text-violet-700 mt-1">{(stats as { botBehaviorDetected?: number } | undefined)?.botBehaviorDetected ?? "0"}</div>
          </CardContent>
        </Card>
        <Card className="border-pink-200 bg-pink-50">
          <CardContent className="p-3">
            <div className="text-xs font-medium text-pink-700 uppercase">Off-Hour Bursts</div>
            <div className="text-2xl font-bold text-pink-700 mt-1">{(stats as { offHourBursts?: number } | undefined)?.offHourBursts ?? "0"}</div>
          </CardContent>
        </Card>
        <Card className="border-rose-200 bg-rose-50">
          <CardContent className="p-3">
            <div className="text-xs font-medium text-rose-700 uppercase">Layer 8+ Reached</div>
            <div className="text-2xl font-bold text-rose-700 mt-1">{(stats as { layer8Reached?: number } | undefined)?.layer8Reached ?? "0"}</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-3">
            <div className="text-xs font-medium text-muted-foreground uppercase">Active IPs</div>
            <div className="text-2xl font-bold text-primary mt-1">{stats?.activeIPs ?? "0"}</div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Threat Log */}
        <Card className="md:col-span-2">
          <CardHeader>
            <CardTitle className="flex items-center gap-2"><Activity className="w-5 h-5 text-primary" /> Live Threat Log</CardTitle>
            <CardDescription>Real-time monitoring of intercepted threats</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {threats?.threats?.map((threat) => (
                <div key={threat.id} className="flex flex-col md:flex-row md:items-center justify-between p-3 border rounded-lg bg-card gap-2">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 font-mono text-sm">
                      <span className="font-bold">{threat.ip}</span>
                      <span className="text-muted-foreground">({threat.country})</span>
                      {threat.isBlacklisted && <Badge variant="destructive" className="text-[10px] h-4">BLOCKED</Badge>}
                      {threat.honeypotTriggered && <Badge className="bg-rose-500 hover:bg-rose-600 text-[10px] h-4">HONEYPOT</Badge>}
                    </div>
                    <div className="text-xs text-muted-foreground mt-1 font-mono">
                      {threat.method} {threat.path}
                    </div>
                    <div className="text-xs text-muted-foreground mt-1">
                      {format(new Date(threat.timestamp), "PPp")} • {threat.threat}
                    </div>
                  </div>
                  <div className={`px-3 py-1 rounded-md text-xs font-bold border whitespace-nowrap ${getLayerColor(threat.layer)}`}>
                    Layer {threat.layer}
                  </div>
                </div>
              ))}
              {(!threats?.threats || threats.threats.length === 0) && (
                <div className="text-center py-8 text-muted-foreground">No recent threats logged.</div>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Blacklist */}
        <Card>
          <CardHeader>
            <CardTitle className="text-destructive">Blacklisted IPs</CardTitle>
            <CardDescription>Automatically blocked by Layer 5</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {blacklist?.ips?.map((ip) => (
                <div key={ip} className="flex justify-between items-center p-2 border rounded bg-destructive/5 font-mono text-sm">
                  <span>{ip}</span>
                  <Button variant="ghost" size="icon" className="h-6 w-6 text-muted-foreground hover:text-destructive" onClick={() => handleRemoveIP(ip)} disabled={removeFromBlacklist.isPending}>
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              ))}
              {(!blacklist?.ips || blacklist.ips.length === 0) && (
                <div className="text-center py-4 text-sm text-muted-foreground">Blacklist is empty.</div>
              )}
            </div>
          </CardContent>
        </Card>
      </div>

      <Dialog open={certReportOpen} onOpenChange={setCertReportOpen}>
        <DialogContent className="max-w-3xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-primary">
              <ShieldAlert className="w-5 h-5" />
              CERT-In Threat Intelligence Report
            </DialogTitle>
          </DialogHeader>
          <div className="p-4 bg-slate-950 text-emerald-400 font-mono text-sm rounded-lg whitespace-pre-wrap overflow-x-auto">
            {certReportData ? JSON.stringify(certReportData, null, 2) : "Loading..."}
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
