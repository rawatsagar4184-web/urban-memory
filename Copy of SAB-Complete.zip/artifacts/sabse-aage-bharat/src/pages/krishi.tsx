import { useGetMandiPrices, useGetKrishiWeather, useGetKrishiAdvisory, useGetLivestockInfo } from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Tractor, CloudSun, ArrowUpRight, ArrowDownRight, Minus, Sprout, Bug, Droplets, Leaf } from "lucide-react";

export function Krishi() {
  const { data: mandi, isLoading: loadingMandi } = useGetMandiPrices();
  const { data: weather, isLoading: loadingWeather } = useGetKrishiWeather();
  const { data: advisory, isLoading: loadingAdvisory } = useGetKrishiAdvisory();
  const { data: livestock, isLoading: loadingLivestock } = useGetLivestockInfo();

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3">
        <Tractor className="w-10 h-10 text-success" />
        <div>
          <h1 className="text-3xl font-bold tracking-tight text-success">Krishi Mitra</h1>
          <p className="text-muted-foreground mt-1">Digital Mandi, weather forecasts, and smart farming advisory for Bharat's farmers.</p>
        </div>
      </div>

      <Tabs defaultValue="mandi" className="w-full">
        <TabsList className="grid w-full md:w-[600px] grid-cols-3">
          <TabsTrigger value="mandi" data-testid="tab-mandi">Digital Mandi</TabsTrigger>
          <TabsTrigger value="advisory" data-testid="tab-advisory">Crop Advisory</TabsTrigger>
          <TabsTrigger value="livestock" data-testid="tab-livestock">Livestock & Bees</TabsTrigger>
        </TabsList>
        
        <TabsContent value="mandi" className="mt-6 space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2">
              <Card>
                <CardHeader>
                  <CardTitle>Live Mandi Prices / मंडी भाव</CardTitle>
                  <CardDescription>Updated every 15 minutes across major markets</CardDescription>
                </CardHeader>
                <CardContent>
                  {loadingMandi ? (
                    <Skeleton className="h-64 w-full" data-testid="skeleton-mandi" />
                  ) : (
                    <div className="overflow-x-auto">
                      <table className="w-full text-sm text-left">
                        <thead className="text-xs text-muted-foreground uppercase bg-muted/50">
                          <tr>
                            <th className="px-4 py-3 rounded-l-lg">Crop / फसल</th>
                            <th className="px-4 py-3">Market / बाजार</th>
                            <th className="px-4 py-3">Price/Quintal (₹)</th>
                            <th className="px-4 py-3 rounded-r-lg">Trend / रुझान</th>
                          </tr>
                        </thead>
                        <tbody>
                          {mandi?.prices.map((item, i) => (
                            <tr key={i} className="border-b last:border-0 hover:bg-muted/30 transition-colors" data-testid={`row-mandi-${item.crop}`}>
                              <td className="px-4 py-4 font-medium">{item.crop}</td>
                              <td className="px-4 py-4">{item.market}</td>
                              <td className="px-4 py-4 font-bold text-lg">₹{item.pricePerQuintal.toLocaleString()}</td>
                              <td className="px-4 py-4">
                                {item.trend === 'up' && <Badge variant="outline" className="text-success border-success bg-success/10"><ArrowUpRight className="w-3 h-3 mr-1"/>{item.change}%</Badge>}
                                {item.trend === 'down' && <Badge variant="outline" className="text-destructive border-destructive bg-destructive/10"><ArrowDownRight className="w-3 h-3 mr-1"/>{Math.abs(item.change)}%</Badge>}
                                {item.trend === 'stable' && <Badge variant="outline" className="text-muted-foreground"><Minus className="w-3 h-3 mr-1"/>0%</Badge>}
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>

            <div>
              <Card className="h-full">
                <CardHeader className="bg-primary/5 pb-4 border-b">
                  <CardTitle className="flex items-center gap-2 text-primary">
                    <CloudSun className="w-5 h-5" />
                    7-Day Weather Forecast
                  </CardTitle>
                </CardHeader>
                <CardContent className="pt-4">
                  {loadingWeather ? (
                    <Skeleton className="h-64 w-full" data-testid="skeleton-weather" />
                  ) : weather && (
                    <div className="space-y-4">
                      <div className="text-sm font-bold bg-muted p-2 rounded text-center">{weather.location}</div>
                      {weather.forecast.map((day, i) => (
                        <div key={i} className="flex justify-between items-center py-2 border-b last:border-0 text-sm" data-testid={`weather-day-${i}`}>
                          <div className="font-medium w-1/3 text-primary">{new Date(day.date).toLocaleDateString(undefined, {weekday: 'short', day: 'numeric'})}</div>
                          <div className="w-1/3 text-center text-xs font-semibold">{day.condition}</div>
                          <div className="w-1/3 text-right">
                            <span className="font-bold text-destructive">{day.tempMax}°</span>
                            <span className="text-muted-foreground ml-2">{day.tempMin}°</span>
                          </div>
                        </div>
                      ))}
                      <div className="mt-4 p-3 bg-secondary/10 border border-secondary/30 rounded-md text-xs font-medium text-secondary-foreground">
                        <span className="block mb-1 text-secondary font-bold uppercase tracking-wide">Farming Advice</span>
                        {weather.farmingAdvice}
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          </div>
        </TabsContent>

        <TabsContent value="advisory" className="mt-6">
          {loadingAdvisory ? (
            <Skeleton className="h-64 w-full" data-testid="skeleton-advisory" />
          ) : advisory && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card className="border-success/30 bg-success/5 md:col-span-2">
                <CardContent className="p-6 flex items-center justify-between">
                  <div>
                    <h2 className="text-2xl font-bold text-success">Advisory for {advisory.crop}</h2>
                    <p className="text-success/80 text-sm mt-1">Based on local soil and weather conditions</p>
                  </div>
                  <Sprout className="w-16 h-16 text-success opacity-50" />
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-sm uppercase tracking-wider text-muted-foreground">
                    <Leaf className="w-4 h-4 text-primary" /> Soil Health & Recommendation
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <p className="font-semibold text-lg">{advisory.soilHealth}</p>
                    <p className="text-sm text-muted-foreground mt-1">Current Soil Status</p>
                  </div>
                  <div className="p-4 bg-primary/5 rounded-lg border border-primary/10">
                    <p className="text-sm font-medium">{advisory.recommendation}</p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-sm uppercase tracking-wider text-muted-foreground">
                    <Bug className="w-4 h-4 text-destructive" /> Alerts & Action
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="p-4 bg-destructive/10 rounded-lg border border-destructive/20 text-destructive">
                    <p className="font-bold mb-1 flex items-center gap-2"><Bug className="w-4 h-4"/> Pest Alert</p>
                    <p className="text-sm">{advisory.pestAlert}</p>
                  </div>
                  <div className="flex gap-4">
                    <div className="flex-1 p-3 bg-blue-50 dark:bg-blue-900/20 rounded-lg border border-blue-100 dark:border-blue-800">
                      <p className="text-xs font-bold text-blue-600 dark:text-blue-400 mb-1 flex items-center gap-1"><Droplets className="w-3 h-3"/> Irrigation</p>
                      <p className="text-sm">{advisory.irrigationAdvice}</p>
                    </div>
                    <div className="flex-1 p-3 bg-secondary/10 rounded-lg border border-secondary/20">
                      <p className="text-xs font-bold text-secondary mb-1">Expected Yield</p>
                      <p className="text-lg font-bold">{advisory.expectedYield}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          )}
        </TabsContent>

        <TabsContent value="livestock" className="mt-6">
          {loadingLivestock ? (
             <Skeleton className="h-64 w-full" data-testid="skeleton-livestock" />
          ) : livestock && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Livestock Management / पशुपालन</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <h4 className="font-semibold text-sm mb-2 text-primary">Health & Care</h4>
                    <p className="text-sm p-3 bg-muted rounded-md">{livestock.livestockHealth}</p>
                  </div>
                  <div>
                    <h4 className="font-semibold text-sm mb-2 text-primary">Milk Yield Optimization</h4>
                    <p className="text-sm p-3 bg-muted rounded-md">{livestock.milkYieldTips}</p>
                  </div>
                </CardContent>
              </Card>
              
              <div className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Beekeeping Guide / मधुमक्खी पालन</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm leading-relaxed">{livestock.beekeepingGuide}</p>
                  </CardContent>
                </Card>
                
                <Card className="bg-secondary/5 border-secondary/20">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-lg text-secondary">Govt Subsidies & Training</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div>
                        <h4 className="text-xs font-bold uppercase tracking-wider mb-2">Available Subsidies</h4>
                        <ul className="list-disc pl-5 text-sm space-y-1">
                          {livestock.govSubsidies.map((sub, i) => <li key={i}>{sub}</li>)}
                        </ul>
                      </div>
                      <div>
                        <h4 className="text-xs font-bold uppercase tracking-wider mb-2">Training Centers</h4>
                        <ul className="list-disc pl-5 text-sm space-y-1 text-primary">
                          {livestock.trainingCenters.map((center, i) => <li key={i}>{center}</li>)}
                        </ul>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}
