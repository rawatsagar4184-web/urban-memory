import { useGetTicker, useGetOrderBook, useGetSWADESHIINDEX } from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";
import { LineChart as ChartIcon, ShieldAlert } from "lucide-react";

export function Exchange() {
  const { data: ticker, isLoading: loadingTicker } = useGetTicker();
  const { data: orderBook, isLoading: loadingBook } = useGetOrderBook();
  const { data: swadeshiIndex, isLoading: loadingIndex } = useGetSWADESHIINDEX();

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3">
        <ChartIcon className="w-10 h-10 text-primary" />
        <div>
          <h1 className="text-3xl font-bold tracking-tight text-primary">SAB Exchange & Swadeshi Index</h1>
          <p className="text-muted-foreground mt-1">Sovereign digital trading ecosystem.</p>
        </div>
      </div>

      {/* FIXED EXCHANGE RATE BANNER - CRITICAL REQUIREMENT */}
      <Card className="bg-gradient-to-r from-primary to-primary/90 text-primary-foreground border-none shadow-xl relative overflow-hidden">
        <div className="absolute top-0 right-0 p-8 opacity-10 pointer-events-none">
          <ShieldAlert className="w-32 h-32" />
        </div>
        <CardContent className="p-6 md:p-8 flex flex-col md:flex-row justify-between items-center gap-6 relative z-10">
          <div className="space-y-2 text-center md:text-left">
            <Badge variant="outline" className="text-secondary border-secondary mb-2 bg-secondary/10">SOVEREIGN GUARANTEE</Badge>
            <h2 className="text-2xl md:text-3xl font-bold tracking-tight">Fixed Exchange Rate</h2>
            <p className="text-primary-foreground/80 font-medium">100 SAB = ₹1 (Fixed by Owner)</p>
            <p className="text-xs text-primary-foreground/60 max-w-md">
              Unlike volatile crypto, SAB is pegged to INR by the absolute authority of the system owner. Market forces do not affect this rate.
            </p>
          </div>
          <div className="text-5xl md:text-6xl font-black font-mono tracking-tighter bg-white/10 px-8 py-6 rounded-xl shadow-inner border border-white/20" data-testid="fixed-rate-display">
            100 SAB = ₹1
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          <Card className="h-[450px] flex flex-col">
            <CardHeader className="pb-2">
              <div className="flex justify-between items-start">
                <div>
                  <CardTitle className="flex items-center gap-2">
                    Swadeshi Index <Badge variant="secondary">SWDX</Badge>
                  </CardTitle>
                  <CardDescription>Performance of top 50 Bharatiya tech companies</CardDescription>
                </div>
                {loadingIndex ? null : swadeshiIndex && (
                  <div className="text-right">
                    <div className="text-2xl font-bold" data-testid="index-current-value">{swadeshiIndex.currentValue.toLocaleString()}</div>
                    <div className={`text-sm font-bold flex justify-end items-center ${swadeshiIndex.change >= 0 ? 'text-success' : 'text-destructive'}`}>
                      {swadeshiIndex.change >= 0 ? '+' : ''}{swadeshiIndex.change} ({swadeshiIndex.changePercent}%)
                    </div>
                  </div>
                )}
              </div>
            </CardHeader>
            <CardContent className="flex-1 min-h-0 pt-4">
              {loadingIndex ? (
                <Skeleton className="h-full w-full" data-testid="skeleton-chart" />
              ) : swadeshiIndex ? (
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={swadeshiIndex.history} margin={{ top: 5, right: 5, left: 5, bottom: 5 }}>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="hsl(var(--muted))" />
                    <XAxis 
                      dataKey="time" 
                      tick={{ fontSize: 12, fill: 'hsl(var(--muted-foreground))' }}
                      tickLine={false}
                      axisLine={false}
                      minTickGap={30}
                    />
                    <YAxis 
                      domain={['auto', 'auto']} 
                      tick={{ fontSize: 12, fill: 'hsl(var(--muted-foreground))' }}
                      tickLine={false}
                      axisLine={false}
                      width={60}
                    />
                    <Tooltip 
                      contentStyle={{ backgroundColor: 'hsl(var(--popover))', borderColor: 'hsl(var(--border))', borderRadius: '8px' }}
                      itemStyle={{ color: 'hsl(var(--foreground))' }}
                    />
                    <Line 
                      type="monotone" 
                      dataKey="value" 
                      stroke="hsl(var(--primary))" 
                      strokeWidth={3}
                      dot={false}
                      activeDot={{ r: 6, fill: 'hsl(var(--secondary))', stroke: 'hsl(var(--background))', strokeWidth: 2 }}
                    />
                  </LineChart>
                </ResponsiveContainer>
              ) : null}
            </CardContent>
          </Card>
          
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <Card>
              <CardContent className="pt-6">
                <p className="text-xs text-muted-foreground uppercase font-bold tracking-wider mb-1">Index High</p>
                <p className="text-xl font-bold">{swadeshiIndex?.high.toLocaleString() ?? "---"}</p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="pt-6">
                <p className="text-xs text-muted-foreground uppercase font-bold tracking-wider mb-1">Index Low</p>
                <p className="text-xl font-bold">{swadeshiIndex?.low.toLocaleString() ?? "---"}</p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="pt-6">
                <p className="text-xs text-muted-foreground uppercase font-bold tracking-wider mb-1">24h Vol</p>
                <p className="text-xl font-bold">{ticker?.volume24h.toLocaleString() ?? "---"}</p>
              </CardContent>
            </Card>
            <Card className="bg-primary/5">
              <CardContent className="pt-6">
                <p className="text-xs text-primary uppercase font-bold tracking-wider mb-1">Pair</p>
                <p className="text-xl font-bold">{ticker?.pair ?? "---"}</p>
              </CardContent>
            </Card>
          </div>
        </div>

        <div>
          <Card className="h-full flex flex-col">
            <CardHeader className="pb-4 border-b">
              <CardTitle>Order Book</CardTitle>
              <CardDescription>Live Bids and Asks</CardDescription>
            </CardHeader>
            <CardContent className="flex-1 pt-4 p-0">
              {loadingBook ? (
                <div className="p-6"><Skeleton className="h-64 w-full" data-testid="skeleton-orderbook" /></div>
              ) : orderBook && (
                <div className="flex flex-col h-full">
                  {/* ASKS (SELL) - Red */}
                  <div className="flex-1 overflow-auto px-2">
                    <table className="w-full text-xs font-mono">
                      <thead>
                        <tr className="text-muted-foreground sticky top-0 bg-card">
                          <th className="text-left font-normal py-2 px-4">Price (₹)</th>
                          <th className="text-right font-normal py-2 px-4">Amount</th>
                        </tr>
                      </thead>
                      <tbody>
                        {[...orderBook.asks].reverse().map((ask, i) => (
                          <tr key={`ask-${i}`} className="hover:bg-muted/50 cursor-pointer relative group">
                            <td className="text-destructive font-bold py-1.5 px-4 z-10 relative">{ask.price.toFixed(2)}</td>
                            <td className="text-right py-1.5 px-4 z-10 relative">{ask.quantity}</td>
                            <div className="absolute inset-y-0 right-0 bg-destructive/10 z-0 transition-all" style={{ width: `${Math.min(100, (ask.total / 1000) * 100)}%` }}></div>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>

                  {/* SPREAD / CURRENT */}
                  <div className="py-3 px-6 border-y bg-muted/30 text-center flex justify-between items-center">
                    <span className="text-sm font-bold text-primary">{ticker?.price.toFixed(2) ?? "---"}</span>
                    <span className="text-xs text-muted-foreground font-mono">Spread: {orderBook.spread.toFixed(2)}</span>
                  </div>

                  {/* BIDS (BUY) - Green */}
                  <div className="flex-1 overflow-auto px-2">
                    <table className="w-full text-xs font-mono">
                      <tbody>
                        {orderBook.bids.map((bid, i) => (
                          <tr key={`bid-${i}`} className="hover:bg-muted/50 cursor-pointer relative group">
                            <td className="text-success font-bold py-1.5 px-4 z-10 relative">{bid.price.toFixed(2)}</td>
                            <td className="text-right py-1.5 px-4 z-10 relative">{bid.quantity}</td>
                            <div className="absolute inset-y-0 right-0 bg-success/10 z-0 transition-all" style={{ width: `${Math.min(100, (bid.total / 1000) * 100)}%` }}></div>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
