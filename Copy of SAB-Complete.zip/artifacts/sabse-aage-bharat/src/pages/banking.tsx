import { useState, useCallback } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { BiometricGate } from "@/components/biometric-gate";
import {
  useCreateBankAccount,
  useFetchBankAccount,
  getFetchBankAccountQueryKey,
  useBankDeposit,
  useBankWithdraw,
  useBankTransfer,
  useFetchAccountStatement,
  getFetchAccountStatementQueryKey,
  useCoreBankStats,
  getCoreBankStatsQueryKey,
  useGetFDRateCard,
  getGetFDRateCardQueryKey,
  useCreateFD,
  useListFDs,
  getListFDsQueryKey,
  useCloseFDRecord,
  useCreateRD,
  useListRDs,
  getListRDsQueryKey,
  useCreateSI,
  useListSIs,
  getListSIsQueryKey,
  useCancelSI,
} from "@workspace/api-client-react";
import { useToast } from "@/hooks/use-toast";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Building2,
  Wallet,
  ArrowRightLeft,
  Search,
  IndianRupee,
  Activity,
  History,
  ShieldCheck,
  AlertTriangle,
  Copy,
  TrendingUp,
  RotateCcw,
  CalendarClock,
  BadgePercent,
  X,
} from "lucide-react";
import { format } from "date-fns";

// Daily debit limits by account type (mirrors backend)
const DAILY_LIMITS: Record<string, string> = {
  savings: "₹1,00,000 / day",
  current: "₹10,00,000 / day",
  "Jan Dhan": "₹10,000 / day",
};

export function Banking() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: stats } = useCoreBankStats({
    query: { queryKey: getCoreBankStatsQueryKey(), refetchInterval: 8000 },
  });

  // --- Create form ---
  const [createForm, setCreateForm] = useState({
    holderName: "",
    mobile: "",
    aadhaarNumber: "",
    accountType: "savings" as "savings" | "current" | "Jan Dhan",
    sabWalletAddress: "",
  });
  const [newAccount, setNewAccount] = useState<{ accountNumber: string; upiId: string; ifscCode: string } | null>(null);

  // --- Lookup ---
  const [lookupInput, setLookupInput] = useState("");
  const [lookupAccount, setLookupAccount] = useState("");

  const { data: lookedUpAccount } = useFetchBankAccount(lookupAccount, {
    query: {
      enabled: lookupAccount.length >= 10,
      queryKey: getFetchBankAccountQueryKey(lookupAccount),
    },
  });

  const { data: accountStatement } = useFetchAccountStatement(lookupAccount, {
    query: {
      enabled: lookupAccount.length >= 10,
      queryKey: getFetchAccountStatementQueryKey(lookupAccount),
    },
  });

  // --- Deposit form ---
  const [depositForm, setDepositForm] = useState({
    accountNumber: "",
    amount: "",
    description: "",
    mode: "CASH" as "CASH" | "NEFT" | "IMPS" | "UPI",
  });

  // --- Withdraw form ---
  const [withdrawForm, setWithdrawForm] = useState({
    accountNumber: "",
    amount: "",
    description: "",
    mode: "ATM" as "ATM" | "CASH" | "UPI",
  });

  // --- Transfer form ---
  const [transferForm, setTransferForm] = useState({
    fromAccount: "",
    toAccount: "",
    amount: "",
    description: "",
    mode: "UPI" as "UPI" | "NEFT" | "IMPS",
  });

  // --- Biometric gate state ---
  const [bioGate, setBioGate] = useState<{
    open: boolean;
    label: string;
    amount?: number;
    onConfirm: () => void;
  }>({ open: false, label: "", onConfirm: () => {} });

  const requireBio = useCallback((label: string, amount: number, onConfirm: () => void) => {
    setBioGate({ open: true, label, amount, onConfirm });
  }, []);

  // --- FD / RD / SI state ---
  const [fdForm, setFdForm] = useState({ accountNumber: "", principal: "", tenure: "90d" as "7d"|"30d"|"90d"|"180d"|"365d", scBonus: false });
  const [rdForm, setRdForm] = useState({ accountNumber: "", monthlyAmount: "", tenureMonths: "12" });
  const [siForm, setSiForm] = useState({ accountNumber: "", toAccount: "", amount: "", description: "", frequency: "monthly" as "once"|"daily"|"weekly"|"monthly" });
  const [fdLookup, setFdLookup] = useState("");
  const [rdLookup, setRdLookup] = useState("");
  const [siLookup, setSiLookup] = useState("");

  // --- Investment queries ---
  const { data: rateCard } = useGetFDRateCard({ query: { queryKey: getGetFDRateCardQueryKey() } });
  const { data: fdList } = useListFDs(fdLookup, { query: { enabled: !!fdLookup, queryKey: getListFDsQueryKey(fdLookup) } });
  const { data: rdList } = useListRDs(rdLookup, { query: { enabled: !!rdLookup, queryKey: getListRDsQueryKey(rdLookup) } });
  const { data: siList } = useListSIs(siLookup, { query: { enabled: !!siLookup, queryKey: getListSIsQueryKey(siLookup) } });

  // --- Mutations ---
  const createAccount = useCreateBankAccount();
  const depositMut = useBankDeposit();
  const withdrawMut = useBankWithdraw();
  const transferMut = useBankTransfer();
  const createFDMut = useCreateFD();
  const closeFDMut = useCloseFDRecord();
  const createRDMut = useCreateRD();
  const createSIMut = useCreateSI();
  const cancelSIMut = useCancelSI();

  // --- Handlers ---
  const handleCreateAccount = () => {
    const { holderName, mobile, aadhaarNumber, accountType } = createForm;
    if (!holderName.trim() || !mobile.trim() || aadhaarNumber.length < 12) {
      toast({ title: "जानकारी अधूरी है", description: "नाम, मोबाइल और 12-अंकीय आधार आवश्यक हैं।", variant: "destructive" });
      return;
    }
    createAccount.mutate(
      { data: createForm },
      {
        onSuccess: (acc) => {
          setNewAccount({ accountNumber: acc.accountNumber, upiId: acc.upiId ?? "", ifscCode: acc.ifscCode });
          setCreateForm({ holderName: "", mobile: "", aadhaarNumber: "", accountType: "savings", sabWalletAddress: "" });
          queryClient.invalidateQueries({ queryKey: getCoreBankStatsQueryKey() });
          toast({ title: "खाता खुल गया!", description: `Account: ${acc.accountNumber}` });
        },
        onError: (err) => {
          toast({ title: "Error", description: (err as { error?: string }).error ?? "Unknown error", variant: "destructive" });
        },
      }
    );
  };

  const handleDeposit = () => {
    const amt = Number(depositForm.amount);
    if (!depositForm.accountNumber || !amt || amt <= 0 || !depositForm.description) {
      toast({ title: "फ़ॉर्म अधूरा है", description: "सभी फ़ील्ड भरें।", variant: "destructive" });
      return;
    }
    depositMut.mutate(
      { data: { ...depositForm, amount: amt } },
      {
        onSuccess: () => {
          toast({ title: "जमा सफल", description: `₹${amt.toLocaleString()} जमा हुए` });
          setDepositForm({ accountNumber: "", amount: "", description: "", mode: "CASH" });
          queryClient.invalidateQueries({ queryKey: getFetchAccountStatementQueryKey(lookupAccount) });
          queryClient.invalidateQueries({ queryKey: getFetchBankAccountQueryKey(lookupAccount) });
          queryClient.invalidateQueries({ queryKey: getCoreBankStatsQueryKey() });
        },
        onError: (err) => {
          toast({ title: "जमा विफल", description: (err as { error?: string }).error ?? "Error", variant: "destructive" });
        },
      }
    );
  };

  const handleWithdraw = () => {
    const amt = Number(withdrawForm.amount);
    if (!withdrawForm.accountNumber || !amt || amt <= 0 || !withdrawForm.description) {
      toast({ title: "फ़ॉर्म अधूरा है", description: "सभी फ़ील्ड भरें।", variant: "destructive" });
      return;
    }
    requireBio("निकासी (Withdraw)", amt, () => {
      withdrawMut.mutate(
        { data: { ...withdrawForm, amount: amt } },
        {
          onSuccess: () => {
            toast({ title: "निकासी सफल", description: `₹${amt.toLocaleString("en-IN")} निकले` });
            setWithdrawForm({ accountNumber: "", amount: "", description: "", mode: "ATM" });
            queryClient.invalidateQueries({ queryKey: getFetchAccountStatementQueryKey(lookupAccount) });
            queryClient.invalidateQueries({ queryKey: getFetchBankAccountQueryKey(lookupAccount) });
            queryClient.invalidateQueries({ queryKey: getCoreBankStatsQueryKey() });
          },
          onError: (err) => {
            toast({ title: "निकासी विफल", description: (err as { error?: string }).error ?? "Error", variant: "destructive" });
          },
        }
      );
    });
  };

  const handleTransfer = () => {
    const amt = Number(transferForm.amount);
    if (!transferForm.fromAccount || !transferForm.toAccount || !amt || amt <= 0) {
      toast({ title: "फ़ॉर्म अधूरा है", description: "दोनों खाते और राशि आवश्यक है।", variant: "destructive" });
      return;
    }
    if (transferForm.fromAccount === transferForm.toAccount) {
      toast({ title: "त्रुटि", description: "एक ही खाते में ट्रांसफर नहीं हो सकता।", variant: "destructive" });
      return;
    }
    requireBio("ट्रांसफर (Transfer)", amt, () => {
      transferMut.mutate(
        { data: { ...transferForm, amount: amt } },
        {
          onSuccess: () => {
            toast({ title: "ट्रांसफर सफल", description: `₹${amt.toLocaleString("en-IN")} भेजे गए` });
            setTransferForm({ fromAccount: "", toAccount: "", amount: "", description: "", mode: "UPI" });
            queryClient.invalidateQueries({ queryKey: getFetchAccountStatementQueryKey(lookupAccount) });
            queryClient.invalidateQueries({ queryKey: getFetchBankAccountQueryKey(lookupAccount) });
            queryClient.invalidateQueries({ queryKey: getCoreBankStatsQueryKey() });
          },
          onError: (err) => {
            toast({ title: "ट्रांसफर विफल", description: (err as { error?: string }).error ?? "Error", variant: "destructive" });
          },
        }
      );
    });
  };

  // --- FD handler ---
  const handleCreateFD = () => {
    const principal = Number(fdForm.principal);
    if (!fdForm.accountNumber || !principal || principal < 1000) {
      toast({ title: "न्यूनतम FD ₹1,000 — खाता नंबर + राशि + tenure आवश्यक", variant: "destructive" }); return;
    }
    createFDMut.mutate(
      { data: { accountNumber: fdForm.accountNumber, principal, tenure: fdForm.tenure, scBonus: fdForm.scBonus } },
      {
        onSuccess: (fd) => {
          toast({ title: "FD खुली!", description: `₹${principal.toLocaleString("en-IN")} @ ${fd.ratePercent}% — परिपक्वता: ₹${fd.maturityAmount.toLocaleString("en-IN")}` });
          setFdLookup(fdForm.accountNumber);
          queryClient.invalidateQueries({ queryKey: getListFDsQueryKey(fdForm.accountNumber) });
        },
        onError: (e) => toast({ title: "FD विफल", description: (e as { error?: string }).error ?? "Error", variant: "destructive" }),
      }
    );
  };

  // --- RD handler ---
  const handleCreateRD = () => {
    const monthly = Number(rdForm.monthlyAmount);
    const months = Number(rdForm.tenureMonths);
    if (!rdForm.accountNumber || monthly < 100 || months < 6) {
      toast({ title: "न्यूनतम ₹100/माह — अवधि कम से कम 6 माह", variant: "destructive" }); return;
    }
    createRDMut.mutate(
      { data: { accountNumber: rdForm.accountNumber, monthlyAmount: monthly, tenureMonths: months } },
      {
        onSuccess: (rd) => {
          toast({ title: "RD खुली!", description: `₹${monthly.toLocaleString("en-IN")}/माह @ ${rd.ratePercent}% — ${months} माह` });
          setRdLookup(rdForm.accountNumber);
          queryClient.invalidateQueries({ queryKey: getListRDsQueryKey(rdForm.accountNumber) });
        },
        onError: (e) => toast({ title: "RD विफल", description: (e as { error?: string }).error ?? "Error", variant: "destructive" }),
      }
    );
  };

  // --- SI handler ---
  const handleCreateSI = () => {
    const amt = Number(siForm.amount);
    if (!siForm.accountNumber || !siForm.toAccount || !amt || !siForm.description) {
      toast({ title: "सभी SI विवरण आवश्यक हैं", variant: "destructive" }); return;
    }
    createSIMut.mutate(
      { data: { accountNumber: siForm.accountNumber, toAccount: siForm.toAccount, amount: amt, description: siForm.description, frequency: siForm.frequency } },
      {
        onSuccess: (si) => {
          toast({ title: "Standing Instruction बनी!", description: `₹${amt.toLocaleString("en-IN")} — ${si.frequency} — अगली: ${format(new Date(si.nextRunAt), "dd MMM yyyy")}` });
          setSiLookup(siForm.accountNumber);
          queryClient.invalidateQueries({ queryKey: getListSIsQueryKey(siForm.accountNumber) });
        },
        onError: (e) => toast({ title: "SI विफल", description: (e as { error?: string }).error ?? "Error", variant: "destructive" }),
      }
    );
  };

  const copyToClipboard = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    toast({ title: "Copied", description: `${label} copied` });
  };

  return (
    <div className="space-y-6">
      <BiometricGate
        open={bioGate.open}
        operationLabel={bioGate.label}
        amount={bioGate.amount}
        onSuccess={() => { setBioGate(g => ({ ...g, open: false })); bioGate.onConfirm(); }}
        onCancel={() => setBioGate(g => ({ ...g, open: false }))}
      />
      {/* Header */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h2 className="text-3xl font-bold tracking-tight text-primary flex items-center gap-2">
            <Building2 className="w-8 h-8 text-secondary" />
            SAB Core Banking
          </h2>
          <p className="text-muted-foreground mt-1">राष्ट्रीय डिजिटल बैंकिंग अवसंरचना (कोर बैंकिंग)</p>
        </div>
        <div className="flex items-center gap-3 bg-secondary/10 px-4 py-2 rounded-lg border border-secondary/20">
          <ShieldCheck className="w-5 h-5 text-secondary" />
          <span className="font-semibold text-primary">SAB Pay UPI — @sabpay</span>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card className="bg-primary text-primary-foreground border-none">
          <CardContent className="p-4">
            <div className="text-xs font-medium opacity-70 uppercase tracking-wider">कुल शेष</div>
            <div className="text-2xl font-bold mt-1 flex items-center gap-1">
              <IndianRupee className="w-5 h-5" />
              {stats?.totalBalance?.toLocaleString("en-IN") ?? "0"}
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="text-xs font-medium text-muted-foreground uppercase tracking-wider">कुल खाते</div>
            <div className="text-2xl font-bold text-primary mt-1">{stats?.totalAccounts ?? "0"}</div>
          </CardContent>
        </Card>
        <Card className="bg-secondary/10 border-secondary/20">
          <CardContent className="p-4">
            <div className="text-xs font-medium text-secondary-foreground uppercase tracking-wider">जन धन खाते</div>
            <div className="text-2xl font-bold text-secondary mt-1">{stats?.janDhanAccounts ?? "0"}</div>
          </CardContent>
        </Card>
        <Card className={(stats as { suspiciousFlags?: number } | undefined)?.suspiciousFlags ? "border-destructive/50 bg-destructive/5" : ""}>
          <CardContent className="p-4">
            <div className="text-xs font-medium text-muted-foreground uppercase tracking-wider flex items-center gap-1">
              {(stats as { suspiciousFlags?: number } | undefined)?.suspiciousFlags ? <AlertTriangle className="w-3 h-3 text-destructive" /> : null}
              संदिग्ध फ्लैग
            </div>
            <div className={`text-2xl font-bold mt-1 ${(stats as { suspiciousFlags?: number } | undefined)?.suspiciousFlags ? "text-destructive" : "text-primary"}`}>
              {(stats as { suspiciousFlags?: number } | undefined)?.suspiciousFlags ?? "0"}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Jan Dhan Banner */}
      <div className="bg-gradient-to-r from-secondary/20 to-primary/10 border border-secondary/30 rounded-xl p-4 flex items-center justify-between">
        <div>
          <h3 className="text-lg font-bold text-primary">"Jan Dhan for All" — शून्य शेष खाता</h3>
          <p className="text-sm text-muted-foreground">हर नागरिक को वित्तीय समावेश। आधार से तुरंत खाता खोलें। सीमा: ₹10,000/दिन।</p>
        </div>
        <Button
          variant="outline"
          className="border-secondary text-secondary hover:bg-secondary hover:text-white shrink-0"
          onClick={() => setCreateForm({ ...createForm, accountType: "Jan Dhan" })}
        >
          Jan Dhan खोलें
        </Button>
      </div>

      {/* Main Tabs */}
      <Tabs defaultValue="lookup" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="lookup" className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">
            <Search className="w-4 h-4 mr-1" /> खोज
          </TabsTrigger>
          <TabsTrigger value="create" className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">
            <Wallet className="w-4 h-4 mr-1" /> नया खाता
          </TabsTrigger>
          <TabsTrigger value="transact" className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">
            <Activity className="w-4 h-4 mr-1" /> लेन-देन
          </TabsTrigger>
          <TabsTrigger value="transfer" className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">
            <ArrowRightLeft className="w-4 h-4 mr-1" /> ट्रांसफर
          </TabsTrigger>
          <TabsTrigger value="fd" className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">
            <TrendingUp className="w-4 h-4 mr-1" /> FD
          </TabsTrigger>
          <TabsTrigger value="rd" className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">
            <RotateCcw className="w-4 h-4 mr-1" /> RD
          </TabsTrigger>
          <TabsTrigger value="si" className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">
            <CalendarClock className="w-4 h-4 mr-1" /> Auto-Pay
          </TabsTrigger>
        </TabsList>

        {/* Lookup Tab */}
        <TabsContent value="lookup" className="mt-6 space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>खाता खोज (Account Lookup)</CardTitle>
              <CardDescription>10-अंकीय SAB Account Number से खोजें</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex gap-2">
                <Input
                  placeholder="SAB खाता नंबर दर्ज करें..."
                  value={lookupInput}
                  onChange={(e) => setLookupInput(e.target.value)}
                  className="max-w-md font-mono"
                  data-testid="input-lookup-account"
                />
                <Button onClick={() => setLookupAccount(lookupInput)} variant="outline">
                  <Search className="w-4 h-4" />
                </Button>
              </div>

              {lookedUpAccount && (
                <div className="bg-muted rounded-lg p-4 space-y-3">
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    <div>
                      <div className="text-xs text-muted-foreground uppercase">खाताधारक</div>
                      <div className="font-bold text-primary">{lookedUpAccount.holderName}</div>
                    </div>
                    <div>
                      <div className="text-xs text-muted-foreground uppercase">प्रकार</div>
                      <div className="font-bold text-primary">{lookedUpAccount.accountType}</div>
                    </div>
                    <div>
                      <div className="text-xs text-muted-foreground uppercase">स्थिति</div>
                      <div className="font-bold text-green-600">{lookedUpAccount.isActive ? "सक्रिय" : "बंद"}</div>
                    </div>
                    <div>
                      <div className="text-xs text-muted-foreground uppercase">शेष राशि</div>
                      <div className="font-bold text-primary flex items-center gap-1">
                        <IndianRupee className="w-4 h-4" />
                        {lookedUpAccount.balance.toLocaleString("en-IN")}
                      </div>
                    </div>
                  </div>
                  {(lookedUpAccount as { upiId?: string }).upiId && (
                    <div className="flex items-center gap-2 bg-background border rounded px-3 py-2 w-fit">
                      <ShieldCheck className="w-4 h-4 text-secondary" />
                      <span className="font-mono text-sm">{(lookedUpAccount as { upiId?: string }).upiId}</span>
                      <button onClick={() => copyToClipboard((lookedUpAccount as { upiId?: string }).upiId ?? "", "UPI ID")} className="text-muted-foreground hover:text-primary">
                        <Copy className="w-3 h-3" />
                      </button>
                    </div>
                  )}
                  <div className="text-xs text-muted-foreground">
                    दैनिक सीमा: {DAILY_LIMITS[(lookedUpAccount as { accountType: string }).accountType] ?? "—"} &nbsp;|&nbsp;
                    IFSC: {(lookedUpAccount as { ifscCode?: string }).ifscCode}
                  </div>
                </div>
              )}

              {accountStatement && accountStatement.transactions.length > 0 && (
                <div>
                  <h4 className="font-bold text-primary mb-3 flex items-center gap-2">
                    <History className="w-4 h-4" /> हाल के लेन-देन
                  </h4>
                  <div className="space-y-2">
                    {accountStatement.transactions.map((txn) => (
                      <div key={txn.id} className={`flex justify-between items-center p-3 border rounded-lg bg-card ${(txn as { fraudFlag?: boolean }).fraudFlag ? "border-destructive/50 bg-destructive/5" : ""}`}>
                        <div>
                          <div className="font-medium text-sm flex items-center gap-1">
                            {(txn as { fraudFlag?: boolean }).fraudFlag && <AlertTriangle className="w-3 h-3 text-destructive" />}
                            {txn.description}
                          </div>
                          <div className="text-xs text-muted-foreground">{format(new Date(txn.timestamp), "dd MMM yyyy, HH:mm")} · {txn.mode} · #{txn.reference}</div>
                        </div>
                        <div className={`font-bold text-sm ${txn.type === "credit" ? "text-green-600" : "text-destructive"}`}>
                          {txn.type === "credit" ? "+" : "−"}₹{txn.amount.toLocaleString("en-IN")}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Create Tab */}
        <TabsContent value="create" className="mt-6">
          {newAccount && (
            <div className="mb-4 bg-green-50 border border-green-300 rounded-xl p-4 space-y-2">
              <div className="font-bold text-green-800 flex items-center gap-2">
                <ShieldCheck className="w-5 h-5" /> खाता सफलतापूर्वक खुला!
              </div>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-3 mt-2">
                {([["Account Number", newAccount.accountNumber], ["UPI ID", newAccount.upiId], ["IFSC Code", newAccount.ifscCode]] as [string, string][]).map(([label, value]) => (
                  <div key={label} className="bg-white border rounded p-2 flex items-center justify-between gap-2">
                    <div>
                      <div className="text-xs text-muted-foreground">{label}</div>
                      <div className="font-mono text-sm font-bold">{value}</div>
                    </div>
                    <button onClick={() => copyToClipboard(value, label)} className="text-muted-foreground hover:text-primary shrink-0">
                      <Copy className="w-4 h-4" />
                    </button>
                  </div>
                ))}
              </div>
              <Button variant="ghost" size="sm" className="text-green-700" onClick={() => setNewAccount(null)}>बंद करें</Button>
            </div>
          )}

          <Card>
            <CardHeader>
              <CardTitle>नया खाता खोलें (Open Account)</CardTitle>
              <CardDescription>SAB Core Banking में नया खाता</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>खाताधारक का नाम *</Label>
                  <Input value={createForm.holderName} onChange={(e) => setCreateForm({ ...createForm, holderName: e.target.value })} data-testid="input-create-name" placeholder="पूरा नाम" />
                </div>
                <div className="space-y-2">
                  <Label>मोबाइल नंबर * (10 अंक)</Label>
                  <Input value={createForm.mobile} onChange={(e) => setCreateForm({ ...createForm, mobile: e.target.value })} data-testid="input-create-mobile" placeholder="9XXXXXXXXX" maxLength={10} />
                </div>
                <div className="space-y-2">
                  <Label>आधार नंबर * (12 अंक)</Label>
                  <Input value={createForm.aadhaarNumber} onChange={(e) => setCreateForm({ ...createForm, aadhaarNumber: e.target.value })} data-testid="input-create-aadhaar" placeholder="XXXXXXXXXXXX" maxLength={12} />
                </div>
                <div className="space-y-2">
                  <Label>खाता प्रकार *</Label>
                  <Select value={createForm.accountType} onValueChange={(v) => setCreateForm({ ...createForm, accountType: v as "savings" | "current" | "Jan Dhan" })}>
                    <SelectTrigger>
                      <SelectValue placeholder="प्रकार चुनें" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="savings">बचत खाता (Savings) — {DAILY_LIMITS.savings}</SelectItem>
                      <SelectItem value="current">चालू खाता (Current) — {DAILY_LIMITS.current}</SelectItem>
                      <SelectItem value="Jan Dhan">जन धन — {DAILY_LIMITS["Jan Dhan"]}</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2 md:col-span-2">
                  <Label>SAB Wallet Address (वैकल्पिक)</Label>
                  <Input value={createForm.sabWalletAddress} onChange={(e) => setCreateForm({ ...createForm, sabWalletAddress: e.target.value })} placeholder="0x..." />
                </div>
              </div>
              <Button
                onClick={handleCreateAccount}
                disabled={createAccount.isPending}
                className="w-full bg-primary hover:bg-primary/90 text-white"
                data-testid="btn-create-account"
              >
                {createAccount.isPending ? "खाता खुल रहा है..." : "खाता खोलें"}
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Transact Tab */}
        <TabsContent value="transact" className="mt-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Deposit */}
            <Card>
              <CardHeader>
                <CardTitle className="text-green-700">जमा (Deposit)</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="space-y-1">
                  <Label>खाता नंबर</Label>
                  <Input value={depositForm.accountNumber} onChange={(e) => setDepositForm({ ...depositForm, accountNumber: e.target.value })} className="font-mono" data-testid="input-deposit-account" />
                </div>
                <div className="space-y-1">
                  <Label>राशि (₹)</Label>
                  <Input type="number" min="1" value={depositForm.amount} onChange={(e) => setDepositForm({ ...depositForm, amount: e.target.value })} />
                </div>
                <div className="space-y-1">
                  <Label>विवरण</Label>
                  <Input value={depositForm.description} onChange={(e) => setDepositForm({ ...depositForm, description: e.target.value })} placeholder="e.g. वेतन जमा" />
                </div>
                <div className="space-y-1">
                  <Label>माध्यम</Label>
                  <Select value={depositForm.mode} onValueChange={(v) => setDepositForm({ ...depositForm, mode: v as "CASH" | "NEFT" | "IMPS" | "UPI" })}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="CASH">CASH</SelectItem>
                      <SelectItem value="NEFT">NEFT</SelectItem>
                      <SelectItem value="IMPS">IMPS</SelectItem>
                      <SelectItem value="UPI">SAB Pay UPI</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <Button onClick={handleDeposit} disabled={depositMut.isPending} className="w-full bg-green-700 hover:bg-green-800 text-white">
                  {depositMut.isPending ? "प्रक्रिया..." : "जमा करें"}
                </Button>
              </CardContent>
            </Card>

            {/* Withdraw */}
            <Card>
              <CardHeader>
                <CardTitle className="text-destructive">निकासी (Withdraw)</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="space-y-1">
                  <Label>खाता नंबर</Label>
                  <Input value={withdrawForm.accountNumber} onChange={(e) => setWithdrawForm({ ...withdrawForm, accountNumber: e.target.value })} className="font-mono" data-testid="input-withdraw-account" />
                </div>
                <div className="space-y-1">
                  <Label>राशि (₹)</Label>
                  <Input type="number" min="1" value={withdrawForm.amount} onChange={(e) => setWithdrawForm({ ...withdrawForm, amount: e.target.value })} />
                </div>
                <div className="space-y-1">
                  <Label>विवरण</Label>
                  <Input value={withdrawForm.description} onChange={(e) => setWithdrawForm({ ...withdrawForm, description: e.target.value })} placeholder="e.g. घरेलू खर्च" />
                </div>
                <div className="space-y-1">
                  <Label>माध्यम</Label>
                  <Select value={withdrawForm.mode} onValueChange={(v) => setWithdrawForm({ ...withdrawForm, mode: v as "ATM" | "CASH" | "UPI" })}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="ATM">ATM</SelectItem>
                      <SelectItem value="CASH">CASH</SelectItem>
                      <SelectItem value="UPI">SAB Pay UPI</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <Button onClick={handleWithdraw} disabled={withdrawMut.isPending} variant="destructive" className="w-full">
                  {withdrawMut.isPending ? "प्रक्रिया..." : "निकासी करें"}
                </Button>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Transfer Tab */}
        <TabsContent value="transfer" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle>पैसे भेजें (Transfer)</CardTitle>
              <CardDescription>SAB Pay UPI / NEFT / IMPS — Anti-fraud velocity check active</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4 max-w-2xl">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-1">
                  <Label>प्रेषक खाता (From)</Label>
                  <Input value={transferForm.fromAccount} onChange={(e) => setTransferForm({ ...transferForm, fromAccount: e.target.value })} className="font-mono" data-testid="input-transfer-from" />
                </div>
                <div className="space-y-1">
                  <Label>प्राप्तकर्ता खाता (To)</Label>
                  <Input value={transferForm.toAccount} onChange={(e) => setTransferForm({ ...transferForm, toAccount: e.target.value })} className="font-mono" data-testid="input-transfer-to" />
                </div>
                <div className="space-y-1">
                  <Label>राशि (₹)</Label>
                  <Input type="number" min="1" value={transferForm.amount} onChange={(e) => setTransferForm({ ...transferForm, amount: e.target.value })} />
                </div>
                <div className="space-y-1">
                  <Label>माध्यम</Label>
                  <Select value={transferForm.mode} onValueChange={(v) => setTransferForm({ ...transferForm, mode: v as "UPI" | "NEFT" | "IMPS" })}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="UPI">SAB Pay UPI (तुरंत)</SelectItem>
                      <SelectItem value="IMPS">IMPS (तुरंत)</SelectItem>
                      <SelectItem value="NEFT">NEFT (बैच)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-1 md:col-span-2">
                  <Label>टिप्पणी / Remarks</Label>
                  <Input value={transferForm.description} onChange={(e) => setTransferForm({ ...transferForm, description: e.target.value })} placeholder="e.g. किराया भुगतान" />
                </div>
              </div>
              <Button onClick={handleTransfer} disabled={transferMut.isPending} className="w-full bg-primary hover:bg-primary/90 text-white">
                {transferMut.isPending ? "ट्रांसफर हो रहा है..." : "ट्रांसफर करें"}
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        {/* FD Tab */}
        <TabsContent value="fd" className="mt-6 space-y-4">
          {/* Rate Card */}
          {rateCard && (
            <Card className="bg-slate-950 text-slate-200 border-slate-700">
              <CardHeader className="pb-2">
                <CardTitle className="flex items-center gap-2 text-amber-400"><BadgePercent className="w-4 h-4" /> SAB FD Rate Card</CardTitle>
                <CardDescription className="text-slate-400">{rateCard.scBonusNote}</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-5 gap-2 text-center text-xs font-mono">
                  {rateCard.rates.map(r => (
                    <div key={r.tenure} className="bg-slate-900 border border-slate-700 rounded p-2">
                      <div className="text-amber-400 font-bold text-base">{r.tenure}</div>
                      <div className="text-slate-300 mt-1">{r.rate}%</div>
                      <div className="text-green-400 text-[10px]">SC: {r.scBonusRate}%</div>
                      <div className="text-slate-500 text-[10px]">{r.days} दिन</div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Open FD */}
            <Card>
              <CardHeader><CardTitle className="flex items-center gap-2 text-amber-700"><TrendingUp className="w-4 h-4" /> Fixed Deposit खोलें</CardTitle></CardHeader>
              <CardContent className="space-y-3">
                <div className="space-y-1"><Label>खाता नंबर</Label><Input className="font-mono" value={fdForm.accountNumber} onChange={e => setFdForm({ ...fdForm, accountNumber: e.target.value })} placeholder="SAB account number" /></div>
                <div className="space-y-1"><Label>मूलधन (₹) — न्यूनतम ₹1,000</Label><Input type="number" min="1000" value={fdForm.principal} onChange={e => setFdForm({ ...fdForm, principal: e.target.value })} /></div>
                <div className="space-y-1">
                  <Label>Tenure (अवधि)</Label>
                  <Select value={fdForm.tenure} onValueChange={v => setFdForm({ ...fdForm, tenure: v as typeof fdForm.tenure })}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      {["7d","30d","90d","180d","365d"].map(t => <SelectItem key={t} value={t}>{t} — {rateCard?.rates.find(r=>r.tenure===t)?.rate ?? ""}%</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
                <div className="flex items-center gap-2 p-2 border rounded bg-green-50">
                  <input type="checkbox" id="sc-bonus" checked={fdForm.scBonus} onChange={e => setFdForm({ ...fdForm, scBonus: e.target.checked })} className="w-4 h-4" />
                  <label htmlFor="sc-bonus" className="text-sm text-green-800 cursor-pointer">SAB Wallet Linked — +{2}% SC Bonus Rate</label>
                </div>
                <Button onClick={handleCreateFD} disabled={createFDMut.isPending} className="w-full bg-amber-600 hover:bg-amber-700 text-white">
                  {createFDMut.isPending ? "FD बन रही है..." : "FD खोलें"}
                </Button>
              </CardContent>
            </Card>

            {/* FD List */}
            <Card>
              <CardHeader>
                <CardTitle className="text-sm font-medium text-muted-foreground uppercase">मेरी FDs देखें</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <div className="flex gap-2">
                  <Input className="font-mono text-sm" placeholder="Account number" value={fdLookup} onChange={e => setFdLookup(e.target.value)} />
                </div>
                {fdList && fdList.fds.length === 0 && <div className="text-sm text-muted-foreground text-center py-4">कोई FD नहीं</div>}
                {fdList?.fds.map(fd => (
                  <div key={fd.id} className="border rounded-lg p-3 space-y-1 bg-amber-50/40">
                    <div className="flex justify-between items-center">
                      <div className="font-bold text-amber-800">₹{fd.principal.toLocaleString("en-IN")}</div>
                      <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${fd.status === "active" ? "bg-green-100 text-green-800" : "bg-slate-100 text-slate-600"}`}>{fd.status}</span>
                    </div>
                    <div className="text-xs text-muted-foreground">{fd.tenure} @ {fd.ratePercent}% → ₹{fd.maturityAmount.toLocaleString("en-IN")}</div>
                    <div className="text-xs text-muted-foreground">परिपक्वता: {format(new Date(fd.maturesAt), "dd MMM yyyy")}</div>
                    {fd.status === "active" && (
                      <Button size="sm" variant="outline" className="text-destructive border-destructive/30 hover:bg-destructive/5 text-xs h-7 mt-1"
                        onClick={() => { closeFDMut.mutate({ fdId: fd.id }, { onSuccess: () => { toast({ title: "FD बंद की" }); queryClient.invalidateQueries({ queryKey: getListFDsQueryKey(fdLookup) }); } }); }}>
                        <X className="w-3 h-3 mr-1" /> Premature Close
                      </Button>
                    )}
                  </div>
                ))}
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* RD Tab */}
        <TabsContent value="rd" className="mt-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader><CardTitle className="flex items-center gap-2 text-blue-700"><RotateCcw className="w-4 h-4" /> Recurring Deposit खोलें</CardTitle></CardHeader>
              <CardContent className="space-y-3">
                <div className="space-y-1"><Label>खाता नंबर</Label><Input className="font-mono" value={rdForm.accountNumber} onChange={e => setRdForm({ ...rdForm, accountNumber: e.target.value })} /></div>
                <div className="space-y-1"><Label>मासिक राशि (₹) — न्यूनतम ₹100</Label><Input type="number" min="100" value={rdForm.monthlyAmount} onChange={e => setRdForm({ ...rdForm, monthlyAmount: e.target.value })} /></div>
                <div className="space-y-1">
                  <Label>अवधि (माह) — 6 से 120</Label>
                  <Select value={rdForm.tenureMonths} onValueChange={v => setRdForm({ ...rdForm, tenureMonths: v })}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      {[6,12,24,36,60,84,120].map(m => <SelectItem key={m} value={String(m)}>{m} माह — {m <= 12 ? "5.5" : m <= 36 ? "6.0" : "6.75"}%</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
                {rdForm.monthlyAmount && rdForm.tenureMonths && (
                  <div className="bg-blue-50 border border-blue-200 rounded p-3 text-sm">
                    <div className="text-blue-800 font-medium">अनुमानित परिपक्वता राशि</div>
                    <div className="text-blue-900 font-bold text-lg">
                      ₹{(Number(rdForm.monthlyAmount) * Number(rdForm.tenureMonths) * 1.0 + Number(rdForm.monthlyAmount) * Number(rdForm.tenureMonths) * (Number(rdForm.tenureMonths) <= 12 ? 0.055 : Number(rdForm.tenureMonths) <= 36 ? 0.06 : 0.0675) * (Number(rdForm.tenureMonths)/24)).toLocaleString("en-IN", { maximumFractionDigits: 0 })}
                    </div>
                    <div className="text-blue-600 text-xs mt-1">कुल जमा: ₹{(Number(rdForm.monthlyAmount) * Number(rdForm.tenureMonths)).toLocaleString("en-IN")}</div>
                  </div>
                )}
                <Button onClick={handleCreateRD} disabled={createRDMut.isPending} className="w-full bg-blue-700 hover:bg-blue-800 text-white">
                  {createRDMut.isPending ? "RD बन रही है..." : "RD खोलें"}
                </Button>
              </CardContent>
            </Card>

            <Card>
              <CardHeader><CardTitle className="text-sm font-medium text-muted-foreground uppercase">मेरी RDs देखें</CardTitle></CardHeader>
              <CardContent className="space-y-2">
                <div className="flex gap-2">
                  <Input className="font-mono text-sm" placeholder="Account number" value={rdLookup} onChange={e => setRdLookup(e.target.value)} />
                </div>
                {rdList && rdList.rds.length === 0 && <div className="text-sm text-muted-foreground text-center py-4">कोई RD नहीं</div>}
                {rdList?.rds.map(rd => (
                  <div key={rd.id} className="border rounded-lg p-3 space-y-1 bg-blue-50/40">
                    <div className="flex justify-between items-center">
                      <div className="font-bold text-blue-800">₹{rd.monthlyAmount.toLocaleString("en-IN")}/माह</div>
                      <span className={`text-xs px-2 py-0.5 rounded-full ${rd.status === "active" ? "bg-green-100 text-green-800" : "bg-slate-100 text-slate-600"}`}>{rd.status}</span>
                    </div>
                    <div className="text-xs text-muted-foreground">{rd.tenureMonths} माह @ {rd.ratePercent}% | {rd.installmentsPaid}/{rd.tenureMonths} किस्तें</div>
                    <div className="text-xs text-muted-foreground">परिपक्वता: {format(new Date(rd.maturesAt), "dd MMM yyyy")}</div>
                  </div>
                ))}
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* SI (Auto-Pay) Tab */}
        <TabsContent value="si" className="mt-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader><CardTitle className="flex items-center gap-2 text-purple-700"><CalendarClock className="w-4 h-4" /> Standing Instruction (Auto-Pay)</CardTitle><CardDescription>तय तारीख पर auto-transfer</CardDescription></CardHeader>
              <CardContent className="space-y-3">
                <div className="space-y-1"><Label>प्रेषक खाता (From)</Label><Input className="font-mono" value={siForm.accountNumber} onChange={e => setSiForm({ ...siForm, accountNumber: e.target.value })} /></div>
                <div className="space-y-1"><Label>प्राप्तकर्ता खाता (To)</Label><Input className="font-mono" value={siForm.toAccount} onChange={e => setSiForm({ ...siForm, toAccount: e.target.value })} /></div>
                <div className="space-y-1"><Label>राशि (₹)</Label><Input type="number" min="1" value={siForm.amount} onChange={e => setSiForm({ ...siForm, amount: e.target.value })} /></div>
                <div className="space-y-1"><Label>विवरण</Label><Input value={siForm.description} onChange={e => setSiForm({ ...siForm, description: e.target.value })} placeholder="e.g. किराया भुगतान" /></div>
                <div className="space-y-1">
                  <Label>आवृत्ति</Label>
                  <Select value={siForm.frequency} onValueChange={v => setSiForm({ ...siForm, frequency: v as typeof siForm.frequency })}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="once">एक बार</SelectItem>
                      <SelectItem value="daily">प्रतिदिन</SelectItem>
                      <SelectItem value="weekly">साप्ताहिक</SelectItem>
                      <SelectItem value="monthly">मासिक</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <Button onClick={handleCreateSI} disabled={createSIMut.isPending} className="w-full bg-purple-700 hover:bg-purple-800 text-white">
                  {createSIMut.isPending ? "SI बन रही है..." : "Auto-Pay बनाएं"}
                </Button>
              </CardContent>
            </Card>

            <Card>
              <CardHeader><CardTitle className="text-sm font-medium text-muted-foreground uppercase">सक्रिय Auto-Pay निर्देश</CardTitle></CardHeader>
              <CardContent className="space-y-2">
                <div className="flex gap-2">
                  <Input className="font-mono text-sm" placeholder="Account number" value={siLookup} onChange={e => setSiLookup(e.target.value)} />
                </div>
                {siList && siList.sis.length === 0 && <div className="text-sm text-muted-foreground text-center py-4">कोई SI नहीं</div>}
                {siList?.sis.map(si => (
                  <div key={si.id} className="border rounded-lg p-3 space-y-1 bg-purple-50/40">
                    <div className="flex justify-between items-center">
                      <div className="font-bold text-purple-800">₹{si.amount.toLocaleString("en-IN")} — {si.frequency}</div>
                      <span className={`text-xs px-2 py-0.5 rounded-full ${si.status === "active" ? "bg-green-100 text-green-800" : "bg-red-100 text-red-700"}`}>{si.status}</span>
                    </div>
                    <div className="text-xs text-muted-foreground">{si.description}</div>
                    <div className="text-xs text-muted-foreground">→ {si.toAccount} | अगली: {format(new Date(si.nextRunAt), "dd MMM yyyy")}</div>
                    {si.status === "active" && (
                      <Button size="sm" variant="outline" className="text-destructive border-destructive/30 text-xs h-7 mt-1"
                        onClick={() => { cancelSIMut.mutate({ siId: si.id }, { onSuccess: () => { toast({ title: "SI रद्द की" }); queryClient.invalidateQueries({ queryKey: getListSIsQueryKey(siLookup) }); } }); }}>
                        <X className="w-3 h-3 mr-1" /> रद्द करें
                      </Button>
                    )}
                  </div>
                ))}
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
