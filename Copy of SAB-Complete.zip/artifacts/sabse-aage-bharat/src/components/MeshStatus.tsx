import { useEffect, useState } from "react";
import { mesh, type MeshState, type MeshPeer } from "../lib/meshProtocol.js";

const STATE_CFG: Record<MeshState, { icon: string; label: string; color: string; bg: string }> = {
  online:  { icon: "🟢", label: "Online",      color: "#22c55e", bg: "#052e16" },
  mesh:    { icon: "🕸️",  label: "Mesh Active", color: "#f59e0b", bg: "#451a03" },
  offline: { icon: "🔴", label: "Offline",     color: "#ef4444", bg: "#450a0a" },
};

export default function MeshStatus() {
  const [state, setState] = useState<MeshState>("online");
  const [peers, setPeers] = useState<MeshPeer[]>([]);
  const [expanded, setExpanded] = useState(false);

  useEffect(() => {
    mesh.on("stateChange", s => setState(s));
    mesh.on("peerFound",   () => setPeers([...mesh.connectedPeers]));
    mesh.on("peerLost",    () => setPeers([...mesh.connectedPeers]));
    mesh.start();
    return () => mesh.stop();
  }, []);

  const cfg = STATE_CFG[state];

  return (
    <div style={{ position: "fixed", bottom: 72, right: 12, zIndex: 9000 }}>
      <button
        onClick={() => setExpanded(x => !x)}
        style={{
          background: cfg.bg, border: `1px solid ${cfg.color}`, borderRadius: 20,
          color: cfg.color, padding: "6px 12px", fontSize: 12, cursor: "pointer",
          display: "flex", alignItems: "center", gap: 6, fontFamily: "monospace",
        }}
      >
        {cfg.icon} {cfg.label}
        {peers.length > 0 && <span style={{ background: cfg.color, color: "#000", borderRadius: 10, padding: "0 6px", fontSize: 10 }}>{peers.length}</span>}
      </button>

      {expanded && (
        <div style={{
          position: "absolute", bottom: 36, right: 0, width: 220,
          background: "#0d1117", border: `1px solid ${cfg.color}`, borderRadius: 8,
          padding: 12, fontSize: 12, color: "#ccc", fontFamily: "monospace",
        }}>
          <div style={{ color: cfg.color, fontWeight: 700, marginBottom: 8 }}>
            🕸️ SAB Mesh — Protocol 13
          </div>
          <div style={{ marginBottom: 4 }}>
            <span style={{ color: "#666" }}>Peer ID:</span><br />
            <span style={{ color: "#fff", fontSize: 10 }}>{mesh.peerId}</span>
          </div>
          <div style={{ marginBottom: 4 }}>
            <span style={{ color: "#666" }}>Transport:</span> BLE + WebRTC
          </div>
          <div style={{ marginBottom: 4 }}>
            <span style={{ color: "#666" }}>Encryption:</span> AES-256-GCM
          </div>
          {peers.length === 0
            ? <div style={{ color: "#555", marginTop: 8 }}>कोई Peer नहीं मिला</div>
            : (
              <div style={{ marginTop: 8 }}>
                <div style={{ color: "#666", marginBottom: 4 }}>Connected Peers:</div>
                {peers.map(p => (
                  <div key={p.id} style={{ color: "#22c55e", fontSize: 10, marginBottom: 2 }}>
                    ▸ {p.id} [{p.transport.toUpperCase()}]
                  </div>
                ))}
              </div>
            )}
          <div style={{ marginTop: 8, color: "#555", fontSize: 10 }}>
            Hop-by-Hop · Zero-Trust · ऑफलाइन
          </div>
        </div>
      )}
    </div>
  );
}
