import { useEffect, useState } from "react";
import { SAB_shield } from "../lib/sabPrivacyShield.js";

interface SAB_Stats { allowed: number; blocked: number; cached: number; auditSize: number }

const SAB_POLL_MS = 3000;

export default function SABPrivacyStatus() {
  const [sab_stats, sab_setStats] = useState<SAB_Stats>({ allowed: 0, blocked: 0, cached: 0, auditSize: 0 });
  const [sab_open, sab_setOpen] = useState(false);
  const [sab_log, sab_setLog] = useState<{ url: string; method: string; blocked: boolean; ts: number }[]>([]);

  useEffect(() => {
    const sab_interval = setInterval(() => {
      sab_setStats(SAB_shield.sab_sandbox.sab_getStats());
      if (sab_open) sab_setLog(SAB_shield.sab_sandbox.sab_getAudit(12));
    }, SAB_POLL_MS);
    return () => clearInterval(sab_interval);
  }, [sab_open]);

  const sab_hasThreats = sab_stats.blocked > 0;

  return (
    <div style={{ position: "fixed", bottom: 112, right: 12, zIndex: 9001 }}>
      <button
        onClick={() => { sab_setOpen(o => !o); sab_setLog(SAB_shield.sab_sandbox.sab_getAudit(12)); }}
        title="SAB Zero-Knowledge Privacy Shield"
        style={{
          background: sab_hasThreats ? "#1a0000" : "#001a08",
          border: `1px solid ${sab_hasThreats ? "#ef4444" : "#22c55e"}`,
          borderRadius: 20, color: sab_hasThreats ? "#ef4444" : "#22c55e",
          padding: "6px 12px", fontSize: 12, cursor: "pointer",
          display: "flex", alignItems: "center", gap: 6, fontFamily: "monospace",
        }}
      >
        🛡️ Shield
        {sab_stats.blocked > 0 && (
          <span style={{ background: "#ef4444", color: "#fff", borderRadius: 10, padding: "0 5px", fontSize: 10 }}>
            {sab_stats.blocked}
          </span>
        )}
      </button>

      {sab_open && (
        <div style={{
          position: "absolute", bottom: 36, right: 0, width: 280,
          background: "#0d1117", border: "1px solid #22c55e", borderRadius: 8,
          padding: 12, fontSize: 11, color: "#ccc", fontFamily: "monospace",
        }}>
          <div style={{ color: "#22c55e", fontWeight: 700, marginBottom: 8 }}>
            🛡️ SAB Zero-Knowledge Shield — P14
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 4, marginBottom: 8 }}>
            {[
              ["✅ Allowed",  String(sab_stats.allowed),  "#22c55e"],
              ["🚫 Blocked",  String(sab_stats.blocked),  "#ef4444"],
              ["💾 Cached",   String(sab_stats.cached),   "#f59e0b"],
              ["📋 Audit",    String(sab_stats.auditSize), "#60a5fa"],
            ].map(([label, val, color]) => (
              <div key={label} style={{ background: "#161b22", borderRadius: 4, padding: "4px 8px" }}>
                <div style={{ color: "#666", fontSize: 10 }}>{label}</div>
                <div style={{ color, fontWeight: 700 }}>{val}</div>
              </div>
            ))}
          </div>

          <div style={{ marginBottom: 6, color: "#666", fontSize: 10 }}>RECENT REQUESTS</div>
          <div style={{ maxHeight: 140, overflowY: "auto" }}>
            {sab_log.length === 0
              ? <div style={{ color: "#444" }}>कोई request नहीं</div>
              : sab_log.slice().reverse().map((e, i) => (
                <div key={i} style={{ marginBottom: 3, display: "flex", gap: 4, alignItems: "center" }}>
                  <span style={{ color: e.blocked ? "#ef4444" : "#22c55e", fontSize: 10 }}>
                    {e.blocked ? "🚫" : "✓"}
                  </span>
                  <span style={{ color: "#888", fontSize: 9 }}>{e.method}</span>
                  <span style={{ color: "#aaa", fontSize: 9, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap", maxWidth: 180 }}>
                    {e.url.replace(/^https?:\/\//, "").slice(0, 40)}
                  </span>
                </div>
              ))}
          </div>

          <div style={{ marginTop: 8, paddingTop: 6, borderTop: "1px solid #222", fontSize: 9, color: "#444" }}>
            Zero-Knowledge · RAM Only · No Disk Storage
          </div>
        </div>
      )}
    </div>
  );
}
