import { useState, useEffect, useCallback } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { Fingerprint, ScanFace, KeyRound, ShieldCheck, AlertTriangle, Loader2 } from "lucide-react";

type BiometricMethod = "fingerprint" | "face" | "pin";
type GateState = "idle" | "scanning" | "success" | "failed" | "pin-fallback";

interface BiometricGateProps {
  open: boolean;
  onSuccess: () => void;
  onCancel: () => void;
  operationLabel: string;
  amount?: number;
}

// WebAuthn challenge bytes — explicit ArrayBuffer for BufferSource compatibility
function randomChallenge(): Uint8Array<ArrayBuffer> {
  const buf = new Uint8Array(new ArrayBuffer(32));
  crypto.getRandomValues(buf);
  return buf;
}

// Check if platform authenticator (fingerprint/face) is available
async function checkBiometricAvailable(): Promise<boolean> {
  try {
    if (!window.PublicKeyCredential) return false;
    return await PublicKeyCredential.isUserVerifyingPlatformAuthenticatorAvailable();
  } catch {
    return false;
  }
}

// WebAuthn: register a passkey (one-time, stored in device)
async function registerBiometric(): Promise<boolean> {
  try {
    const cred = await navigator.credentials.create({
      publicKey: {
        challenge: randomChallenge(),
        rp: { name: "SAB Core Banking", id: window.location.hostname },
        user: {
          id: new TextEncoder().encode("sab-owner"),
          name: "owner@sabpay",
          displayName: "SAB Owner",
        },
        pubKeyCredParams: [{ type: "public-key", alg: -7 }],
        authenticatorSelection: {
          authenticatorAttachment: "platform",
          userVerification: "required",
        },
        timeout: 30000,
      },
    });
    return !!cred;
  } catch {
    return false;
  }
}

// WebAuthn: authenticate with existing passkey
async function authenticateBiometric(): Promise<boolean> {
  try {
    const assertion = await navigator.credentials.get({
      publicKey: {
        challenge: randomChallenge(),
        userVerification: "required",
        timeout: 30000,
      },
    });
    return !!assertion;
  } catch {
    return false;
  }
}

const SAB_OWNER_PIN = "SAB2024";

export function BiometricGate({ open, onSuccess, onCancel, operationLabel, amount }: BiometricGateProps) {
  const [state, setState] = useState<GateState>("idle");
  const [method, setMethod] = useState<BiometricMethod>("fingerprint");
  const [biometricAvailable, setBiometricAvailable] = useState(false);
  const [pin, setPin] = useState("");
  const [pinError, setPinError] = useState("");
  const [pulseRing, setPulseRing] = useState(false);

  useEffect(() => {
    if (open) {
      setState("idle");
      setPin("");
      setPinError("");
      checkBiometricAvailable().then(setBiometricAvailable);
    }
  }, [open]);

  const runBiometric = useCallback(async (m: BiometricMethod) => {
    setMethod(m);
    setState("scanning");
    setPulseRing(true);

    try {
      let success = false;

      if (!biometricAvailable || window.location.protocol !== "https:") {
        // Dev mode: simulate 1.5s scan then success
        await new Promise(r => setTimeout(r, 1500));
        success = true;
      } else {
        // Try to authenticate first; if no credential registered, register one
        success = await authenticateBiometric();
        if (!success) success = await registerBiometric();
      }

      if (success) {
        setState("success");
        setTimeout(() => onSuccess(), 800);
      } else {
        setState("failed");
        setTimeout(() => setState("pin-fallback"), 1000);
      }
    } catch {
      setState("failed");
      setTimeout(() => setState("pin-fallback"), 1000);
    } finally {
      setPulseRing(false);
    }
  }, [biometricAvailable, onSuccess]);

  const verifyPin = () => {
    if (pin === SAB_OWNER_PIN) {
      setState("success");
      setTimeout(() => onSuccess(), 600);
    } else {
      setPinError("गलत PIN — पुनः प्रयास करें");
      setPin("");
      setTimeout(() => setPinError(""), 2000);
    }
  };

  const scannerColor = {
    idle: "text-primary",
    scanning: "text-secondary animate-pulse",
    success: "text-green-600",
    failed: "text-destructive",
    "pin-fallback": "text-muted-foreground",
  }[state];

  return (
    <Dialog open={open} onOpenChange={(o) => { if (!o) onCancel(); }}>
      <DialogContent className="max-w-sm">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-primary">
            <ShieldCheck className="w-5 h-5 text-secondary" />
            बायोमेट्रिक सत्यापन
          </DialogTitle>
          <DialogDescription>
            <span className="font-medium text-foreground">{operationLabel}</span>
            {amount ? <span className="text-secondary font-bold"> — ₹{amount.toLocaleString("en-IN")}</span> : null}
            <br />
            <span className="text-xs">इस ऑपरेशन के लिए पहचान सत्यापन आवश्यक है।</span>
          </DialogDescription>
        </DialogHeader>

        {state !== "pin-fallback" && (
          <div className="flex flex-col items-center py-6 gap-6">
            {/* Scanner animation */}
            <div className={`relative ${pulseRing ? "after:absolute after:inset-0 after:rounded-full after:border-2 after:border-secondary after:animate-ping" : ""}`}>
              <div className={`w-24 h-24 rounded-full border-4 flex items-center justify-center transition-colors duration-500 ${
                state === "success" ? "border-green-500 bg-green-50" :
                state === "failed" ? "border-destructive bg-destructive/10" :
                state === "scanning" ? "border-secondary bg-secondary/10" :
                "border-primary/30 bg-primary/5"
              }`}>
                {method === "fingerprint"
                  ? <Fingerprint className={`w-12 h-12 transition-colors duration-500 ${scannerColor}`} />
                  : method === "face"
                  ? <ScanFace className={`w-12 h-12 transition-colors duration-500 ${scannerColor}`} />
                  : <KeyRound className={`w-12 h-12 transition-colors duration-500 ${scannerColor}`} />
                }
              </div>
            </div>

            {/* Status text */}
            <div className="text-center">
              {state === "idle" && <p className="text-sm text-muted-foreground">स्कैन विधि चुनें</p>}
              {state === "scanning" && (
                <div className="flex items-center gap-2 text-secondary font-medium">
                  <Loader2 className="w-4 h-4 animate-spin" />
                  {method === "fingerprint" ? "फिंगरप्रिंट स्कैन हो रहा है..." : "चेहरा स्कैन हो रहा है..."}
                </div>
              )}
              {state === "success" && <p className="text-green-600 font-bold">सत्यापन सफल</p>}
              {state === "failed" && (
                <div className="flex items-center gap-2 text-destructive">
                  <AlertTriangle className="w-4 h-4" />
                  <span className="text-sm">सत्यापन विफल — PIN पर स्विच हो रहे हैं...</span>
                </div>
              )}
            </div>

            {/* Action buttons */}
            {state === "idle" && (
              <div className="grid grid-cols-2 gap-3 w-full">
                <Button
                  onClick={() => runBiometric("fingerprint")}
                  className="flex flex-col h-auto py-3 gap-1 bg-primary hover:bg-primary/90 text-white"
                >
                  <Fingerprint className="w-5 h-5" />
                  <span className="text-xs">Fingerprint</span>
                </Button>
                <Button
                  onClick={() => runBiometric("face")}
                  variant="outline"
                  className="flex flex-col h-auto py-3 gap-1 border-primary text-primary hover:bg-primary/10"
                >
                  <ScanFace className="w-5 h-5" />
                  <span className="text-xs">Face ID</span>
                </Button>
                <Button
                  onClick={() => setState("pin-fallback")}
                  variant="ghost"
                  className="col-span-2 text-muted-foreground text-xs h-8"
                >
                  PIN से सत्यापित करें
                </Button>
              </div>
            )}

            {/* Dev mode notice */}
            {window.location.protocol !== "https:" && state === "idle" && (
              <p className="text-xs text-amber-600 bg-amber-50 border border-amber-200 rounded px-2 py-1 text-center">
                Development Mode — Biometric simulated.<br />HTTPS पर real WebAuthn (FIDO2) काम करेगा।
              </p>
            )}
          </div>
        )}

        {/* PIN Fallback */}
        {state === "pin-fallback" && (
          <div className="space-y-4 py-4">
            <div className="flex items-center gap-2 text-center justify-center text-muted-foreground text-sm">
              <KeyRound className="w-4 h-4" />
              PIN से सत्यापित करें
            </div>
            <div className="space-y-2">
              <Label>SAB Security PIN</Label>
              <Input
                type="password"
                value={pin}
                onChange={e => { setPin(e.target.value); setPinError(""); }}
                onKeyDown={e => e.key === "Enter" && verifyPin()}
                placeholder="••••••••"
                className="text-center font-mono text-lg tracking-widest"
                autoFocus
              />
              {pinError && <p className="text-destructive text-xs text-center">{pinError}</p>}
            </div>
            <div className="grid grid-cols-2 gap-2">
              <Button onClick={onCancel} variant="ghost">रद्द करें</Button>
              <Button onClick={verifyPin} className="bg-primary text-white" disabled={!pin}>सत्यापित करें</Button>
            </div>
            <Button
              variant="link"
              className="w-full text-xs text-secondary"
              onClick={() => { setState("idle"); setPin(""); setPinError(""); }}
            >
              बायोमेट्रिक पर वापस जाएं
            </Button>
          </div>
        )}

        {state !== "pin-fallback" && state !== "success" && (
          <Button variant="ghost" size="sm" className="w-full text-muted-foreground text-xs" onClick={onCancel}>
            रद्द करें
          </Button>
        )}
      </DialogContent>
    </Dialog>
  );
}
