/* ============================================================
   SAB Install Prompt — PWA "Phone पर Install करें" बटन
   Listens for beforeinstallprompt, shows custom install UI
   RAM-only — no storage used
   ============================================================ */
import { useState, useEffect } from "react";

interface BeforeInstallPromptEvent extends Event {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: "accepted" | "dismissed" }>;
}

export default function SABInstallPrompt() {
  const [sab_prompt, sab_setPrompt] = useState<BeforeInstallPromptEvent | null>(null);
  const [sab_installed, sab_setInstalled] = useState(false);
  const [sab_installing, sab_setInstalling] = useState(false);
  const [sab_dismissed, sab_setDismissed] = useState(false);

  useEffect(() => {
    const sab_onPrompt = (e: Event) => {
      e.preventDefault();
      sab_setPrompt(e as BeforeInstallPromptEvent);
    };
    const sab_onInstalled = () => sab_setInstalled(true);

    window.addEventListener("beforeinstallprompt", sab_onPrompt);
    window.addEventListener("appinstalled", sab_onInstalled);

    if (window.matchMedia("(display-mode: standalone)").matches) {
      sab_setInstalled(true);
    }

    return () => {
      window.removeEventListener("beforeinstallprompt", sab_onPrompt);
      window.removeEventListener("appinstalled", sab_onInstalled);
    };
  }, []);

  const sab_install = async () => {
    if (!sab_prompt) return;
    sab_setInstalling(true);
    await sab_prompt.prompt();
    const { outcome } = await sab_prompt.userChoice;
    if (outcome === "accepted") sab_setInstalled(true);
    sab_setInstalling(false);
    sab_setPrompt(null);
  };

  if (sab_installed || sab_dismissed || !sab_prompt) return null;

  return (
    <div style={{
      position: "fixed", bottom: 160, left: "50%", transform: "translateX(-50%)",
      zIndex: 8999, width: "min(360px, 90vw)",
      background: "linear-gradient(135deg, #0a0e2e, #1a0a00)",
      border: "1px solid rgba(255,107,53,0.5)",
      borderRadius: 16, padding: "16px 20px",
      boxShadow: "0 8px 32px rgba(0,0,0,0.6)",
      display: "flex", flexDirection: "column", gap: 12,
    }}>
      <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
        <div style={{
          width: 48, height: 48, borderRadius: 12, flexShrink: 0,
          background: "rgba(255,107,53,0.15)", border: "1px solid rgba(255,107,53,0.4)",
          display: "flex", alignItems: "center", justifyContent: "center", fontSize: 24,
        }}>🇮🇳</div>
        <div>
          <div style={{ color: "#FF6B35", fontWeight: 700, fontSize: 14 }}>
            सबसे आगे भारत
          </div>
          <div style={{ color: "#9ca3af", fontSize: 11, marginTop: 2 }}>
            फोन पर Install करें — Offline काम करेगा
          </div>
        </div>
        <button
          onClick={() => sab_setDismissed(true)}
          style={{
            marginLeft: "auto", background: "none", border: "none",
            color: "#4b5563", cursor: "pointer", fontSize: 18, lineHeight: 1,
            padding: 4, flexShrink: 0,
          }}
          aria-label="बंद करें"
        >×</button>
      </div>

      <button
        onClick={sab_install}
        disabled={sab_installing}
        style={{
          width: "100%", padding: "11px 0", borderRadius: 10, border: "none",
          cursor: sab_installing ? "not-allowed" : "pointer",
          background: sab_installing
            ? "rgba(255,107,53,0.3)"
            : "linear-gradient(135deg, #FF6B35, #e85a20)",
          color: "#fff", fontWeight: 700, fontSize: 14,
          display: "flex", alignItems: "center", justifyContent: "center", gap: 8,
        }}
      >
        {sab_installing
          ? <><span>⟳</span> Install हो रहा है...</>
          : <><span>📲</span> अभी Install करें</>}
      </button>

      <div style={{ fontSize: 10, color: "#4b5563", textAlign: "center" }}>
        App Store की जरूरत नहीं — सीधे फोन में
      </div>
    </div>
  );
}
