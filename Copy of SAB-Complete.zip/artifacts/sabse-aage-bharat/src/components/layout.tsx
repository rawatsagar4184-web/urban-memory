import { useGetChainStats, getGetChainStatsQueryKey, useGetSystemStatus, getGetSystemStatusQueryKey } from "@workspace/api-client-react";
import { Link, useLocation } from "wouter";
import { 
  AlertCircle, LayoutDashboard, Wallet, ArrowRightLeft, Boxes, ShieldAlert,
  GraduationCap, Languages, Hammer, Landmark, Tractor, Users,
  LineChart, Trophy, Shield, Mic, Activity, Building2, Lock
} from "lucide-react";

export function Layout({ children }: { children: React.ReactNode }) {
  const [location] = useLocation();
  const { data: chainStats } = useGetChainStats({
    query: { queryKey: getGetChainStatsQueryKey(), refetchInterval: 5000 }
  });
  
  const { data: systemStatus } = useGetSystemStatus({
    query: { queryKey: getGetSystemStatusQueryKey(), refetchInterval: 10000 }
  });

  const isFrozen = chainStats?.isSystemFrozen;

  const navGroups = [
    {
      title: "COMMAND CENTER",
      items: [
        { href: "/", label: "🏠 होम (Users)", icon: LayoutDashboard },
        { href: "/command", label: "Matrix Control", icon: LayoutDashboard },
        { href: "/admin", label: "Admin Panel", icon: ShieldAlert },
        { href: "/banking", label: "Core Banking", icon: Building2 },
      ]
    },
    {
      title: "SAB BLOCKCHAIN",
      items: [
        { href: "/wallet", label: "Wallet Hub", icon: Wallet },
        { href: "/transfer", label: "Transfer SAB", icon: ArrowRightLeft },
        { href: "/blockchain", label: "Chain Explorer", icon: Boxes },
        { href: "/exchange", label: "Exchange", icon: LineChart },
      ]
    },
    {
      title: "SHIKSHA",
      items: [
        { href: "/academy", label: "IAS/IPS Academy", icon: GraduationCap },
        { href: "/language", label: "Language Academy", icon: Languages },
        { href: "/skills", label: "Hunar Kendra", icon: Hammer },
      ]
    },
    {
      title: "BHARAT SEVA",
      items: [
        { href: "/gov", label: "Digital Sarkar", icon: Landmark },
        { href: "/krishi", label: "Krishi Mitra", icon: Tractor },
      ]
    },
    {
      title: "SAMAJ",
      items: [
        { href: "/social", label: "Swadeshi Social", icon: Users },
        { href: "/creator", label: "Creator Economy", icon: Trophy },
      ]
    },
    {
      title: "SURAKSHA",
      items: [
        { href: "/security", label: "Cyber Wall", icon: Shield },
        { href: "/threat", label: "Cyber Shield", icon: Lock },
        { href: "/voice", label: "Khushi AI Voice", icon: Mic },
      ]
    }
  ];

  return (
    <div className="min-h-[100dvh] w-full flex flex-col md:flex-row bg-background">
      {/* Sidebar */}
      <aside className="w-full md:w-64 bg-primary text-primary-foreground flex flex-col shrink-0 overflow-y-auto">
        <div className="p-6 pb-2">
          <h1 className="text-2xl font-bold tracking-tight text-white">सबसे आगे भारत</h1>
          <p className="text-primary-foreground/70 text-sm mt-1">Sabse Aage Bharat</p>
        </div>
        <nav className="flex-1 px-4 py-4 flex flex-col gap-6">
          {navGroups.map((group) => (
            <div key={group.title}>
              <h2 className="text-xs font-bold text-secondary uppercase tracking-wider mb-2 px-4">{group.title}</h2>
              <div className="flex flex-col gap-1">
                {group.items.map((item) => {
                  const Icon = item.icon;
                  const active = location === item.href;
                  return (
                    <Link key={item.href} href={item.href} className="outline-none">
                      <div
                        data-testid={`link-nav-${item.label.replace(/\s+/g, '-').toLowerCase()}`}
                        className={`flex items-center gap-3 px-4 py-2 rounded-lg font-medium cursor-pointer transition-colors ${
                          active ? "bg-white/10 text-white" : "text-primary-foreground/80 hover:bg-white/5 hover:text-white"
                        }`}
                      >
                        <Icon className="w-4 h-4" />
                        <span className="text-sm">{item.label}</span>
                      </div>
                    </Link>
                  );
                })}
              </div>
            </div>
          ))}
        </nav>
        <div className="p-6 mt-auto">
          {systemStatus?.mode === "development" && (
            <div className="bg-yellow-500/20 border border-yellow-500/50 text-yellow-200 rounded-lg p-3 text-xs font-medium text-center mb-4 flex items-center justify-center gap-2">
              <Activity className="w-4 h-4" />
              DEVELOPMENT MODE
            </div>
          )}
          <div className="bg-white/10 rounded-lg p-4 text-sm text-center">
            <p className="font-bold text-white mb-1">Fixed Exchange Rate</p>
            <p className="text-secondary text-lg font-mono font-bold tracking-tight">100 SAB = ₹1</p>
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* System Banner */}
        {isFrozen && (
          <div className="bg-destructive text-destructive-foreground px-4 py-3 flex items-center justify-center gap-2 font-bold tracking-wide" data-testid="banner-system-frozen">
            <AlertCircle className="w-5 h-5" />
            SYSTEM FROZEN - All transactions halted by Owner
          </div>
        )}
        
        <main className="flex-1 p-6 md:p-10 overflow-auto">
          <div className="max-w-6xl mx-auto">
            {children}
          </div>
        </main>
      </div>
    </div>
  );
}
