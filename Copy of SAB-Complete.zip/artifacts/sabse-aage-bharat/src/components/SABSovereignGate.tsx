/* ============================================================
   SAB Sovereign Gate — Dual Biometric Access Control
   Owner: Sagar Bhai | SAB Digital Swaraj
   Step 1: Fingerprint (WebAuthn) → Step 2: Iris Scan (WebAuthn)
   RAM-only session — re-auth required on every page reload
   ============================================================ */

import { useState, useEffect, useCallback, useRef } from "react";

type ScanStep = "idle" | "step1-scanning" | "step1-done" | "step2-scanning" | "unlocked" | "denied" | "pin-fallback";

const SAB_OWNER_PIN = "SAB2024";
const DEV_MODE = window.location.protocol !== "https:";

async function sab_isBiometricAvailable(): Promise<boolean> {
  try {
    if (!window.PublicKeyCredential) return false;
    return await PublicKeyCredential.isUserVerifyingPlatformAuthenticatorAvailable();
  } catch { return false; }
}

function sab_randomChallenge(): Uint8Array<ArrayBuffer> {
  const buf = new Uint8Array(new ArrayBuffer(32));
  crypto.getRandomValues(buf);
  return buf;
}

async function sab_webauthnVerify(): Promise<boolean> {
  try {
    const assertion = await navigator.credentials.get({
      publicKey: { challenge: sab_randomChallenge(), userVerification: "required", timeout: 30000 },
    });
    if (assertion) return true;
    const cred = await navigator.credentials.create({
      publicKey: {
        challenge: sab_randomChallenge(),
        rp: { name: "SAB Sovereign", id: window.location.hostname },
        user: { id: new TextEncoder().encode("sab-sagar-bhai"), name: "sagar@sab", displayName: "Sagar Bhai" },
        pubKeyCredParams: [{ type: "public-key", alg: -7 }],
        authenticatorSelection: { authenticatorAttachment: "platform", userVerification: "required" },
        timeout: 30000,
      },
    });
    return !!cred;
  } catch { return false; }
}

function SAB_IrisScanAnimation({ active }: { active: boolean }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const frameRef = useRef<number>(0);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    let angle = 0;

    const draw = () => {
      ctx.clearRect(0, 0, 120, 120);
      const cx = 60, cy = 60;

      ctx.beginPath();
      ctx.arc(cx, cy, 50, 0, Math.PI * 2);
      ctx.strokeStyle = active ? "#FF6B35" : "#1A1F5C";
      ctx.lineWidth = 3;
      ctx.stroke();

      ctx.beginPath();
      ctx.arc(cx, cy, 35, 0, Math.PI * 2);
      ctx.strokeStyle = active ? "#ff8c5a" : "#2a3070";
      ctx.lineWidth = 2;
      ctx.stroke();

      if (active) {
        for (let i = 0; i < 12; i++) {
          const a = angle + (i * Math.PI * 2) / 12;
          ctx.beginPath();
          ctx.moveTo(cx + Math.cos(a) * 20, cy + Math.sin(a) * 20);
          ctx.lineTo(cx + Math.cos(a) * 46, cy + Math.sin(a) * 46);
          ctx.strokeStyle = `rgba(255,107,53,${0.3 + 0.5 * Math.abs(Math.sin(angle + i))})`;
          ctx.lineWidth = 1.5;
          ctx.stroke();
        }
        angle += 0.05;
      }

      ctx.beginPath();
      ctx.arc(cx, cy, 12, 0, Math.PI * 2);
      ctx.fillStyle = active ? "#FF6B35" : "#1A1F5C";
      ctx.fill();

      ctx.beginPath();
      ctx.arc(cx - 4, cy - 4, 4, 0, Math.PI * 2);
      ctx.fillStyle = "rgba(255,255,255,0.4)";
      ctx.fill();

      if (active) {
        ctx.beginPath();
        ctx.moveTo(0, cy);
        ctx.lineTo(120, cy);
        ctx.strokeStyle = `rgba(255,107,53,${0.6 + 0.4 * Math.sin(Date.now() / 150)})`;
        ctx.lineWidth = 1;
        ctx.stroke();
      }

      frameRef.current = requestAnimationFrame(draw);
    };

    frameRef.current = requestAnimationFrame(draw);
    return () => cancelAnimationFrame(frameRef.current);
  }, [active]);

  return <canvas ref={canvasRef} width={120} height={120} style={{ display: "block" }} />;
}

function SAB_FingerprintAnimation({ active }: { active: boolean }) {
  const lines = [28, 22, 18, 14, 12, 14, 18, 22, 28];
  return (
    <svg width={80} height={96} viewBox="0 0 80 96">
      {lines.map((r, i) => {
        const y = 12 + i * 9;
        const x1 = 40 - r, x2 = 40 + r;
        return (
          <line key={i} x1={x1} y1={y} x2={x2} y2={y}
            stroke={active ? "#FF6B35" : "#334155"}
            strokeWidth={2.5} strokeLinecap="round"
            style={{ transition: "stroke 0.3s", opacity: active ? 1 : 0.4 }}
          />
        );
      })}
      {active && (
        <rect x={0} y={0} width={80} height={96} rx={8}
          fill="rgba(255,107,53,0.12)"
          style={{ animation: "none" }}
        />
      )}
    </svg>
  );
}

interface SABSovereignGateProps { children: React.ReactNode }

export default function SABSovereignGate({ children }: SABSovereignGateProps) {
  const [step, setStep] = useState<ScanStep>("idle");
  const [progress, setProgress] = useState(0);
  const [pin, setPin] = useState("");
  const [pinError, setPinError] = useState("");
  const [unlocked, setUnlocked] = useState(false);
  const [biometricAvailable, setBiometricAvailable] = useState(false);
  const [statusMsg, setStatusMsg] = useState("स्वागत है — पहचान सत्यापन आवश्यक है");
  const [failCount, setFailCount] = useState(0);
  const progressRef = useRef<ReturnType<typeof setInterval> | null>(null);

  useEffect(() => {
    sab_isBiometricAvailable().then(setBiometricAvailable);
  }, []);

  const animateProgress = useCallback((from: number, to: number, onDone?: () => void) => {
    if (progressRef.current) clearInterval(progressRef.current);
    let cur = from;
    progressRef.current = setInterval(() => {
      cur += 1;
      setProgress(cur);
      if (cur >= to) {
        if (progressRef.current) clearInterval(progressRef.current);
        onDone?.();
      }
    }, 18);
  }, []);

  const sab_runFingerprint = useCallback(async () => {
    setStep("step1-scanning");
    setStatusMsg("फिंगरप्रिंट स्कैन हो रहा है...");
    animateProgress(0, 48);

    let success = false;
    if (DEV_MODE || !biometricAvailable) {
      await new Promise(r => setTimeout(r, 2000));
      success = true;
    } else {
      success = await sab_webauthnVerify();
    }

    if (progressRef.current) clearInterval(progressRef.current);

    if (success) {
      setProgress(50);
      setStep("step1-done");
      setStatusMsg("✅ फिंगरप्रिंट सत्यापित — आंखों का स्कैन करें");
    } else {
      setFailCount(f => f + 1);
      setStep("denied");
      setStatusMsg("❌ फिंगरप्रिंट विफल");
      setTimeout(() => { setStep("pin-fallback"); setStatusMsg("PIN से सत्यापित करें"); }, 1200);
    }
  }, [biometricAvailable, animateProgress]);

  const sab_runIris = useCallback(async () => {
    setStep("step2-scanning");
    setStatusMsg("आंखों का स्कैन हो रहा है...");
    animateProgress(50, 98);

    let success = false;
    if (DEV_MODE || !biometricAvailable) {
      await new Promise(r => setTimeout(r, 2500));
      success = true;
    } else {
      success = await sab_webauthnVerify();
    }

    if (progressRef.current) clearInterval(progressRef.current);

    if (success) {
      setProgress(100);
      setStep("unlocked");
      setStatusMsg("🔓 सम्पूर्ण सत्यापन — स्वागत है, सागर भाई");
      setTimeout(() => setUnlocked(true), 1200);
    } else {
      setFailCount(f => f + 1);
      setStep("denied");
      setStatusMsg("❌ Iris स्कैन विफल");
      setTimeout(() => { setStep("pin-fallback"); setStatusMsg("PIN से सत्यापित करें"); }, 1200);
    }
  }, [biometricAvailable, animateProgress]);

  const sab_verifyPin = useCallback(() => {
    if (pin === SAB_OWNER_PIN) {
      setProgress(100);
      setStep("unlocked");
      setStatusMsg("🔓 PIN सत्यापित — स्वागत है, सागर भाई");
      setTimeout(() => setUnlocked(true), 1000);
    } else {
      setFailCount(f => f + 1);
      setPinError("गलत PIN — पुनः प्रयास करें");
      setPin("");
      setTimeout(() => setPinError(""), 2000);
    }
  }, [pin]);

  if (unlocked) return <>{children}</>;

  const isScanning = step === "step1-scanning" || step === "step2-scanning";
  const isDenied = step === "denied";

  return (
    <div style={{
      position: "fixed", inset: 0, zIndex: 99999,
      background: "linear-gradient(135deg, #0a0e2e 0%, #0f1635 50%, #1a0a00 100%)",
      display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center",
      fontFamily: "'Segoe UI', system-ui, sans-serif",
    }}>
      {/* Top badge */}
      <div style={{
        position: "absolute", top: 24, left: "50%", transform: "translateX(-50%)",
        display: "flex", alignItems: "center", gap: 10,
      }}>
        <div style={{ fontSize: 28 }}>🇮🇳</div>
        <div>
          <div style={{ color: "#FF6B35", fontWeight: 800, fontSize: 16, letterSpacing: 2 }}>सबसे आगे भारत</div>
          <div style={{ color: "#6b7280", fontSize: 10, letterSpacing: 3, textTransform: "uppercase" }}>Sovereign Digital Platform</div>
        </div>
      </div>

      {/* Main card */}
      <div style={{
        width: "min(420px, 92vw)",
        background: "rgba(255,255,255,0.04)",
        border: "1px solid rgba(255,107,53,0.25)",
        borderRadius: 20, padding: "36px 32px",
        backdropFilter: "blur(12px)",
        boxShadow: "0 24px 80px rgba(0,0,0,0.6), inset 0 1px 0 rgba(255,255,255,0.06)",
      }}>
        {/* Header */}
        <div style={{ textAlign: "center", marginBottom: 28 }}>
          <div style={{
            display: "inline-flex", alignItems: "center", justifyContent: "center",
            width: 56, height: 56, borderRadius: "50%",
            background: "rgba(255,107,53,0.12)", border: "2px solid rgba(255,107,53,0.4)",
            marginBottom: 14,
          }}>
            <span style={{ fontSize: 26 }}>🔐</span>
          </div>
          <div style={{ color: "#FF6B35", fontWeight: 800, fontSize: 18, letterSpacing: 1 }}>
            SOVEREIGN ACCESS
          </div>
          <div style={{ color: "#9ca3af", fontSize: 12, marginTop: 4 }}>
            {statusMsg}
          </div>
        </div>

        {/* Progress bar */}
        <div style={{ marginBottom: 28 }}>
          <div style={{ display: "flex", justifyContent: "space-between", fontSize: 10, color: "#6b7280", marginBottom: 6 }}>
            <span>फिंगरप्रिंट</span>
            <span style={{ color: "#FF6B35", fontWeight: 700 }}>{progress}%</span>
            <span>Iris स्कैन</span>
          </div>
          <div style={{ height: 6, background: "rgba(255,255,255,0.08)", borderRadius: 999, overflow: "hidden" }}>
            <div style={{
              height: "100%", borderRadius: 999, transition: "width 0.12s linear",
              width: `${progress}%`,
              background: progress === 100
                ? "linear-gradient(90deg, #22c55e, #16a34a)"
                : "linear-gradient(90deg, #FF6B35, #ff9a6b)",
              boxShadow: progress > 0 ? "0 0 8px rgba(255,107,53,0.6)" : "none",
            }} />
          </div>
          <div style={{ display: "flex", justifyContent: "center", gap: 24, marginTop: 8 }}>
            <span style={{ fontSize: 9, color: progress >= 50 ? "#22c55e" : "#374151", transition: "color 0.3s" }}>
              {progress >= 50 ? "✅" : "○"} Step 1
            </span>
            <span style={{ fontSize: 9, color: progress >= 100 ? "#22c55e" : "#374151", transition: "color 0.3s" }}>
              {progress >= 100 ? "✅" : "○"} Step 2
            </span>
          </div>
        </div>

        {/* Scan area */}
        {step !== "pin-fallback" && (
          <div style={{ display: "flex", gap: 20, justifyContent: "center", alignItems: "center", marginBottom: 28 }}>
            {/* Fingerprint */}
            <div style={{ textAlign: "center" }}>
              <div style={{
                width: 100, height: 116, display: "flex", alignItems: "center", justifyContent: "center",
                borderRadius: 12, border: `2px solid ${step === "step1-scanning" ? "#FF6B35" : progress >= 50 ? "#22c55e" : "rgba(255,255,255,0.1)"}`,
                background: step === "step1-scanning" ? "rgba(255,107,53,0.08)" : "rgba(255,255,255,0.03)",
                transition: "all 0.3s", cursor: step === "idle" || step === "step1-done" ? "default" : "default",
                boxShadow: step === "step1-scanning" ? "0 0 20px rgba(255,107,53,0.3)" : "none",
              }}>
                <SAB_FingerprintAnimation active={step === "step1-scanning"} />
              </div>
              <div style={{ fontSize: 10, color: "#9ca3af", marginTop: 6 }}>
                {progress >= 50 ? <span style={{ color: "#22c55e" }}>✅ सत्यापित</span> : "फिंगरप्रिंट"}
              </div>
            </div>

            <div style={{ color: "#374151", fontSize: 20 }}>→</div>

            {/* Iris */}
            <div style={{ textAlign: "center" }}>
              <div style={{
                width: 100, height: 116, display: "flex", alignItems: "center", justifyContent: "center",
                borderRadius: 12, border: `2px solid ${step === "step2-scanning" ? "#FF6B35" : progress >= 100 ? "#22c55e" : "rgba(255,255,255,0.1)"}`,
                background: step === "step2-scanning" ? "rgba(255,107,53,0.08)" : "rgba(255,255,255,0.03)",
                transition: "all 0.3s",
                boxShadow: step === "step2-scanning" ? "0 0 20px rgba(255,107,53,0.3)" : "none",
              }}>
                <SAB_IrisScanAnimation active={step === "step2-scanning"} />
              </div>
              <div style={{ fontSize: 10, color: "#9ca3af", marginTop: 6 }}>
                {progress >= 100 ? <span style={{ color: "#22c55e" }}>✅ सत्यापित</span> : "Iris स्कैन"}
              </div>
            </div>
          </div>
        )}

        {/* Action buttons */}
        {(step === "idle") && (
          <button
            onClick={sab_runFingerprint}
            style={{
              width: "100%", padding: "14px 0", borderRadius: 10, border: "none", cursor: "pointer",
              background: "linear-gradient(135deg, #FF6B35, #e85a20)",
              color: "#fff", fontWeight: 700, fontSize: 15, letterSpacing: 0.5,
              boxShadow: "0 4px 20px rgba(255,107,53,0.4)",
              display: "flex", alignItems: "center", justifyContent: "center", gap: 10,
            }}
          >
            <span style={{ fontSize: 18 }}>👆</span>
            फिंगरप्रिंट स्कैन शुरू करें
          </button>
        )}

        {(step === "step1-done") && (
          <button
            onClick={sab_runIris}
            style={{
              width: "100%", padding: "14px 0", borderRadius: 10, border: "none", cursor: "pointer",
              background: "linear-gradient(135deg, #1A1F5C, #2a3070)",
              color: "#fff", fontWeight: 700, fontSize: 15, letterSpacing: 0.5,
              boxShadow: "0 4px 20px rgba(26,31,92,0.5)",
              display: "flex", alignItems: "center", justifyContent: "center", gap: 10,
            }}
          >
            <span style={{ fontSize: 18 }}>👁️</span>
            Iris स्कैन शुरू करें
          </button>
        )}

        {isScanning && (
          <div style={{
            width: "100%", padding: "14px 0", borderRadius: 10, textAlign: "center",
            background: "rgba(255,107,53,0.08)", border: "1px solid rgba(255,107,53,0.2)",
            color: "#FF6B35", fontWeight: 700, fontSize: 14,
            display: "flex", alignItems: "center", justifyContent: "center", gap: 8,
          }}>
            <span style={{ display: "inline-block", animation: "spin 1s linear infinite" }}>⟳</span>
            स्कैन प्रक्रिया जारी है...
          </div>
        )}

        {isDenied && (
          <div style={{
            width: "100%", padding: "12px", borderRadius: 10, textAlign: "center",
            background: "rgba(239,68,68,0.1)", border: "1px solid rgba(239,68,68,0.3)",
            color: "#ef4444", fontWeight: 700, fontSize: 13,
          }}>
            ⚠️ प्रमाणीकरण विफल ({failCount} प्रयास)
          </div>
        )}

        {step === "unlocked" && (
          <div style={{
            width: "100%", padding: "14px", borderRadius: 10, textAlign: "center",
            background: "rgba(34,197,94,0.12)", border: "1px solid rgba(34,197,94,0.4)",
            color: "#22c55e", fontWeight: 800, fontSize: 15,
          }}>
            🔓 प्रवेश स्वीकृत — सिस्टम लोड हो रहा है...
          </div>
        )}

        {/* PIN fallback */}
        {step === "pin-fallback" && (
          <div style={{ display: "flex", flexDirection: "column", gap: 0 }}>
            <div style={{ textAlign: "center", marginBottom: 16, color: "#9ca3af", fontSize: 13 }}>
              🔑 SAB Security PIN दर्ज करें
            </div>
            <input
              type="password"
              value={pin}
              onChange={e => { setPin(e.target.value); setPinError(""); }}
              onKeyDown={e => e.key === "Enter" && sab_verifyPin()}
              placeholder="••••••••"
              autoFocus
              style={{
                width: "100%", padding: "12px 16px", borderRadius: 10, border: "1px solid rgba(255,107,53,0.3)",
                background: "rgba(255,255,255,0.05)", color: "#fff", fontSize: 18,
                textAlign: "center", letterSpacing: 6, outline: "none", fontFamily: "monospace",
                boxSizing: "border-box",
              }}
            />
            {pinError && (
              <div style={{ color: "#ef4444", fontSize: 12, textAlign: "center", marginTop: 8 }}>{pinError}</div>
            )}
            <button
              onClick={sab_verifyPin}
              disabled={!pin}
              style={{
                width: "100%", marginTop: 14, padding: "12px 0", borderRadius: 10, border: "none",
                cursor: pin ? "pointer" : "not-allowed",
                background: pin ? "linear-gradient(135deg, #FF6B35, #e85a20)" : "rgba(255,255,255,0.08)",
                color: pin ? "#fff" : "#6b7280", fontWeight: 700, fontSize: 14,
              }}
            >
              सत्यापित करें
            </button>
            <button
              onClick={() => { setStep("idle"); setProgress(0); setPin(""); setPinError(""); setStatusMsg("बायोमेट्रिक से पुनः प्रयास करें"); }}
              style={{
                width: "100%", marginTop: 8, padding: "8px 0", borderRadius: 8, border: "none",
                background: "transparent", color: "#FF6B35", cursor: "pointer", fontSize: 12,
              }}
            >
              बायोमेट्रिक पर वापस जाएं
            </button>
          </div>
        )}

        {/* Skip for PIN */}
        {step === "idle" && (
          <button
            onClick={() => { setStep("pin-fallback"); setStatusMsg("PIN से सत्यापित करें"); }}
            style={{
              width: "100%", marginTop: 10, padding: "8px 0", background: "transparent",
              border: "none", color: "#6b7280", fontSize: 11, cursor: "pointer",
            }}
          >
            PIN से सत्यापित करें
          </button>
        )}
      </div>

      {/* Dev mode notice */}
      {DEV_MODE && (
        <div style={{
          position: "absolute", bottom: 20, left: "50%", transform: "translateX(-50%)",
          background: "rgba(245,158,11,0.12)", border: "1px solid rgba(245,158,11,0.3)",
          borderRadius: 8, padding: "6px 16px", fontSize: 10, color: "#f59e0b",
          whiteSpace: "nowrap",
        }}>
          🔧 Dev Mode — Biometric simulated | Production पर real WebAuthn (FIDO2) काम करेगा
        </div>
      )}

      <style>{`@keyframes spin { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }`}</style>
    </div>
  );
}
