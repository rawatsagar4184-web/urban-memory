import { Copy, Check } from "lucide-react";
import { useState } from "react";
import { Button } from "@/components/ui/button";

export function CopyableHash({ hash }: { hash: string }) {
  const [copied, setCopied] = useState(false);
  
  if (!hash) return <span className="text-muted-foreground">-</span>;
  
  const truncated = hash.length > 16 ? `${hash.slice(0, 8)}...${hash.slice(-8)}` : hash;

  const onCopy = () => {
    navigator.clipboard.writeText(hash);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="flex items-center gap-2">
      <span className="font-mono text-sm text-foreground">{truncated}</span>
      <Button variant="ghost" size="icon" className="h-6 w-6" onClick={onCopy} data-testid={`button-copy-${hash}`}>
        {copied ? <Check className="h-3 w-3 text-success" /> : <Copy className="h-3 w-3" />}
      </Button>
    </div>
  );
}
