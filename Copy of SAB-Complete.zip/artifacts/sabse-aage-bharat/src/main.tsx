import { createRoot } from "react-dom/client";
import App from "./App";
import "./index.css";
import { sab_startPing } from "./lib/sabSessionPing";

sab_startPing();

if ("serviceWorker" in navigator) {
  window.addEventListener("load", () => {
    navigator.serviceWorker.register("/sw.js").catch(() => {});
  });
}

createRoot(document.getElementById("root")!).render(<App />);
