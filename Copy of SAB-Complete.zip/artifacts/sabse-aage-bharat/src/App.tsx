import { Switch, Route, Router as WouterRouter, useLocation } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";

import { Layout } from "@/components/layout";
import { SABHome } from "@/pages/home";
import { Dashboard } from "@/pages/dashboard";
import { WalletHub } from "@/pages/wallet";
import { Transfer } from "@/pages/transfer";
import { BlockchainExplorer } from "@/pages/blockchain";
import { AdminPanel } from "@/pages/admin";
import { Academy } from "@/pages/academy";
import { Language } from "@/pages/language";
import { Skills } from "@/pages/skills";
import { Gov } from "@/pages/gov";
import { Krishi } from "@/pages/krishi";
import { Social } from "@/pages/social";
import { Exchange } from "@/pages/exchange";
import { Creator } from "@/pages/creator";
import { Security } from "@/pages/security";
import { Voice } from "@/pages/voice";
import { Banking } from "@/pages/banking";
import { ThreatIntelligence } from "@/pages/threat";
import { Scanner } from "@/pages/scanner";
import MeshStatus from "@/components/MeshStatus";
import SABPrivacyStatus from "@/components/SABPrivacyStatus";
import SABInstallPrompt from "@/components/SABInstallPrompt";
import { SAB_shield } from "@/lib/sabPrivacyShield";

SAB_shield.sab_install();

const queryClient = new QueryClient({
  defaultOptions: { queries: { retry: 1, refetchOnWindowFocus: false } },
});

function LayoutedRoutes() {
  return (
    <Layout>
      <Switch>
        <Route path="/command" component={Dashboard} />
        <Route path="/wallet" component={WalletHub} />
        <Route path="/transfer" component={Transfer} />
        <Route path="/blockchain" component={BlockchainExplorer} />
        <Route path="/explorer" component={BlockchainExplorer} />
        <Route path="/admin" component={AdminPanel} />
        <Route path="/banking" component={Banking} />
        <Route path="/academy" component={Academy} />
        <Route path="/language" component={Language} />
        <Route path="/skills" component={Skills} />
        <Route path="/gov" component={Gov} />
        <Route path="/krishi" component={Krishi} />
        <Route path="/social" component={Social} />
        <Route path="/exchange" component={Exchange} />
        <Route path="/creator" component={Creator} />
        <Route path="/security" component={Security} />
        <Route path="/threat" component={ThreatIntelligence} />
        <Route path="/voice" component={Voice} />
        <Route path="/scanner" component={Scanner} />
        <Route component={NotFound} />
      </Switch>
    </Layout>
  );
}

function Router() {
  const [location] = useLocation();
  if (location === "/") return <SABHome />;
  return <LayoutedRoutes />;
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
          <Router />
        </WouterRouter>
        <SABPrivacyStatus />
        <MeshStatus />
        <SABInstallPrompt />
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
