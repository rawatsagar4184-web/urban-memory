import { generatePeerId } from "./meshCrypto.js";
import { storePacket, flushToServer, type MeshPacket } from "./meshStore.js";

export type MeshState = "online" | "mesh" | "offline";

export interface MeshPeer {
  id: string;
  transport: "ble" | "webrtc";
  connectedAt: number;
}

interface MeshEvents {
  stateChange: (s: MeshState) => void;
  peerFound:   (p: MeshPeer) => void;
  peerLost:    (id: string)  => void;
  packetRx:    (pkt: MeshPacket) => void;
}

const LOCAL_ID = (() => {
  let id = localStorage.getItem("sab-peer-id");
  if (!id) { id = generatePeerId(); localStorage.setItem("sab-peer-id", id); }
  return id;
})();

const SAB_BLE_UUID = "0000FEA6-0000-1000-8000-00805F9B34FB";

class MeshProtocol {
  private state: MeshState = "online";
  private peers = new Map<string, MeshPeer>();
  private handlers: Partial<MeshEvents> = {};
  private rtcPeers = new Map<string, RTCPeerConnection>();
  private channels = new Map<string, RTCDataChannel>();
  private onlineHandler = () => this.handleOnline();
  private offlineHandler = () => this.handleOffline();
  private bleScan = false;

  get peerId() { return LOCAL_ID; }
  get currentState() { return this.state; }
  get connectedPeers() { return Array.from(this.peers.values()); }

  on<K extends keyof MeshEvents>(event: K, fn: MeshEvents[K]) {
    this.handlers[event] = fn as MeshEvents[K];
  }

  start() {
    window.addEventListener("online",  this.onlineHandler);
    window.addEventListener("offline", this.offlineHandler);
    if (!navigator.onLine) this.handleOffline();
    window.addEventListener("online", () => {
      void flushToServer(window.location.origin).then(n => {
        if (n > 0) console.info(`[SAB Mesh] Synced ${n} offline packets`);
      });
    });
  }

  stop() {
    window.removeEventListener("online",  this.onlineHandler);
    window.removeEventListener("offline", this.offlineHandler);
    this.bleScan = false;
    this.rtcPeers.forEach(pc => pc.close());
    this.rtcPeers.clear();
    this.channels.clear();
    this.peers.clear();
    this.setState("online");
  }

  private setState(s: MeshState) {
    if (this.state === s) return;
    this.state = s;
    this.handlers.stateChange?.(s);
  }

  private handleOnline() {
    this.bleScan = false;
    this.setState("online");
  }

  private handleOffline() {
    this.setState("mesh");
    void this.scanBLE();
    this.advertiseWebRTC();
  }

  private addPeer(id: string, transport: "ble" | "webrtc") {
    if (this.peers.has(id)) return;
    const p: MeshPeer = { id, transport, connectedAt: Date.now() };
    this.peers.set(id, p);
    this.handlers.peerFound?.(p);
  }

  private removePeer(id: string) {
    this.peers.delete(id);
    this.handlers.peerLost?.(id);
  }

  private async scanBLE() {
    if (!("bluetooth" in navigator)) return;
    this.bleScan = true;
    try {
      const device = await (navigator as unknown as { bluetooth: { requestDevice: (o: unknown) => Promise<{ gatt?: { connect: () => Promise<{ getPrimaryService: (u: string) => Promise<{ getCharacteristic: (u: string) => Promise<{ readValue: () => Promise<DataView> }> }> }> }; addEventListener: (e: string, h: () => void) => void }> } })
        .bluetooth.requestDevice({
          filters: [{ services: [SAB_BLE_UUID] }],
          optionalServices: [SAB_BLE_UUID],
        });
      if (!this.bleScan) return;
      const server = await device.gatt?.connect();
      if (!server) return;
      const svc = await server.getPrimaryService(SAB_BLE_UUID);
      const chr = await svc.getCharacteristic(SAB_BLE_UUID);
      const val = await chr.readValue();
      const peerId = new TextDecoder().decode(val);
      this.addPeer(peerId, "ble");
      device.addEventListener("gattserverdisconnected", () => this.removePeer(peerId));
    } catch { /* user cancelled or BLE unavailable */ }
  }

  private advertiseWebRTC() {
    const bc = new BroadcastChannel("sab-mesh-signaling");
    bc.onmessage = async (e: MessageEvent<{ type: string; from: string; sdp?: RTCSessionDescriptionInit; candidate?: RTCIceCandidateInit }>) => {
      const msg = e.data;
      if (msg.from === LOCAL_ID) return;
      if (msg.type === "offer" && msg.sdp) {
        const pc = this.createPC(msg.from);
        await pc.setRemoteDescription(new RTCSessionDescription(msg.sdp));
        const ans = await pc.createAnswer();
        await pc.setLocalDescription(ans);
        bc.postMessage({ type: "answer", from: LOCAL_ID, to: msg.from, sdp: ans });
      } else if (msg.type === "answer" && msg.sdp) {
        const pc = this.rtcPeers.get(msg.from);
        if (pc) await pc.setRemoteDescription(new RTCSessionDescription(msg.sdp));
      } else if (msg.type === "ice" && msg.candidate) {
        const pc = this.rtcPeers.get(msg.from);
        if (pc) await pc.addIceCandidate(new RTCIceCandidate(msg.candidate));
      }
    };
    const pc = this.createPC("broadcast");
    const dc = pc.createDataChannel("sab");
    dc.onopen = () => this.addPeer("broadcast", "webrtc");
    pc.createOffer().then(o => { void pc.setLocalDescription(o); bc.postMessage({ type: "offer", from: LOCAL_ID, sdp: o }); });
  }

  private createPC(peerId: string): RTCPeerConnection {
    const pc = new RTCPeerConnection({ iceServers: [] });
    this.rtcPeers.set(peerId, pc);
    pc.onicecandidate = e => {
      if (e.candidate) new BroadcastChannel("sab-mesh-signaling")
        .postMessage({ type: "ice", from: LOCAL_ID, to: peerId, candidate: e.candidate });
    };
    pc.ondatachannel = e => this.setupChannel(peerId, e.channel);
    pc.onconnectionstatechange = () => {
      if (pc.connectionState === "disconnected" || pc.connectionState === "closed") this.removePeer(peerId);
    };
    return pc;
  }

  private setupChannel(peerId: string, dc: RTCDataChannel) {
    this.channels.set(peerId, dc);
    dc.onopen  = () => this.addPeer(peerId, "webrtc");
    dc.onclose = () => this.removePeer(peerId);
    dc.onmessage = async e => {
      try {
        const pkt = JSON.parse(e.data as string) as MeshPacket;
        pkt.hops.push(LOCAL_ID);
        await storePacket(pkt);
        this.handlers.packetRx?.(pkt);
        if (pkt.to !== LOCAL_ID) this.forward(pkt, peerId);
      } catch { /* bad packet */ }
    };
  }

  async send(to: string, type: MeshPacket["type"], payload: string): Promise<void> {
    const pkt: MeshPacket = {
      id: crypto.randomUUID(), from: LOCAL_ID, to, type, payload,
      hops: [LOCAL_ID], ts: Date.now(), synced: false,
    };
    await storePacket(pkt);
    this.forward(pkt, null);
  }

  private forward(pkt: MeshPacket, exceptPeer: string | null) {
    const data = JSON.stringify(pkt);
    this.channels.forEach((dc, id) => {
      if (id !== exceptPeer && dc.readyState === "open") dc.send(data);
    });
  }
}

export const mesh = new MeshProtocol();
