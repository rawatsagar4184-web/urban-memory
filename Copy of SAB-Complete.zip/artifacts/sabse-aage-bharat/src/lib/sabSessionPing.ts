/* ============================================================
   SAB Session Ping — Public user heartbeat
   Generates RAM-only session ID, pings server every 60s
   Server tracks live count. ID never stored to disk.
   ============================================================ */

const SAB_SESSION_ID: string = `sab-${crypto.randomUUID()}`;
const SAB_PING_INTERVAL_MS = 60_000;

let sab_pingTimer: ReturnType<typeof setInterval> | null = null;

function sab_currentPage(): string {
  return window.location.pathname || "/";
}

async function sab_sendPing(): Promise<void> {
  try {
    await fetch("/api/admin/ping", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ sessionId: SAB_SESSION_ID, page: sab_currentPage() }),
    });
  } catch { /* silent — offline is fine */ }
}

export function sab_startPing(): void {
  if (sab_pingTimer) return;
  void sab_sendPing(); // immediate first ping
  sab_pingTimer = setInterval(() => { void sab_sendPing(); }, SAB_PING_INTERVAL_MS);
}

export function sab_stopPing(): void {
  if (sab_pingTimer) { clearInterval(sab_pingTimer); sab_pingTimer = null; }
}

export { SAB_SESSION_ID };
