import { deriveKey, encrypt, decrypt } from "./meshCrypto.js";

const DB_NAME = "sab-mesh";
const STORE = "queue";
const VERSION = 1;
const MESH_SECRET = "SAB_MESH_SHARED_KEY_2024";

export interface MeshPacket {
  id: string;
  from: string;
  to: string;
  type: "msg" | "file" | "data";
  payload: string;
  hops: string[];
  ts: number;
  synced: boolean;
}

function openDB(): Promise<IDBDatabase> {
  return new Promise((res, rej) => {
    const req = indexedDB.open(DB_NAME, VERSION);
    req.onupgradeneeded = () => req.result.createObjectStore(STORE, { keyPath: "id" });
    req.onsuccess = () => res(req.result);
    req.onerror = () => rej(req.error);
  });
}

export async function storePacket(pkt: MeshPacket): Promise<void> {
  const key = await deriveKey(MESH_SECRET);
  const encPayload = await encrypt(key, JSON.stringify(pkt));
  const db = await openDB();
  await new Promise<void>((res, rej) => {
    const tx = db.transaction(STORE, "readwrite");
    tx.objectStore(STORE).put({ id: pkt.id, data: encPayload, synced: false });
    tx.oncomplete = () => res();
    tx.onerror = () => rej(tx.error);
  });
  db.close();
}

export async function getPendingPackets(): Promise<MeshPacket[]> {
  const key = await deriveKey(MESH_SECRET);
  const db = await openDB();
  const rows: { id: string; data: string }[] = await new Promise((res, rej) => {
    const tx = db.transaction(STORE, "readonly");
    const req = tx.objectStore(STORE).getAll();
    req.onsuccess = () => res(req.result);
    req.onerror = () => rej(req.error);
  });
  db.close();
  const pkts: MeshPacket[] = [];
  for (const r of rows) {
    try { pkts.push(JSON.parse(await decrypt(key, r.data)) as MeshPacket); } catch { /* skip corrupt */ }
  }
  return pkts.filter(p => !p.synced);
}

export async function markSynced(ids: string[]): Promise<void> {
  const db = await openDB();
  const tx = db.transaction(STORE, "readwrite");
  const store = tx.objectStore(STORE);
  for (const id of ids) {
    const req = store.get(id);
    req.onsuccess = () => {
      if (req.result) store.put({ ...req.result, synced: true });
    };
  }
  await new Promise<void>((res, rej) => {
    tx.oncomplete = () => res();
    tx.onerror = () => rej(tx.error);
  });
  db.close();
}

export async function flushToServer(apiBase: string): Promise<number> {
  const pkts = await getPendingPackets();
  if (pkts.length === 0) return 0;
  try {
    const res = await fetch(`${apiBase}/api/mesh/sync`, {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ packets: pkts }),
    });
    if (!res.ok) return 0;
    await markSynced(pkts.map(p => p.id));
    return pkts.length;
  } catch { return 0; }
}
