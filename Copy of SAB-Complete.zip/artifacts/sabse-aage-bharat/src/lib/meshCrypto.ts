const ENC = "AES-GCM";
const KEY_LEN = 256;
const IV_LEN = 12;

export async function deriveKey(secret: string): Promise<CryptoKey> {
  const raw = await crypto.subtle.importKey(
    "raw", new TextEncoder().encode(secret), "PBKDF2", false, ["deriveKey"]
  );
  return crypto.subtle.deriveKey(
    { name: "PBKDF2", salt: new TextEncoder().encode("SAB-MESH-SALT-2024"), iterations: 100_000, hash: "SHA-256" },
    raw, { name: ENC, length: KEY_LEN }, false, ["encrypt", "decrypt"]
  );
}

export async function encrypt(key: CryptoKey, data: string): Promise<string> {
  const iv = crypto.getRandomValues(new Uint8Array(IV_LEN));
  const cipher = await crypto.subtle.encrypt(
    { name: ENC, iv }, key, new TextEncoder().encode(data)
  );
  const buf = new Uint8Array(IV_LEN + cipher.byteLength);
  buf.set(iv, 0);
  buf.set(new Uint8Array(cipher), IV_LEN);
  return btoa(String.fromCharCode(...buf));
}

export async function decrypt(key: CryptoKey, encoded: string): Promise<string> {
  const buf = Uint8Array.from(atob(encoded), c => c.charCodeAt(0));
  const iv = buf.slice(0, IV_LEN);
  const cipher = buf.slice(IV_LEN);
  const plain = await crypto.subtle.decrypt({ name: ENC, iv }, key, cipher);
  return new TextDecoder().decode(plain);
}

export function generatePeerId(): string {
  return `SAB-${crypto.randomUUID().slice(0, 8).toUpperCase()}`;
}
