/* ============================================================
   SAB Zero-Knowledge Privacy Shield — Protocol 14
   All data stays in RAM. Nothing touches disk.
   Prefix contract: vars = sab_*, classes/consts = SAB_*
   ============================================================ */

const SAB_VERSION = "1.0.0";
const SAB_TRACKING_HEADERS = new Set([
  "x-forwarded-for", "x-real-ip", "cf-connecting-ip",
  "x-client-id", "x-device-id", "x-fingerprint",
  "x-analytics-id", "x-session-id", "x-tracking-id",
]);
const SAB_BLOCKED_DOMAINS = new Set([
  "google-analytics.com", "googletagmanager.com", "doubleclick.net",
  "facebook.com", "fb.com", "fbcdn.net", "analytics.yahoo.com",
  "hotjar.com", "mixpanel.com", "segment.io", "amplitude.com",
  "clarity.ms", "mouseflow.com", "fullstory.com",
]);

/* ── Ephemeral RAM Sandbox ── */
interface SAB_CacheEntry { body: string; status: number; headers: Record<string, string>; ts: number }
interface SAB_AuditEntry { url: string; method: string; blocked: boolean; ts: number; origin: "fetch" | "xhr" }

class SAB_Sandbox {
  private sab_cache   = new Map<string, SAB_CacheEntry>();
  private sab_audit   = new Array<SAB_AuditEntry>();
  private sab_blocked = 0;
  private sab_allowed = 0;

  sab_cacheKey(url: string, method: string) { return `${method}:${url}`; }

  sab_read(key: string): SAB_CacheEntry | undefined {
    const e = this.sab_cache.get(key);
    if (!e) return undefined;
    if (Date.now() - e.ts > 60_000) { this.sab_cache.delete(key); return undefined; }
    return e;
  }

  sab_write(key: string, entry: SAB_CacheEntry) {
    if (this.sab_cache.size > 200) {
      const first = this.sab_cache.keys().next().value;
      if (first !== undefined) this.sab_cache.delete(first);
    }
    this.sab_cache.set(key, entry);
  }

  sab_log(entry: SAB_AuditEntry) {
    if (this.sab_audit.length >= 500) this.sab_audit.shift();
    this.sab_audit.push(entry);
    entry.blocked ? this.sab_blocked++ : this.sab_allowed++;
  }

  sab_getStats() {
    return { allowed: this.sab_allowed, blocked: this.sab_blocked, cached: this.sab_cache.size, auditSize: this.sab_audit.length };
  }

  sab_getAudit(last = 20) { return this.sab_audit.slice(-last); }

  sab_purge() { this.sab_cache.clear(); this.sab_audit.length = 0; this.sab_blocked = 0; this.sab_allowed = 0; }
}

/* ── Helpers ── */
function sab_isDomainBlocked(url: string): boolean {
  try {
    const host = new URL(url).hostname.replace(/^www\./, "");
    for (const d of SAB_BLOCKED_DOMAINS) if (host === d || host.endsWith(`.${d}`)) return true;
  } catch { /* relative URL — safe */ }
  return false;
}

function sab_sanitizeHeaders(init?: RequestInit): RequestInit {
  const headers = new Headers(init?.headers ?? {});
  for (const h of SAB_TRACKING_HEADERS) headers.delete(h);
  return { ...init, headers };
}

function sab_blockedResponse(url: string): Response {
  return new Response(JSON.stringify({ sab_blocked: true, url }), {
    status: 403, headers: { "Content-Type": "application/json", "X-SAB-Shield": "blocked" },
  });
}

/* ── Storage Guard ── */
function sab_installStorageGuard() {
  const sab_guard = (target: Storage) => {
    const sab_origSetItem = target.setItem.bind(target);
    Object.defineProperty(target, "setItem", {
      value: (key: string, value: string) => {
        if (key.startsWith("sab-") || key.startsWith("SAB-")) {
          sab_origSetItem(key, value);
        } else {
          SAB_shield.sab_sandbox.sab_log({ url: `storage:${key}`, method: "WRITE_BLOCKED", blocked: true, ts: Date.now(), origin: "fetch" });
        }
      },
      writable: false, configurable: false,
    });
  };
  sab_guard(window.localStorage);
  sab_guard(window.sessionStorage);
}

/* ── Main Shield Class ── */
export class SAB_PrivacyShield {
  readonly sab_sandbox = new SAB_Sandbox();
  private sab_active = false;
  private sab_origFetch = window.fetch.bind(window);
  private sab_origXHROpen = XMLHttpRequest.prototype.open;

  sab_install() {
    if (this.sab_active) return;
    this.sab_active = true;
    this.sab_patchFetch();
    this.sab_patchXHR();
    sab_installStorageGuard();
    console.info(`[SAB Shield v${SAB_VERSION}] Installed — Zero-Knowledge mode active`);
  }

  sab_uninstall() {
    if (!this.sab_active) return;
    window.fetch = this.sab_origFetch;
    XMLHttpRequest.prototype.open = this.sab_origXHROpen;
    this.sab_active = false;
    this.sab_sandbox.sab_purge();
    console.info("[SAB Shield] Uninstalled");
  }

  get sab_isActive() { return this.sab_active; }

  private sab_patchFetch() {
    const self = this;
    window.fetch = async function sab_fetch(input: RequestInfo | URL, init?: RequestInit): Promise<Response> {
      const url = typeof input === "string" ? input : input instanceof URL ? input.href : input.url;
      const method = init?.method?.toUpperCase() ?? "GET";

      if (sab_isDomainBlocked(url)) {
        self.sab_sandbox.sab_log({ url, method, blocked: true, ts: Date.now(), origin: "fetch" });
        return sab_blockedResponse(url);
      }

      const key = self.sab_sandbox.sab_cacheKey(url, method);
      if (method === "GET") {
        const cached = self.sab_sandbox.sab_read(key);
        if (cached) {
          self.sab_sandbox.sab_log({ url, method, blocked: false, ts: Date.now(), origin: "fetch" });
          return new Response(cached.body, { status: cached.status, headers: cached.headers });
        }
      }

      const cleanInit = sab_sanitizeHeaders(init);
      const res = await self.sab_origFetch(input, cleanInit);
      self.sab_sandbox.sab_log({ url, method, blocked: false, ts: Date.now(), origin: "fetch" });

      if (method === "GET" && res.ok) {
        const clone = res.clone();
        clone.text().then(body => {
          self.sab_sandbox.sab_write(key, {
            body, status: res.status,
            headers: Object.fromEntries(res.headers.entries()),
            ts: Date.now(),
          });
        }).catch(() => { /* non-text body — skip cache */ });
      }

      return res;
    };
  }

  private sab_patchXHR() {
    const self = this;
    const sab_origOpen = this.sab_origXHROpen;
    XMLHttpRequest.prototype.open = function sab_xhrOpen(method: string, url: string | URL, ...args: unknown[]) {
      const urlStr = url.toString();
      if (sab_isDomainBlocked(urlStr)) {
        self.sab_sandbox.sab_log({ url: urlStr, method, blocked: true, ts: Date.now(), origin: "xhr" });
        return;
      }
      self.sab_sandbox.sab_log({ url: urlStr, method, blocked: false, ts: Date.now(), origin: "xhr" });
      return (sab_origOpen as (...a: unknown[]) => void).call(this, method, url, ...args);
    };
  }
}

export const SAB_shield = new SAB_PrivacyShield();
