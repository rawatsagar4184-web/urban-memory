/* ============================================================
   SAB Service Worker — Offline Cache + PWA Support
   Cache strategy: Network-first for API, Cache-first for assets
   ============================================================ */

const SAB_CACHE = "sab-v1";
const SAB_ASSETS = [
  "/",
  "/manifest.json",
];

self.addEventListener("install", (e) => {
  e.waitUntil(
    caches.open(SAB_CACHE).then(c => c.addAll(SAB_ASSETS)).then(() => self.skipWaiting())
  );
});

self.addEventListener("activate", (e) => {
  e.waitUntil(
    caches.keys().then(keys =>
      Promise.all(keys.filter(k => k !== SAB_CACHE).map(k => caches.delete(k)))
    ).then(() => self.clients.claim())
  );
});

self.addEventListener("fetch", (e) => {
  const url = new URL(e.request.url);

  /* API calls — network first, no cache */
  if (url.pathname.startsWith("/api/")) {
    e.respondWith(fetch(e.request).catch(() =>
      new Response(JSON.stringify({ error: "offline", sab: true }), {
        status: 503, headers: { "Content-Type": "application/json" }
      })
    ));
    return;
  }

  /* Assets — cache first, fallback to network */
  e.respondWith(
    caches.match(e.request).then(cached => {
      if (cached) return cached;
      return fetch(e.request).then(res => {
        if (res.ok) {
          const clone = res.clone();
          caches.open(SAB_CACHE).then(c => c.put(e.request, clone));
        }
        return res;
      }).catch(() => caches.match("/"));
    })
  );
});
