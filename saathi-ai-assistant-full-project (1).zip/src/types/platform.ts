export type PlatformCategory = 
  | 'ecommerce'
  | 'saas'
  | 'edtech'
  | 'booking'
  | 'realestate'
  | 'ai_tools'
  | 'community';

export interface PlatformItem {
  id: string;
  category: PlatformCategory;
  titleHindi: string;
  titleEnglish: string;
  taglineHindi: string;
  descriptionHindi: string;
  image?: string;
  featuredModules: string[];
  techStack: {
    frontend: string;
    backend: string;
    database: string;
    integrations: string[];
  };
  sampleUseCasesHindi: string[];
  keyBenefitsHindi: string[];
  estimatedTimeline: string;
}

export interface ArchitecturePlanInput {
  industry: string;
  scale: 'mvp' | 'growth' | 'enterprise';
  features: string[];
  userRoles: string[];
  databaseType: 'firestore' | 'postgresql' | 'hybrid';
  aiEnabled: boolean;
  notes: string;
}

export interface GeneratedBlueprint {
  title: string;
  summaryHindi: string;
  frontendStack: string[];
  backendStack: string[];
  databaseSchema: {
    collectionOrTable: string;
    fields: string[];
    description: string;
  }[];
  implementationPhases: {
    phase: string;
    duration: string;
    tasks: string[];
  }[];
  suggestedPrompt: string;
}
