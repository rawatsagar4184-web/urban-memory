import React from 'react';
import { Sparkles, ArrowRight, Download } from 'lucide-react';

interface HeaderProps {
  onPlanClick: () => void;
  onExploreClick: () => void;
  onDemoClick: () => void;
  onAiClick: () => void;
  onGuardianClick: () => void;
  onMasterClick: () => void;
  onTrainingClick: () => void;
  onCrossDeviceClick: () => void;
  onSecurityClick: () => void;
  onTechClick: () => void;
  onFaqClick: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  onPlanClick,
  onExploreClick,
  onDemoClick,
  onAiClick,
  onGuardianClick,
  onMasterClick,
  onTrainingClick,
  onCrossDeviceClick,
  onSecurityClick,
  onTechClick,
  onFaqClick,
}) => {
  return (
    <header className="sticky top-0 z-40 bg-[#090D16]/95 backdrop-blur-md border-b border-slate-800/80">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
        {/* Zone 1: Single text element wordmark (Top Bar Contract) */}
        <a 
          href="#" 
          className="text-lg font-bold tracking-tight text-white hover:text-amber-400 transition-colors flex items-center gap-2.5"
        >
          <span className="w-2.5 h-2.5 rounded-full bg-amber-400 inline-block animate-pulse"></span>
          <span>साथी (Saathi) AI</span>
          <span className="text-[11px] font-normal text-amber-400/90 bg-amber-500/10 border border-amber-500/30 px-2 py-0.5 rounded-full hidden sm:inline">
            मालिक: सागर रावत
          </span>
        </a>

        {/* Zone 2: 4-6 clean text navigation links */}
        <nav className="hidden lg:flex items-center gap-3 text-xs xl:text-sm font-medium text-slate-300">
          <button 
            onClick={onSecurityClick}
            className="text-emerald-400 hover:text-emerald-300 transition-colors cursor-pointer whitespace-nowrap flex items-center gap-1 font-bold px-2 py-1 rounded-md bg-emerald-500/10 border border-emerald-500/25"
          >
            <span>🔒 एंटी-हैक वॉल्ट</span>
          </button>
          <button 
            onClick={onCrossDeviceClick}
            className="text-sky-400 hover:text-sky-300 transition-colors cursor-pointer whitespace-nowrap flex items-center gap-1 font-bold px-2 py-1 rounded-md bg-sky-500/10 border border-sky-500/25"
          >
            <span>📱💻 फोन+लैपटॉप सिंक</span>
          </button>
          <button 
            onClick={onTrainingClick}
            className="text-amber-400 hover:text-amber-300 transition-colors cursor-pointer whitespace-nowrap flex items-center gap-1.5 font-bold"
          >
            <span>🎓 ट्रेनिंग स्टूडियो</span>
          </button>
          <button 
            onClick={onMasterClick}
            className="text-amber-300 hover:text-white transition-colors cursor-pointer whitespace-nowrap flex items-center gap-1.5 font-semibold"
          >
            <span>👑 मालिक कंट्रोल</span>
          </button>
          <button 
            onClick={onAiClick}
            className="text-indigo-400 hover:text-indigo-300 transition-colors cursor-pointer whitespace-nowrap flex items-center gap-1.5 font-semibold"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>साथी से चैट</span>
          </button>
        </nav>

        {/* Zone 3: 1-2 primary actions */}
        <div className="flex items-center gap-2">
          <a
            href="/api/download/zip"
            download="saathi-ai-assistant-full-project.zip"
            className="inline-flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-semibold text-cyan-300 bg-cyan-950/60 hover:bg-cyan-900/60 border border-cyan-500/40 rounded-lg transition-colors shadow-sm whitespace-nowrap cursor-pointer"
            title="मालिक सागर, पूरी प्रोजेक्ट ZIP फ़ाइल डाउनलोड करें"
          >
            <Download className="w-3.5 h-3.5 text-cyan-400" />
            <span className="hidden sm:inline">डाउनलोड</span> ZIP
          </a>
          <button
            onClick={onSecurityClick}
            className="inline-flex lg:hidden items-center gap-1 px-2.5 py-1.5 text-xs font-semibold text-emerald-300 bg-emerald-500/15 border border-emerald-500/30 rounded-lg cursor-pointer"
          >
            <span>🔒 वॉल्ट</span>
          </button>
          <button
            onClick={onTrainingClick}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold text-slate-950 bg-amber-400 hover:bg-amber-300 rounded-lg transition-colors shadow-sm whitespace-nowrap cursor-pointer"
          >
            <span>साथी को सिखाएं</span>
            <ArrowRight className="w-3 h-3 hidden sm:inline" />
          </button>
        </div>
      </div>
    </header>
  );
};
