import React, { useState } from 'react';
import { 
  ShoppingBag, 
  LayoutDashboard, 
  Calendar, 
  Plus, 
  Minus, 
  Trash2, 
  CheckCircle2, 
  ArrowRight, 
  Clock, 
  UserCheck, 
  TrendingUp, 
  DollarSign, 
  Users as UsersIcon,
  Sparkles,
  RefreshCw
} from 'lucide-react';

export const LivePrototypes: React.FC = () => {
  const [activeDemo, setActiveDemo] = useState<'ecommerce' | 'saas' | 'booking'>('ecommerce');

  // --- 1. E-Commerce State ---
  const initialProducts = [
    { id: 1, name: 'प्रो नॉइज़-कैंसलिंग हेडफ़ोन', price: 2999, category: 'ऑडियो', rating: 4.8 },
    { id: 2, name: 'फिटनेस ट्रैकर स्मार्टवॉच v2', price: 3499, category: 'वेयरेबल्स', rating: 4.9 },
    { id: 3, name: 'एर्गोनॉमिक एल्युमिनियम लैपटॉप स्टैंड', price: 1499, category: 'ऑफिस', rating: 4.7 },
  ];
  const [cart, setCart] = useState<{ id: number; name: string; price: number; qty: number }[]>([
    { id: 1, name: 'प्रो नॉइज़-कैंसलिंग हेडफ़ोन', price: 2999, qty: 1 }
  ]);
  const [promoCode, setPromoCode] = useState('');
  const [discountApplied, setDiscountApplied] = useState(false);
  const [orderConfirmed, setOrderConfirmed] = useState(false);

  const addToCart = (product: typeof initialProducts[0]) => {
    setOrderConfirmed(false);
    setCart(prev => {
      const existing = prev.find(item => item.id === product.id);
      if (existing) {
        return prev.map(item => item.id === product.id ? { ...item, qty: item.qty + 1 } : item);
      }
      return [...prev, { id: product.id, name: product.name, price: product.price, qty: 1 }];
    });
  };

  const updateQty = (id: number, delta: number) => {
    setCart(prev => prev.map(item => {
      if (item.id === id) {
        const newQty = item.qty + delta;
        return newQty > 0 ? { ...item, qty: newQty } : null;
      }
      return item;
    }).filter(Boolean) as typeof cart);
  };

  const subtotal = cart.reduce((acc, curr) => acc + curr.price * curr.qty, 0);
  const discountAmount = discountApplied ? Math.round(subtotal * 0.1) : 0;
  const grandTotal = subtotal - discountAmount;

  // --- 2. SaaS CRM State ---
  const [pipelineDeals, setPipelineDeals] = useState([
    { id: 'd1', company: 'एपेक्स लॉजिस्टिक्स प्रा. लि.', value: '₹1,50,000', stage: 'नया लीड' },
    { id: 'd2', company: 'ग्लोबल टेक सॉल्यूशंस', value: '₹3,20,000', stage: 'प्रस्ताव भेजा' },
    { id: 'd3', company: 'शर्मा रिटेल स्टोर्स', value: '₹95,000', stage: 'संपर्क किया' },
    { id: 'd4', company: 'वेदांत बायोफार्मा', value: '₹4,80,000', stage: 'डील फाइनल' }
  ]);
  const [selectedTimeframe, setSelectedTimeframe] = useState<'30d' | '90d' | '12m'>('30d');

  const advanceStage = (dealId: string) => {
    const stages = ['नया लीड', 'संपर्क किया', 'प्रस्ताव भेजा', 'डील फाइनल'];
    setPipelineDeals(prev => prev.map(deal => {
      if (deal.id === dealId) {
        const curIdx = stages.indexOf(deal.stage);
        const nextStage = stages[(curIdx + 1) % stages.length];
        return { ...deal, stage: nextStage };
      }
      return deal;
    }));
  };

  // --- 3. Booking State ---
  const doctors = [
    { id: 'doc1', name: 'डॉ. राजेश शर्मा', specialty: 'कार्डियोलॉजिस्ट (हृदय रोग)', exp: '14+ वर्ष अनुभव', fee: '₹800' },
    { id: 'doc2', name: 'डॉ. प्रिया वर्मा', specialty: 'डर्मेटोलॉजिस्ट (त्वचा विशेषज्ञ)', exp: '9+ वर्ष अनुभव', fee: '₹700' },
    { id: 'doc3', name: 'डॉ. अमित कपूर', specialty: 'जनरल फिजिशियन', exp: '12+ वर्ष अनुभव', fee: '₹500' }
  ];
  const [selectedDoc, setSelectedDoc] = useState(doctors[0]);
  const [selectedDate, setSelectedDate] = useState('कल (10:00 AM - 1:00 PM)');
  const [selectedSlot, setSelectedSlot] = useState('11:30 AM');
  const [bookingConfirmed, setBookingConfirmed] = useState(false);

  return (
    <section id="demos" className="py-16 md:py-24 bg-slate-950/60 border-b border-slate-800/80">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="max-w-3xl mb-10">
          <div className="text-xs font-semibold text-indigo-400 tracking-wider uppercase mb-2">
            Interactive Working Sandboxes
          </div>
          <h2 className="text-2xl sm:text-3xl md:text-4xl font-bold text-white tracking-tight text-balance">
            लाइव प्रोटोटाइप्स: अनुभव करें कि आपका ऐप कैसा काम करेगा
          </h2>
          <p className="mt-3 text-base text-slate-300">
            नीचे दिए गए मिनी-एप्लिकेशन्स में बटन दबाकर देखें। यह दिखाता है कि हम आपके लिए कितने स्मूथ और फंक्शनल इंटरफेस तैयार कर सकते हैं।
          </p>
        </div>

        {/* Demo Switcher Tabs */}
        <div className="flex flex-wrap items-center gap-2 p-1.5 bg-slate-900 border border-slate-800 rounded-xl mb-8 w-fit">
          <button
            onClick={() => setActiveDemo('ecommerce')}
            className={`inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold rounded-lg transition-colors cursor-pointer ${
              activeDemo === 'ecommerce'
                ? 'bg-indigo-600 text-white'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <ShoppingBag className="w-4 h-4" />
            <span>ई-कॉमर्स स्टोर डेमो</span>
          </button>

          <button
            onClick={() => setActiveDemo('saas')}
            className={`inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold rounded-lg transition-colors cursor-pointer ${
              activeDemo === 'saas'
                ? 'bg-indigo-600 text-white'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <LayoutDashboard className="w-4 h-4" />
            <span>SaaS बिजनेस डैशबोर्ड डेमो</span>
          </button>

          <button
            onClick={() => setActiveDemo('booking')}
            className={`inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold rounded-lg transition-colors cursor-pointer ${
              activeDemo === 'booking'
                ? 'bg-indigo-600 text-white'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Calendar className="w-4 h-4" />
            <span>अपॉइंटमेंट शेड्यूलर डेमो</span>
          </button>
        </div>

        {/* Sandbox Container */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 sm:p-8 shadow-xl">
          
          {/* DEMO 1: E-COMMERCE */}
          {activeDemo === 'ecommerce' && (
            <div className="space-y-8 animate-in fade-in duration-300">
              
              <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-800 pb-4">
                <div>
                  <h3 className="text-lg font-bold text-white">डिजिटल स्टोरफ्रंट व लाइव कार्ट इंजन</h3>
                  <p className="text-xs text-slate-400 mt-0.5">प्रोडक्ट जोड़ें, डिस्काउंट कोड लगाएं और चेकआउट सिमुलेट करें</p>
                </div>
                <div className="text-xs text-indigo-400 font-mono">
                  कार्ट में आइटम्स: {cart.reduce((a, b) => a + b.qty, 0)}
                </div>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
                {/* Product Catalog */}
                <div className="lg:col-span-7 space-y-4">
                  <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-400">
                    प्रोडक्ट सूची (क्लिक करके कार्ट में जोड़ें)
                  </h4>
                  <div className="space-y-3">
                    {initialProducts.map(p => (
                      <div 
                        key={p.id}
                        className="bg-slate-950/70 p-4 rounded-xl border border-slate-800 flex items-center justify-between gap-4 hover:border-slate-700 transition-colors"
                      >
                        <div>
                          <div className="text-sm font-semibold text-white">{p.name}</div>
                          <div className="flex items-center gap-2 text-xs text-slate-400 mt-1">
                            <span>{p.category}</span>
                            <span aria-hidden="true">·</span>
                            <span>★ {p.rating}</span>
                          </div>
                        </div>
                        <div className="flex items-center gap-4">
                          <span className="text-sm font-bold text-white tabular-nums">
                            ₹{p.price.toLocaleString('en-IN')}
                          </span>
                          <button
                            onClick={() => addToCart(p)}
                            className="px-3 py-1.5 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-500 rounded-lg transition-colors cursor-pointer inline-flex items-center gap-1"
                          >
                            <Plus className="w-3.5 h-3.5" />
                            <span>कार्ट में डालें</span>
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Cart & Checkout */}
                <div className="lg:col-span-5 bg-slate-950 p-5 rounded-xl border border-slate-800 flex flex-col justify-between">
                  <div>
                    <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-400 mb-3 flex items-center justify-between">
                      <span>आपकी शॉपिंग कार्ट</span>
                      {cart.length > 0 && (
                        <button 
                          onClick={() => setCart([])} 
                          className="text-xs text-rose-400 hover:text-rose-300 cursor-pointer flex items-center gap-1"
                        >
                          <Trash2 className="w-3 h-3" /> खाली करें
                        </button>
                      )}
                    </h4>

                    {cart.length === 0 ? (
                      <div className="py-8 text-center text-xs text-slate-500">
                        आपकी कार्ट खाली है। बाईं तरफ से कोई प्रोडक्ट जोड़ें।
                      </div>
                    ) : (
                      <div className="space-y-2.5 max-h-48 overflow-y-auto pr-1">
                        {cart.map(item => (
                          <div key={item.id} className="flex items-center justify-between text-xs bg-slate-900/80 p-2.5 rounded-lg border border-slate-800">
                            <span className="text-slate-200 font-medium truncate max-w-[150px]">{item.name}</span>
                            <div className="flex items-center gap-2 shrink-0">
                              <span className="text-slate-400 tabular-nums">₹{item.price * item.qty}</span>
                              <div className="flex items-center gap-1 bg-slate-800 rounded px-1.5 py-0.5">
                                <button 
                                  onClick={() => updateQty(item.id, -1)}
                                  className="text-slate-400 hover:text-white p-0.5 cursor-pointer"
                                >
                                  <Minus className="w-3 h-3" />
                                </button>
                                <span className="tabular-nums font-semibold text-white px-1">{item.qty}</span>
                                <button 
                                  onClick={() => updateQty(item.id, 1)}
                                  className="text-slate-400 hover:text-white p-0.5 cursor-pointer"
                                >
                                  <Plus className="w-3 h-3" />
                                </button>
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}

                    {/* Promo code */}
                    {cart.length > 0 && (
                      <div className="mt-4 pt-3 border-t border-slate-800 flex gap-2">
                        <input
                          type="text"
                          value={promoCode}
                          onChange={(e) => setPromoCode(e.target.value)}
                          placeholder="कूपन कोड डालें (उदा: SAVE10)"
                          className="flex-1 bg-slate-900 text-xs text-white px-3 py-1.5 rounded-lg border border-slate-700 focus:outline-none focus:border-indigo-500"
                        />
                        <button
                          onClick={() => {
                            if (promoCode.trim().toUpperCase() === 'SAVE10') {
                              setDiscountApplied(true);
                            }
                          }}
                          className="px-3 py-1.5 text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-white rounded-lg cursor-pointer"
                        >
                          लागू करें
                        </button>
                      </div>
                    )}
                    {discountApplied && (
                      <div className="text-[11px] text-emerald-400 mt-1 flex items-center gap-1">
                        <CheckCircle2 className="w-3 h-3" /> 10% कूपन डिस्काउंट लागू हो गया!
                      </div>
                    )}
                  </div>

                  {/* Summary & Checkout Button */}
                  <div className="mt-4 pt-4 border-t border-slate-800">
                    <div className="space-y-1.5 text-xs text-slate-400 mb-4">
                      <div className="flex justify-between">
                        <span>सबटोटल:</span>
                        <span className="tabular-nums text-slate-200">₹{subtotal.toLocaleString('en-IN')}</span>
                      </div>
                      {discountApplied && (
                        <div className="flex justify-between text-emerald-400">
                          <span>छूट (10%):</span>
                          <span className="tabular-nums">-₹{discountAmount.toLocaleString('en-IN')}</span>
                        </div>
                      )}
                      <div className="flex justify-between text-sm font-bold text-white pt-1 border-t border-slate-800">
                        <span>कुल देय राशि:</span>
                        <span className="tabular-nums text-indigo-400">₹{grandTotal.toLocaleString('en-IN')}</span>
                      </div>
                    </div>

                    {orderConfirmed ? (
                      <div className="p-3 bg-emerald-950/60 border border-emerald-800 rounded-lg text-center animate-in zoom-in-95">
                        <CheckCircle2 className="w-5 h-5 text-emerald-400 mx-auto mb-1" />
                        <div className="text-xs font-bold text-emerald-300">ऑर्डर सफल! (#ORD-8942)</div>
                        <div className="text-[11px] text-emerald-400/80 mt-0.5">कस्टमर को SMS व इनवॉइस ईमेल भेज दिया गया</div>
                      </div>
                    ) : (
                      <button
                        disabled={cart.length === 0}
                        onClick={() => setOrderConfirmed(true)}
                        className={`w-full py-2.5 text-xs font-semibold rounded-lg transition-colors cursor-pointer flex items-center justify-center gap-2 ${
                          cart.length > 0 
                            ? 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-sm' 
                            : 'bg-slate-800 text-slate-500 cursor-not-allowed'
                        }`}
                      >
                        <Sparkles className="w-3.5 h-3.5" />
                        <span>सुरक्षित चेकआउट सिमुलेट करें</span>
                      </button>
                    )}
                  </div>

                </div>
              </div>

            </div>
          )}

          {/* DEMO 2: SAAS DASHBOARD */}
          {activeDemo === 'saas' && (
            <div className="space-y-6 animate-in fade-in duration-300">
              
              <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-800 pb-4">
                <div>
                  <h3 className="text-lg font-bold text-white">B2B CRM व रेवेन्यू ट्रैकर</h3>
                  <p className="text-xs text-slate-400 mt-0.5">लीड्स का स्टेटस बदलें और रियल-टाइम मेट्रिक्स का प्रवाह देखें</p>
                </div>
                <div className="flex items-center gap-1 bg-slate-950 p-1 rounded-lg border border-slate-800">
                  {(['30d', '90d', '12m'] as const).map(tf => (
                    <button
                      key={tf}
                      onClick={() => setSelectedTimeframe(tf)}
                      className={`px-2.5 py-1 text-xs rounded font-medium cursor-pointer ${
                        selectedTimeframe === tf ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-white'
                      }`}
                    >
                      {tf === '30d' ? '30 दिन' : tf === '90d' ? '3 माह' : '1 वर्ष'}
                    </button>
                  ))}
                </div>
              </div>

              {/* KPI Cards (No pill wraps) */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="p-4 bg-slate-950 rounded-xl border border-slate-800">
                  <div className="text-xs text-slate-400 flex items-center justify-between">
                    <span>मासिक आवर्ती आय (MRR)</span>
                    <DollarSign className="w-3.5 h-3.5 text-emerald-400" />
                  </div>
                  <div className="text-2xl font-bold text-white mt-1 tabular-nums">
                    {selectedTimeframe === '30d' ? '₹8,45,000' : selectedTimeframe === '90d' ? '₹24,30,000' : '₹1.02 Cr'}
                  </div>
                  <div className="text-xs text-emerald-400 mt-1 flex items-center gap-1">
                    <TrendingUp className="w-3 h-3" /> +18.4% पिछले माह से
                  </div>
                </div>

                <div className="p-4 bg-slate-950 rounded-xl border border-slate-800">
                  <div className="text-xs text-slate-400 flex items-center justify-between">
                    <span>सक्रिय कॉर्पोरेट क्लाइंट्स</span>
                    <UsersIcon className="w-3.5 h-3.5 text-indigo-400" />
                  </div>
                  <div className="text-2xl font-bold text-white mt-1 tabular-nums">
                    {selectedTimeframe === '30d' ? '142' : selectedTimeframe === '90d' ? '280' : '520'}
                  </div>
                  <div className="text-xs text-indigo-400 mt-1">99.2% रिटेंशन रेट</div>
                </div>

                <div className="p-4 bg-slate-950 rounded-xl border border-slate-800">
                  <div className="text-xs text-slate-400 flex items-center justify-between">
                    <span>औसत डील साइज</span>
                    <TrendingUp className="w-3.5 h-3.5 text-amber-400" />
                  </div>
                  <div className="text-2xl font-bold text-white mt-1 tabular-nums">₹1,85,000</div>
                  <div className="text-xs text-slate-400 mt-1">Enterprise Plan</div>
                </div>

                <div className="p-4 bg-slate-950 rounded-xl border border-slate-800">
                  <div className="text-xs text-slate-400 flex items-center justify-between">
                    <span>कन्वर्जन रेट</span>
                    <UserCheck className="w-3.5 h-3.5 text-cyan-400" />
                  </div>
                  <div className="text-2xl font-bold text-white mt-1 tabular-nums">34.8%</div>
                  <div className="text-xs text-cyan-400 mt-1">उद्योग औसत से 2x अधिक</div>
                </div>
              </div>

              {/* Deal Pipeline Table */}
              <div>
                <div className="flex items-center justify-between mb-3">
                  <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-400">
                    डील पाइपलाइन (क्लिक करके स्टेज आगे बढ़ाएं)
                  </h4>
                  <span className="text-xs text-slate-500">4 सक्रिय सौदे</span>
                </div>
                
                <div className="space-y-2">
                  {pipelineDeals.map(deal => (
                    <div 
                      key={deal.id}
                      className="p-3 bg-slate-950 rounded-xl border border-slate-800 flex flex-wrap items-center justify-between gap-3"
                    >
                      <div>
                        <div className="text-sm font-semibold text-white">{deal.company}</div>
                        <div className="text-xs text-slate-400 mt-0.5">वैल्यू: <strong className="text-slate-200 tabular-nums">{deal.value}</strong></div>
                      </div>
                      
                      <div className="flex items-center gap-3">
                        <div className="text-xs text-slate-300 font-medium">
                          स्टेज: <span className="text-indigo-400">{deal.stage}</span>
                        </div>
                        <button
                          onClick={() => advanceStage(deal.id)}
                          className="px-3 py-1 text-xs font-medium text-slate-300 bg-slate-800 hover:bg-slate-700 rounded-lg transition-colors cursor-pointer inline-flex items-center gap-1.5"
                        >
                          <RefreshCw className="w-3 h-3 text-indigo-400" />
                          <span>अगला चरण</span>
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

            </div>
          )}

          {/* DEMO 3: BOOKING CALENDAR */}
          {activeDemo === 'booking' && (
            <div className="space-y-6 animate-in fade-in duration-300">
              
              <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-800 pb-4">
                <div>
                  <h3 className="text-lg font-bold text-white">ऑनलाइन अपॉइंटमेंट शेड्यूलिंग सिस्टम</h3>
                  <p className="text-xs text-slate-400 mt-0.5">स्पेशलिस्ट चुनें, टाइम स्लॉट सिलेक्ट करें और इंस्टेंट कन्फर्मेशन पाएं</p>
                </div>
                <div className="text-xs text-emerald-400 flex items-center gap-1">
                  <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
                  स्लॉट अवेलेबिलिटी: लाइव
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                
                {/* 1. Doctor / Specialist Selection */}
                <div className="space-y-3">
                  <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-400">
                    1. डॉक्टर / विशेषज्ञ चुनें
                  </h4>
                  {doctors.map(doc => (
                    <div
                      key={doc.id}
                      onClick={() => {
                        setSelectedDoc(doc);
                        setBookingConfirmed(false);
                      }}
                      className={`p-3.5 rounded-xl border transition-all cursor-pointer ${
                        selectedDoc.id === doc.id
                          ? 'bg-indigo-950/60 border-indigo-500 shadow-sm'
                          : 'bg-slate-950 border-slate-800 hover:border-slate-700'
                      }`}
                    >
                      <div className="text-sm font-semibold text-white">{doc.name}</div>
                      <div className="text-xs text-indigo-300 mt-0.5">{doc.specialty}</div>
                      <div className="flex items-center justify-between text-xs text-slate-400 mt-2">
                        <span>{doc.exp}</span>
                        <span className="font-bold text-white">{doc.fee}</span>
                      </div>
                    </div>
                  ))}
                </div>

                {/* 2. Slot Selection */}
                <div className="space-y-3">
                  <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-400">
                    2. दिन व समय चुनें
                  </h4>
                  <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-3">
                    <div className="text-xs text-slate-300 font-medium">तारीख:</div>
                    <div className="grid grid-cols-2 gap-2 text-xs">
                      {['आज (शाम)', 'कल (सुबह)', 'परसों (सुबह)', 'शनिवार'].map(d => (
                        <button
                          key={d}
                          onClick={() => {
                            setSelectedDate(d);
                            setBookingConfirmed(false);
                          }}
                          className={`p-2 rounded-lg border text-center transition-colors cursor-pointer ${
                            selectedDate === d
                              ? 'bg-indigo-600 border-indigo-500 text-white'
                              : 'bg-slate-900 border-slate-800 text-slate-300 hover:text-white'
                          }`}
                        >
                          {d}
                        </button>
                      ))}
                    </div>

                    <div className="text-xs text-slate-300 font-medium pt-2 border-t border-slate-800">
                      उपलब्ध टाइम स्लॉट्स:
                    </div>
                    <div className="grid grid-cols-3 gap-1.5 text-xs">
                      {['10:00 AM', '11:30 AM', '12:15 PM', '04:00 PM', '05:30 PM', '06:45 PM'].map(slot => (
                        <button
                          key={slot}
                          onClick={() => {
                            setSelectedSlot(slot);
                            setBookingConfirmed(false);
                          }}
                          className={`py-1.5 px-2 rounded border text-center font-mono transition-colors cursor-pointer ${
                            selectedSlot === slot
                              ? 'bg-emerald-600 border-emerald-500 text-white'
                              : 'bg-slate-900 border-slate-800 text-slate-300 hover:text-white'
                          }`}
                        >
                          {slot}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>

                {/* 3. Booking Confirmation Card */}
                <div className="space-y-3">
                  <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-400">
                    3. बुकिंग स्लिप व पुष्टिकरण
                  </h4>
                  <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 flex flex-col justify-between h-[280px]">
                    <div>
                      <div className="text-xs text-slate-400">चयनित विवरण:</div>
                      <div className="text-sm font-bold text-white mt-1">{selectedDoc.name}</div>
                      <div className="text-xs text-indigo-300">{selectedDoc.specialty}</div>

                      <div className="mt-4 p-2.5 bg-slate-900 rounded-lg border border-slate-800 space-y-1 text-xs">
                        <div className="flex justify-between text-slate-400">
                          <span>तारीख:</span>
                          <span className="text-slate-200">{selectedDate}</span>
                        </div>
                        <div className="flex justify-between text-slate-400">
                          <span>समय स्लॉट:</span>
                          <span className="text-slate-200 font-mono">{selectedSlot}</span>
                        </div>
                        <div className="flex justify-between text-slate-400">
                          <span>कंसल्टेशन फीस:</span>
                          <span className="text-slate-200 font-bold">{selectedDoc.fee}</span>
                        </div>
                      </div>
                    </div>

                    {bookingConfirmed ? (
                      <div className="p-3 bg-emerald-950/70 border border-emerald-700 rounded-lg text-center animate-in zoom-in-95">
                        <CheckCircle2 className="w-5 h-5 text-emerald-400 mx-auto mb-1" />
                        <div className="text-xs font-bold text-emerald-300">अपॉइंटमेंट कन्फर्म! (टोकन #42)</div>
                        <div className="text-[11px] text-emerald-400/80 mt-0.5">व्हाट्सएप रिमाइंडर सेट कर दिया गया है</div>
                      </div>
                    ) : (
                      <button
                        onClick={() => setBookingConfirmed(true)}
                        className="w-full py-2.5 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-500 rounded-lg transition-colors cursor-pointer flex items-center justify-center gap-1.5 shadow-sm"
                      >
                        <Clock className="w-3.5 h-3.5" />
                        <span>इंस्टेंट बुकिंग कन्फर्म करें</span>
                      </button>
                    )}
                  </div>
                </div>

              </div>

            </div>
          )}

        </div>

      </div>
    </section>
  );
};
