import React from 'react';
import { TECHNICAL_CAPABILITIES } from '../data/platformsData';
import { Terminal, Shield, Database, PlugZap, CheckCircle2 } from 'lucide-react';

export const TechStackMatrix: React.FC = () => {
  const getIcon = (idx: number) => {
    switch (idx) {
      case 0: return <Terminal className="w-5 h-5 text-indigo-400" />;
      case 1: return <Shield className="w-5 h-5 text-emerald-400" />;
      case 2: return <Database className="w-5 h-5 text-cyan-400" />;
      default: return <PlugZap className="w-5 h-5 text-amber-400" />;
    }
  };

  return (
    <section id="tech" className="py-16 md:py-24 border-b border-slate-800/80">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="max-w-3xl mb-12">
          <div className="text-xs font-semibold text-indigo-400 tracking-wider uppercase mb-2">
            Engineering Standards & Stack
          </div>
          <h2 className="text-2xl sm:text-3xl md:text-4xl font-bold text-white tracking-tight text-balance">
            मजबूत, आधुनिक और स्केलेबल इंजीनियरिंग क्षमताएं
          </h2>
          <p className="mt-3 text-base text-slate-300">
            हम कोई आधी-अधूरी वेबसाइट नहीं, बल्कि उत्पादन स्तर (Production-Ready) की पूर्ण स्टैक वेब प्रणालियाँ तैयार करते हैं।
          </p>
        </div>

        {/* 4 Pillars Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {TECHNICAL_CAPABILITIES.map((cap, idx) => (
            <div 
              key={idx}
              className="bg-slate-900/70 border border-slate-800 rounded-2xl p-6 sm:p-8 flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center gap-3 mb-4">
                  <div className="p-2.5 bg-slate-950 rounded-xl border border-slate-800">
                    {getIcon(idx)}
                  </div>
                  <div>
                    <div className="text-xs text-indigo-400 font-semibold">{cap.area}</div>
                    <h3 className="text-lg font-bold text-white mt-0.5">{cap.title}</h3>
                  </div>
                </div>

                <div className="pt-4 border-t border-slate-800/80">
                  <ul className="space-y-2.5">
                    {cap.items.map((item, itemIdx) => (
                      <li key={itemIdx} className="text-xs text-slate-300 flex items-start gap-2.5">
                        <CheckCircle2 className="w-4 h-4 text-indigo-400 shrink-0 mt-0.5" />
                        <span className="leading-relaxed">{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>

              <div className="mt-6 pt-4 border-t border-slate-800/60 text-[11px] text-slate-400 flex items-center justify-between">
                <span>Enterprise Architecture</span>
                <span className="text-slate-300 font-mono">100% Type-Safe</span>
              </div>
            </div>
          ))}
        </div>

      </div>
    </section>
  );
};
