import React from 'react';
import { ArrowRight, Layers, ShieldCheck, Cpu, Code2 } from 'lucide-react';

interface HeroProps {
  onExploreClick: () => void;
  onDemoClick: () => void;
  onPlanClick: () => void;
  onAiClick: () => void;
  onGuardianClick?: () => void;
  onMasterClick?: () => void;
  onTrainingClick?: () => void;
  onCrossDeviceClick?: () => void;
  onSecurityClick?: () => void;
}

export const Hero: React.FC<HeroProps> = ({
  onExploreClick,
  onDemoClick,
  onPlanClick,
  onAiClick,
  onGuardianClick,
  onMasterClick,
  onTrainingClick,
  onCrossDeviceClick,
  onSecurityClick,
}) => {
  return (
    <section className="relative overflow-hidden pt-12 pb-16 md:pt-20 md:pb-24 border-b border-slate-800/80">
      {/* Background glow subtle effect */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[650px] h-[360px] bg-amber-500/10 blur-[130px] rounded-full pointer-events-none -z-10" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          
          {/* Left Column: Value proposition and Direct Answer */}
          <div className="lg:col-span-7 space-y-6">
            <div className="flex flex-wrap items-center gap-2">
              <div className="text-xs font-bold text-amber-400 bg-amber-500/10 border border-amber-500/30 px-3 py-1 rounded-full uppercase tracking-wider flex items-center gap-1.5">
                <span>👑 साथी (Saathi) · मालिक सागर के लिए 100% समर्पित</span>
              </div>
              <button
                onClick={onSecurityClick}
                className="text-xs font-semibold text-emerald-400 bg-emerald-500/10 hover:bg-emerald-500/20 border border-emerald-500/30 px-3 py-1 rounded-full uppercase tracking-wider flex items-center gap-1 cursor-pointer transition-colors"
              >
                <span>🔒 एंटी-ट्रैकिंग व AI मॉडल वॉल्ट</span>
              </button>
              <button
                onClick={onCrossDeviceClick}
                className="text-xs font-semibold text-sky-400 bg-sky-500/10 hover:bg-sky-500/20 border border-sky-500/30 px-3 py-1 rounded-full uppercase tracking-wider flex items-center gap-1 cursor-pointer transition-colors"
              >
                <span>📱💻 फोन+लैपटॉप सिंक (0 लैग)</span>
              </button>
            </div>

            <h1 className="text-3xl sm:text-4xl md:text-5xl font-extrabold text-white tracking-tight leading-[1.18] text-balance">
              मिलिए <span className="text-amber-400">‘साथी’</span> से — आपका आज्ञाकारी, स्व-सुधारने वाला व पूर्ण प्रशिक्षित AI असिस्टेंट
            </h1>

            <p className="text-base sm:text-lg text-slate-300 leading-relaxed max-w-2xl font-normal">
              मालिक सागर, <strong className="text-white font-semibold">‘साथी’</strong> केवल आपकी आज्ञा मानेगा। आप इसे जेमिनी, चैटजीपीटी और सभी आधुनिक AI टूल्स का उपयोग करना खुद सिखा सकते हैं। कोई भी काम देने पर यह <strong className="text-amber-400 font-semibold">2 से 3 बार खुद जांचेगा</strong> कि कोई गलती तो नहीं है, उसे ठीक करेगा, और आपकी अनुमति से पूरे प्लेटफ़ॉर्म को मक्खन की तरह स्मूथ चलाएगा।
            </p>

            {/* CTAs */}
            <div className="pt-2 flex flex-wrap items-center gap-3">
              <button
                onClick={onTrainingClick || onMasterClick}
                className="px-6 py-3 text-sm font-bold text-slate-950 bg-amber-400 rounded-lg hover:bg-amber-300 transition-colors shadow-sm inline-flex items-center gap-2 cursor-pointer"
              >
                <span>🎓 साथी को सिखाएं (Training Studio)</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <button
                onClick={onMasterClick || onAiClick}
                className="px-5 py-3 text-sm font-semibold text-slate-200 bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded-lg transition-colors cursor-pointer inline-flex items-center gap-2"
              >
                <span>👑 3-Pass बग-चेक व अप्रूवल</span>
              </button>
              
              <button
                onClick={onAiClick}
                className="px-5 py-3 text-sm font-medium text-slate-300 hover:text-white bg-slate-900 border border-slate-800 rounded-lg transition-colors cursor-pointer"
              >
                साथी से बात करें
              </button>
            </div>

            {/* Claim-to-Proof Quantitative Adjacency without pill boxes */}
            <div className="pt-6 border-t border-slate-800/80 grid grid-cols-3 gap-4">
              <div>
                <div className="text-2xl font-bold text-white tabular-nums">7+</div>
                <div className="text-xs text-slate-400 mt-0.5">प्रमुख प्लेटफ़ॉर्म श्रेणियां</div>
              </div>
              <div>
                <div className="text-2xl font-bold text-white tabular-nums">100%</div>
                <div className="text-xs text-slate-400 mt-0.5">कस्टम कोड व ओनरशिप</div>
              </div>
              <div>
                <div className="text-2xl font-bold text-white tabular-nums">0-Latency</div>
                <div className="text-xs text-slate-400 mt-0.5">मोबाइल-फर्स्ट स्पीड</div>
              </div>
            </div>
          </div>

          {/* Right Column: Visual Focal Carrier with Zero-Broken-Image fallback */}
          <div className="lg:col-span-5">
            <div className="relative rounded-2xl overflow-hidden border border-slate-800 bg-slate-900 shadow-2xl">
              <img
                src="/src/assets/images/platform_hero_architecture_1790256964571.jpg"
                alt="Platform Architecture & Digital Ecosystem"
                referrerPolicy="no-referrer"
                className="w-full h-auto object-cover aspect-video hover:scale-[1.02] transition-transform duration-500"
                onError={(e) => {
                  // Resilient zero-broken-image fallback
                  e.currentTarget.style.display = 'none';
                  const fallback = e.currentTarget.parentElement?.querySelector('.fallback-box') as HTMLElement;
                  if (fallback) fallback.style.display = 'flex';
                }}
              />
              <div 
                className="fallback-box hidden w-full aspect-video bg-gradient-to-br from-slate-900 via-indigo-950 to-slate-900 p-8 flex-col justify-center items-center text-center"
              >
                <Layers className="w-12 h-12 text-indigo-400 mb-3" />
                <h3 className="text-lg font-bold text-white">Full-Stack Digital Platform</h3>
                <p className="text-xs text-slate-400 mt-1">Production-ready React, Express & Database Architecture</p>
              </div>

              {/* Bottom Architectural Summary Bar */}
              <div className="p-4 bg-slate-950/90 border-t border-slate-800/80 flex items-center justify-between text-xs text-slate-400">
                <span className="flex items-center gap-1.5 text-slate-300">
                  <Code2 className="w-3.5 h-3.5 text-indigo-400" />
                  React 19 · Node Express · Cloud SQL / Firestore
                </span>
                <span className="flex items-center gap-1.5 text-emerald-400">
                  <ShieldCheck className="w-3.5 h-3.5" />
                  Enterprise Ready
                </span>
              </div>
            </div>
          </div>

        </div>
      </div>
    </section>
  );
};
