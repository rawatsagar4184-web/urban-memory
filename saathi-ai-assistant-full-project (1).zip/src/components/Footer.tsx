import React from 'react';
import { ArrowUp } from 'lucide-react';

export const Footer: React.FC = () => {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="bg-[#060910] border-t border-slate-800/80 py-12 text-slate-400 text-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row items-center justify-between gap-6">
          
          {/* Brand */}
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-amber-400"></span>
            <span className="text-sm font-bold text-white tracking-tight">साथी (Saathi) AI</span>
            <span className="text-amber-400/90 ml-1 font-medium">· मालिक: सागर रावत</span>
          </div>

          {/* Nav Links */}
          <div className="flex flex-wrap items-center justify-center gap-6 text-slate-400">
            <a href="#saathi-training" className="hover:text-amber-400 transition-colors">ट्रेनिंग स्टूडियो</a>
            <a href="#master-control" className="hover:text-white transition-colors">मालिक कंट्रोल</a>
            <a href="#guardian" className="hover:text-white transition-colors">ऑटो-हीलिंग</a>
            <a href="#ai-assistant" className="hover:text-white transition-colors">साथी चैट</a>
            <a href="#categories" className="hover:text-white transition-colors">प्लेटफ़ॉर्म</a>
            <a href="#demos" className="hover:text-white transition-colors">लाइव डेमो</a>
          </div>

          {/* Back to top */}
          <div>
            <button
              onClick={scrollToTop}
              className="inline-flex items-center gap-1.5 text-slate-400 hover:text-white transition-colors cursor-pointer"
            >
              <span>ऊपर जाएं</span>
              <ArrowUp className="w-3.5 h-3.5" />
            </button>
          </div>

        </div>

        {/* Bottom subtle copyright */}
        <div className="mt-8 pt-6 border-t border-slate-900 text-center text-slate-400">
          <p>Google AI Studio Build · प्रोडक्शन-ग्रेड वेब एप्लिकेशन्स और कस्टम सॉफ्टवेयर आर्किटेक्चर</p>
        </div>
      </div>
    </footer>
  );
};
