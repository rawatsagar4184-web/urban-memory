import React, { useState } from 'react';
import { PLATFORMS_DATA } from '../data/platformsData';
import { PlatformItem, PlatformCategory } from '../types/platform';
import { 
  ShoppingBag, 
  LayoutDashboard, 
  GraduationCap, 
  CalendarCheck, 
  Home, 
  BrainCircuit, 
  Users, 
  ArrowUpRight, 
  Check, 
  X, 
  Database, 
  Layers, 
  Sparkles,
  Clock
} from 'lucide-react';

interface PlatformShowcaseProps {
  onSelectForPlanner: (platformId: string) => void;
}

export const PlatformShowcase: React.FC<PlatformShowcaseProps> = ({ onSelectForPlanner }) => {
  const [activeTab, setActiveTab] = useState<PlatformCategory | 'all'>('all');
  const [selectedPlatform, setSelectedPlatform] = useState<PlatformItem | null>(null);

  const filteredPlatforms = activeTab === 'all' 
    ? PLATFORMS_DATA 
    : PLATFORMS_DATA.filter(p => p.category === activeTab);

  const getCategoryIcon = (category: PlatformCategory) => {
    switch (category) {
      case 'ecommerce': return <ShoppingBag className="w-4 h-4" />;
      case 'saas': return <LayoutDashboard className="w-4 h-4" />;
      case 'edtech': return <GraduationCap className="w-4 h-4" />;
      case 'booking': return <CalendarCheck className="w-4 h-4" />;
      case 'realestate': return <Home className="w-4 h-4" />;
      case 'ai_tools': return <BrainCircuit className="w-4 h-4" />;
      case 'community': return <Users className="w-4 h-4" />;
    }
  };

  return (
    <section id="categories" className="py-16 md:py-24 border-b border-slate-800/80">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="max-w-3xl mb-12">
          <div className="text-xs font-semibold text-indigo-400 tracking-wider uppercase mb-2">
            Core Architecture Catalog
          </div>
          <h2 className="text-2xl sm:text-3xl md:text-4xl font-bold text-white tracking-tight text-balance">
            7 प्रमुख प्रकार के प्लेटफ़ॉर्म जो हम आपके लिए बना सकते हैं
          </h2>
          <p className="mt-3 text-base text-slate-300">
            प्रत्येक प्लेटफ़ॉर्म को आपके बिजनेस लॉजिक, डेटाबेस नियमों और ब्रांड पहचान के अनुसार पूरी तरह कस्टमाइज़ किया जा सकता है।
          </p>
        </div>

        {/* Filter Segmented Controls (Interactive buttons) */}
        <div className="flex flex-wrap items-center gap-1.5 p-1.5 bg-slate-900 border border-slate-800 rounded-xl mb-10 w-fit">
          <button
            onClick={() => setActiveTab('all')}
            className={`px-3.5 py-1.5 text-xs font-medium rounded-lg transition-colors cursor-pointer ${
              activeTab === 'all'
                ? 'bg-indigo-600 text-white'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            सभी 7 प्लेटफॉर्म्स
          </button>
          {PLATFORMS_DATA.map(platform => (
            <button
              key={platform.id}
              onClick={() => setActiveTab(platform.category)}
              className={`inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-medium rounded-lg transition-colors cursor-pointer ${
                activeTab === platform.category
                  ? 'bg-indigo-600 text-white'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              {getCategoryIcon(platform.category)}
              <span>{platform.titleEnglish.split(' ')[0]}</span>
            </button>
          ))}
        </div>

        {/* Bento / Asymmetric Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredPlatforms.map((platform, idx) => {
            const isFeatured = idx === 0 || idx === 1;
            return (
              <div
                key={platform.id}
                className={`group bg-slate-900/60 hover:bg-slate-900 border border-slate-800 hover:border-slate-700 rounded-2xl transition-all duration-300 flex flex-col justify-between overflow-hidden ${
                  isFeatured && activeTab === 'all' ? 'md:col-span-2 lg:col-span-2' : ''
                }`}
              >
                {/* Image slot if available and featured */}
                {platform.image && (
                  <div className="relative aspect-[16/9] w-full overflow-hidden bg-slate-950 border-b border-slate-800">
                    <img
                      src={platform.image}
                      alt={platform.titleHindi}
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                      onError={(e) => {
                        e.currentTarget.style.display = 'none';
                      }}
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/20 to-transparent" />
                    <div className="absolute bottom-3 left-4 right-4 flex items-center justify-between text-xs text-slate-300">
                      <span className="font-semibold text-white">{platform.titleEnglish}</span>
                      <span className="text-slate-400 flex items-center gap-1">
                        <Clock className="w-3 h-3 text-indigo-400" />
                        {platform.estimatedTimeline}
                      </span>
                    </div>
                  </div>
                )}

                {/* Card Body */}
                <div className="p-6 flex-1 flex flex-col">
                  {/* Clean unboxed metadata (NO PILLS) */}
                  <div className="flex items-center gap-2 text-xs text-slate-400 mb-3">
                    <span className="text-indigo-400 font-semibold">{String(idx + 1).padStart(2, '0')}.</span>
                    <span>{platform.titleEnglish}</span>
                    <span aria-hidden="true">·</span>
                    <span>फुल-स्टैक रेडी</span>
                  </div>

                  {/* Title */}
                  <h3 className="text-xl font-bold text-white mb-2 group-hover:text-indigo-300 transition-colors">
                    {platform.titleHindi}
                  </h3>

                  {/* Description */}
                  <p className="text-sm text-slate-300 leading-relaxed mb-4">
                    {platform.descriptionHindi}
                  </p>

                  {/* Key Modules List */}
                  <div className="mt-auto pt-4 border-t border-slate-800/80">
                    <div className="text-xs font-semibold text-slate-400 mb-2">मुख्य फीचर्स और मॉड्यूल्स:</div>
                    <ul className="space-y-1.5 mb-5">
                      {platform.featuredModules.slice(0, 3).map((mod, i) => (
                        <li key={i} className="text-xs text-slate-300 flex items-start gap-2">
                          <Check className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
                          <span>{mod}</span>
                        </li>
                      ))}
                    </ul>

                    {/* Action buttons */}
                    <div className="flex items-center justify-between gap-3 pt-2">
                      <button
                        onClick={() => setSelectedPlatform(platform)}
                        className="text-xs font-semibold text-indigo-400 hover:text-indigo-300 transition-colors inline-flex items-center gap-1 cursor-pointer"
                      >
                        <span>विस्तृत आर्किटेक्चर देखें</span>
                        <ArrowUpRight className="w-3.5 h-3.5" />
                      </button>

                      <button
                        onClick={() => onSelectForPlanner(platform.id)}
                        className="px-3 py-1.5 text-xs font-semibold text-white bg-slate-800 hover:bg-indigo-600 rounded-lg transition-colors cursor-pointer"
                      >
                        यह बनाना है
                      </button>
                    </div>
                  </div>

                </div>

              </div>
            );
          })}
        </div>

      </div>

      {/* Modal for Deep Technical Architecture Blueprint */}
      {selectedPlatform && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="bg-slate-900 border border-slate-700 rounded-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto p-6 md:p-8 shadow-2xl relative">
            
            {/* Close Button */}
            <button
              onClick={() => setSelectedPlatform(null)}
              className="absolute top-5 right-5 p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
              aria-label="बंद करें"
            >
              <X className="w-5 h-5" />
            </button>

            {/* Header info */}
            <div className="flex items-center gap-2 text-xs text-slate-400 mb-2">
              <span className="text-indigo-400 font-semibold">{selectedPlatform.titleEnglish}</span>
              <span aria-hidden="true">·</span>
              <span>आर्किटेक्चर विवरण</span>
            </div>

            <h3 className="text-2xl font-bold text-white mb-2">
              {selectedPlatform.titleHindi}
            </h3>
            <p className="text-sm text-indigo-300 font-medium mb-4">
              {selectedPlatform.taglineHindi}
            </p>

            <p className="text-sm text-slate-300 leading-relaxed mb-6">
              {selectedPlatform.descriptionHindi}
            </p>

            {/* Tech Stack Blueprint */}
            <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 mb-6 space-y-2.5">
              <div className="text-xs font-bold text-indigo-400 flex items-center gap-1.5 mb-2">
                <Layers className="w-3.5 h-3.5" />
                तकनीकी स्टैक (Recommended Tech Stack)
              </div>
              <div className="text-xs text-slate-300 flex items-center justify-between">
                <span className="text-slate-400">फ़्रंटएंड:</span>
                <span className="font-mono text-slate-200">{selectedPlatform.techStack.frontend}</span>
              </div>
              <div className="text-xs text-slate-300 flex items-center justify-between">
                <span className="text-slate-400">बैकएंड:</span>
                <span className="font-mono text-slate-200">{selectedPlatform.techStack.backend}</span>
              </div>
              <div className="text-xs text-slate-300 flex items-center justify-between">
                <span className="text-slate-400">डेटाबेस:</span>
                <span className="font-mono text-slate-200">{selectedPlatform.techStack.database}</span>
              </div>
              <div className="text-xs text-slate-300 flex items-center justify-between">
                <span className="text-slate-400">इंटीग्रेशंस:</span>
                <span className="font-mono text-slate-200">{selectedPlatform.techStack.integrations.join(', ')}</span>
              </div>
            </div>

            {/* All Featured Modules */}
            <div className="mb-6">
              <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider mb-3">
                प्लेटफ़ॉर्म में शामिल सभी फीचर्स:
              </h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {selectedPlatform.featuredModules.map((mod, i) => (
                  <div key={i} className="text-xs text-slate-300 flex items-start gap-2 bg-slate-800/40 p-2.5 rounded-lg border border-slate-800">
                    <Check className="w-3.5 h-3.5 text-indigo-400 shrink-0 mt-0.5" />
                    <span>{mod}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Real World Use Cases */}
            <div className="mb-6">
              <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider mb-3">
                वास्तविक उपयोग (Real World Use Cases):
              </h4>
              <ul className="space-y-1.5">
                {selectedPlatform.sampleUseCasesHindi.map((uc, i) => (
                  <li key={i} className="text-xs text-slate-300 flex items-center gap-2">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
                    <span>{uc}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Timeline & Planner Button */}
            <div className="pt-4 border-t border-slate-800 flex items-center justify-between gap-4">
              <div className="text-xs text-slate-400">
                अनुमानित विकास समय: <strong className="text-white">{selectedPlatform.estimatedTimeline}</strong>
              </div>
              <button
                onClick={() => {
                  const id = selectedPlatform.id;
                  setSelectedPlatform(null);
                  onSelectForPlanner(id);
                }}
                className="px-4 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-500 rounded-lg transition-colors cursor-pointer inline-flex items-center gap-1.5"
              >
                <Sparkles className="w-3.5 h-3.5" />
                <span>इस प्रकार का प्लेटफॉर्म प्लान करें</span>
              </button>
            </div>

          </div>
        </div>
      )}
    </section>
  );
};
