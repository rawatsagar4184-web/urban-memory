import React, { useState } from 'react';
import { 
  Wand2, 
  Copy, 
  Check, 
  Sparkles, 
  Database, 
  ShieldCheck, 
  Cpu, 
  Calendar, 
  ChevronRight,
  RefreshCw,
  Layers
} from 'lucide-react';

interface ArchitecturePlannerProps {
  initialCategory?: string;
}

export const ArchitecturePlanner: React.FC<ArchitecturePlannerProps> = ({ initialCategory }) => {
  const [platformType, setPlatformType] = useState(initialCategory || 'ecommerce');
  const [scale, setScale] = useState<'mvp' | 'growth' | 'enterprise'>('growth');
  const [selectedFeatures, setSelectedFeatures] = useState<string[]>([
    'auth',
    'database',
    'admin_panel',
    'payments',
    'responsive_ui'
  ]);
  const [useAI, setUseAI] = useState(true);
  const [customGoal, setCustomGoal] = useState('');
  const [copied, setCopied] = useState(false);

  const toggleFeature = (id: string) => {
    setSelectedFeatures(prev => 
      prev.includes(id) ? prev.filter(f => f !== id) : [...prev, id]
    );
  };

  const featureOptions = [
    { id: 'auth', label: 'यूजर लॉगिन व साइन-अप (Email + Google OAuth)' },
    { id: 'database', label: 'क्लाउड डेटाबेस (Firestore / Cloud SQL)' },
    { id: 'payments', label: 'ऑनलाइन पेमेंट गेटवे (Razorpay / Stripe / UPI)' },
    { id: 'admin_panel', label: 'एडमिन कंट्रोल रूम व रोल-बेस्ड परमिशन्स' },
    { id: 'analytics', label: 'लाइव सेल्स व यूज़र एनालिटिक्स चार्ट्स' },
    { id: 'notifications', label: 'व्हाट्सएप / ईमेल ऑटोमेटेड नोटिफिकेशन्स' },
    { id: 'responsive_ui', label: 'मोबाइल-फर्स्ट PWA रेडी यूआई' },
    { id: 'file_storage', label: 'डॉक्यूमेंट व इमेज अपलोड स्टोरेज' }
  ];

  // Derive generated prompt based on selections
  const generatePrompt = () => {
    const platformNames: Record<string, string> = {
      ecommerce: 'ई-कॉमर्स और ऑनलाइन स्टोर (E-Commerce Platform)',
      saas: 'B2B SaaS व बिजनेस मैनेजमेंट डैशबोर्ड (Business Dashboard)',
      edtech: 'ई-लर्निंग व कोर्स मैनेजमेंट सिस्टम (LMS EdTech)',
      booking: 'अपॉइंटमेंट शेड्यूलिंग व सर्विस बुकिंग पोर्टल (Booking Portal)',
      realestate: 'रियल एस्टेट व प्रॉपर्टी लिस्टिंग पोर्टल (Real Estate Portal)',
      ai_tools: 'कस्टम Gemini AI पावर्ड ऑटोमेशन टूल (AI Automation Tool)',
      community: 'कम्युनिटी व सोशल डिस्कशन फोरम (Community Hub)'
    };

    const targetName = platformNames[platformType] || 'कस्टम वेब प्लेटफॉर्म';
    const activeFeatsText = selectedFeatures.map(f => {
      const found = featureOptions.find(o => o.id === f);
      return found ? found.label : f;
    }).join(', ');

    return `कृपया मेरे लिए निम्नलिखित स्पेसिफिकेशन के आधार पर एक संपूर्ण प्लेटफॉर्म बनाएं:

1. प्लेटफॉर्म का प्रकार: ${targetName}
2. स्केल स्तर: ${scale === 'mvp' ? 'MVP (न्यूनतम व्यवहार्य उत्पाद)' : scale === 'growth' ? 'ग्रोइंग बिजनेस रेडी' : 'हाई-स्केल एंटरप्राइज'}
3. आवश्यक मुख्य फीचर्स:
   - ${activeFeatsText}
   ${useAI ? '- Google Gemini AI इंटीग्रेशन (स्मार्ट असिस्टेंस व ऑटोमेशन)' : ''}
${customGoal ? `4. अतिरिक्त व्यावसायिक आवश्यकताएं: ${customGoal}\n` : ''}
5. तकनीकी अपेक्षाएं:
   - React 19, TypeScript, Tailwind CSS
   - एक्सप्रेस/नोड.जेएस बैकएंड और क्लाउड डेटाबेस
   - पिक्सल-परफेक्ट, मोबाइल-रिस्पॉन्सिव और सुरुचिपूर्ण डिज़ाइन
   - हिंदी व अंग्रेजी (द्विभाषी) सपोर्ट`;
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(generatePrompt());
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  return (
    <section id="planner" className="py-16 md:py-24 border-b border-slate-800/80">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="max-w-3xl mb-12">
          <div className="text-xs font-semibold text-indigo-400 tracking-wider uppercase mb-2">
            Interactive Architecture Planner
          </div>
          <h2 className="text-2xl sm:text-3xl md:text-4xl font-bold text-white tracking-tight text-balance">
            अपना कस्टम प्लेटफ़ॉर्म प्लान करें व तकनीकी खाका तैयार करें
          </h2>
          <p className="mt-3 text-base text-slate-300">
            अपनी ज़रूरत चुनें। हमारा आर्किटेक्ट इंजन तुरंत आपके लिए उपयुक्त टेक स्टैक, डेटाबेस स्कीमा और AI Studio का रेडी-टू-रन प्रॉम्प्ट तैयार कर देगा।
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* Controls Column */}
          <div className="lg:col-span-6 space-y-6 bg-slate-900 border border-slate-800 rounded-2xl p-6 sm:p-8">
            
            {/* 1. Platform Type */}
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-2">
                1. आप किस तरह का प्लेटफॉर्म बनाना चाहते हैं?
              </label>
              <select
                value={platformType}
                onChange={(e) => setPlatformType(e.target.value)}
                className="w-full bg-slate-950 text-white text-sm px-4 py-3 rounded-xl border border-slate-700 focus:outline-none focus:border-indigo-500 cursor-pointer"
              >
                <option value="ecommerce">ई-कॉमर्स स्टोर / डिजिटल मार्केटप्लेस (E-Commerce)</option>
                <option value="saas">B2B SaaS / बिजनेस डैशबोर्ड व CRM</option>
                <option value="edtech">ई-लर्निंग / कोचिंग व LMS पोर्टल</option>
                <option value="booking">अपॉइंटमेंट शेड्यूलर / डॉक्टर व कंसल्टेंट बुकिंग</option>
                <option value="realestate">रियल एस्टेट / प्रॉपर्टी लिस्टिंग डायरेक्टरी</option>
                <option value="ai_tools">कस्टम Gemini AI ऑटोमेशन टूल</option>
                <option value="community">कम्युनिटी फोरम व मेंबरशिप नेटवर्क</option>
              </select>
            </div>

            {/* 2. Scale Tier */}
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-2">
                2. प्रोजेक्ट का पैमाना (Scale):
              </label>
              <div className="grid grid-cols-3 gap-2">
                {[
                  { key: 'mvp', label: 'MVP / प्रोटोटाइप', desc: 'त्वरित टेस्टिंग' },
                  { key: 'growth', label: 'ग्रोइंग बिजनेस', desc: 'फुल फीचर्स' },
                  { key: 'enterprise', label: 'एंटरप्राइज', desc: 'मल्टी-रोल स्केलिंग' },
                ].map(item => (
                  <button
                    key={item.key}
                    type="button"
                    onClick={() => setScale(item.key as any)}
                    className={`p-3 rounded-xl border text-left transition-colors cursor-pointer ${
                      scale === item.key 
                        ? 'bg-indigo-950/60 border-indigo-500 text-white' 
                        : 'bg-slate-950 border-slate-800 text-slate-300 hover:border-slate-700'
                    }`}
                  >
                    <div className="text-xs font-bold">{item.label}</div>
                    <div className="text-[11px] text-slate-400 mt-0.5">{item.desc}</div>
                  </button>
                ))}
              </div>
            </div>

            {/* 3. Features Multi-Select */}
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-2">
                3. आवश्यक मुख्य मॉड्यूल्स चुनें:
              </label>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {featureOptions.map(feat => {
                  const isChecked = selectedFeatures.includes(feat.id);
                  return (
                    <button
                      key={feat.id}
                      type="button"
                      onClick={() => toggleFeature(feat.id)}
                      className={`p-2.5 rounded-lg border text-left text-xs transition-colors flex items-center justify-between cursor-pointer ${
                        isChecked 
                          ? 'bg-indigo-950/40 border-indigo-500/80 text-white' 
                          : 'bg-slate-950 border-slate-800 text-slate-400 hover:border-slate-700'
                      }`}
                    >
                      <span className="truncate pr-2">{feat.label}</span>
                      <div className={`w-4 h-4 rounded flex items-center justify-center shrink-0 border ${
                        isChecked ? 'bg-indigo-600 border-indigo-600 text-white' : 'border-slate-700'
                      }`}>
                        {isChecked && <Check className="w-3 h-3" />}
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* 4. AI Feature Toggle */}
            <div className="p-3.5 bg-slate-950 rounded-xl border border-slate-800 flex items-center justify-between">
              <div>
                <div className="text-xs font-semibold text-white flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-indigo-400" />
                  Google Gemini AI फीचर्स जोड़ें
                </div>
                <div className="text-[11px] text-slate-400 mt-0.5">
                  स्मार्ट असिस्टेंट, ऑटोमेटेड समरी या कंटेंट जनरेशन
                </div>
              </div>
              <button
                type="button"
                onClick={() => setUseAI(!useAI)}
                className={`w-11 h-6 rounded-full transition-colors relative cursor-pointer ${
                  useAI ? 'bg-indigo-600' : 'bg-slate-800'
                }`}
              >
                <div className={`w-4 h-4 rounded-full bg-white absolute top-1 transition-transform ${
                  useAI ? 'left-6' : 'left-1'
                }`} />
              </button>
            </div>

            {/* 5. Custom Requirements Text */}
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-2">
                5. आपका कोई विशेष नियम या व्यावसायिक विवरण (वैकल्पिक):
              </label>
              <textarea
                value={customGoal}
                onChange={(e) => setCustomGoal(e.target.value)}
                placeholder="उदा: मुझे डिलीवरी बॉयज के लिए अलग पोर्टल चाहिए, या मेरे पास 500 से अधिक प्रॉडक्ट्स हैं..."
                rows={2}
                className="w-full bg-slate-950 text-white text-xs px-3.5 py-2.5 rounded-xl border border-slate-700 focus:outline-none focus:border-indigo-500 placeholder:text-slate-500"
              />
            </div>

          </div>

          {/* Generated Architecture Blueprint Column */}
          <div className="lg:col-span-6 space-y-6">
            
            {/* Tech Blueprint Box */}
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 sm:p-8">
              <div className="flex items-center justify-between pb-4 border-b border-slate-800">
                <div className="flex items-center gap-2 text-xs font-bold text-indigo-400 uppercase tracking-wider">
                  <Cpu className="w-4 h-4" />
                  अनुशंसित तकनीकी आर्किटेक्चर
                </div>
                <span className="text-xs text-slate-400">Production-Ready</span>
              </div>

              <div className="mt-4 space-y-3 text-xs">
                <div className="flex justify-between items-center py-1.5 border-b border-slate-800/60">
                  <span className="text-slate-400">फ़्रंटएंड स्टैक:</span>
                  <span className="text-white font-mono">React 19 + TypeScript + Tailwind CSS</span>
                </div>
                <div className="flex justify-between items-center py-1.5 border-b border-slate-800/60">
                  <span className="text-slate-400">बैकएंड सर्वर:</span>
                  <span className="text-white font-mono">Express Node.js REST API</span>
                </div>
                <div className="flex justify-between items-center py-1.5 border-b border-slate-800/60">
                  <span className="text-slate-400">डेटाबेस लेयर:</span>
                  <span className="text-white font-mono">
                    {scale === 'enterprise' ? 'Cloud SQL (PostgreSQL)' : 'Firestore Cloud Database'}
                  </span>
                </div>
                <div className="flex justify-between items-center py-1.5 border-b border-slate-800/60">
                  <span className="text-slate-400">ऑथेंटिकेशन:</span>
                  <span className="text-white font-mono">Firebase Auth / Role-Based JWT</span>
                </div>
                {useAI && (
                  <div className="flex justify-between items-center py-1.5 border-b border-slate-800/60">
                    <span className="text-slate-400">AI मॉडल:</span>
                    <span className="text-indigo-300 font-mono">Gemini 2.5 Flash (@google/genai)</span>
                  </div>
                )}
              </div>

              {/* Database Schema Entities Preview */}
              <div className="mt-6 pt-4 border-t border-slate-800">
                <div className="text-xs font-semibold text-slate-300 mb-2 flex items-center gap-1.5">
                  <Database className="w-3.5 h-3.5 text-indigo-400" />
                  डेटाबेस कलेक्शन/टेबल्स रूपरेखा:
                </div>
                <div className="grid grid-cols-2 gap-2 text-xs text-slate-400 font-mono">
                  <div className="bg-slate-950 p-2 rounded border border-slate-800">
                    <span className="text-indigo-400 font-bold">users/</span> (roles, auth, profile)
                  </div>
                  <div className="bg-slate-950 p-2 rounded border border-slate-800">
                    <span className="text-indigo-400 font-bold">records/</span> (orders, bookings, items)
                  </div>
                  <div className="bg-slate-950 p-2 rounded border border-slate-800">
                    <span className="text-indigo-400 font-bold">activity/</span> (logs, status, audit)
                  </div>
                  <div className="bg-slate-950 p-2 rounded border border-slate-800">
                    <span className="text-indigo-400 font-bold">settings/</span> (config, payments, api)
                  </div>
                </div>
              </div>
            </div>

            {/* Generated AI Studio Prompt Box */}
            <div className="bg-slate-900 border border-indigo-950 rounded-2xl p-6 sm:p-8">
              <div className="flex items-center justify-between mb-3">
                <div className="text-xs font-bold text-white flex items-center gap-1.5">
                  <Wand2 className="w-3.5 h-3.5 text-indigo-400" />
                  AI Studio प्रॉम्प्ट (1-क्लिक में कॉपी करें):
                </div>
                <button
                  onClick={handleCopy}
                  className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors cursor-pointer flex items-center gap-1.5 ${
                    copied 
                      ? 'bg-emerald-600 text-white' 
                      : 'bg-indigo-600 hover:bg-indigo-500 text-white'
                  }`}
                >
                  {copied ? (
                    <>
                      <Check className="w-3.5 h-3.5" />
                      <span>कॉपी हो गया!</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5" />
                      <span>प्रॉम्प्ट कॉपी करें</span>
                    </>
                  )}
                </button>
              </div>

              <div className="relative">
                <pre className="p-4 bg-slate-950 rounded-xl border border-slate-800 text-[11px] text-slate-300 font-mono overflow-x-auto whitespace-pre-wrap leading-relaxed max-h-56">
                  {generatePrompt()}
                </pre>
              </div>

              <p className="text-[11px] text-slate-400 mt-3">
                💡 <strong>टिप:</strong> आप इस प्रॉम्प्ट को कॉपी करके सीधे चैट बॉक्स में भेज सकते हैं, और हम इस पूरे प्लेटफॉर्म को इसी वर्कस्पेस में अभी लाइव कोड कर देंगे!
              </p>
            </div>

          </div>

        </div>

      </div>
    </section>
  );
};
