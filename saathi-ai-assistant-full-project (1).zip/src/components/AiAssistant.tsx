import React, { useState, useRef, useEffect } from 'react';
import { 
  Bot, 
  Send, 
  Sparkles, 
  User, 
  Copy, 
  Check, 
  RotateCcw, 
  Briefcase, 
  Code, 
  Headphones, 
  PenTool, 
  HelpCircle,
  Cpu,
  ArrowRight,
  ShieldCheck,
  Zap,
  MessageSquare,
  Crown,
  ThumbsUp,
  ThumbsDown,
  Brain,
  Globe,
  Key
} from 'lucide-react';

interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: string;
}

export const AiAssistant: React.FC = () => {
  const [persona, setPersona] = useState<'guardian' | 'business' | 'tech' | 'customer_support' | 'creative'>('guardian');
  const [modelEngine, setModelEngine] = useState<'gemini' | 'chatgpt' | 'claude' | 'deepseek' | 'perplexity'>('gemini');
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'welcome',
      role: 'assistant',
      content: 'प्रणाम मालिक सागर! मैं आपका आज्ञाकारी AI असिस्टेंट "साथी (Saathi)" हूँ। मैं जेमिनी, चैटजीपीटी और सभी आधुनिक AI टूल्स से लैस हूँ।\n\nआप मुझे जो भी सिखाएंगे, मैं उसे 100% निष्ठा से सीखूँगा। कोई भी काम देने पर मैं पहले 2-3 बार अपनी गलतियाँ खुद खोजूँगा, सारे बग्स हटाऊँगा, और फिर आपकी मंज़ूरी लेकर ही काम फाइनल करूँगा।\n\nआज्ञा दीजिए मालिक, आज क्या काम करना है?',
      timestamp: 'अभी'
    }
  ]);
  const [inputMessage, setInputMessage] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const personaList = [
    {
      id: 'guardian',
      label: 'सुरक्षा व आत्म-सुधार (Guardian)',
      desc: 'ऑटो-बग फिक्स, WAF सुरक्षा व स्मूथ ऑटोपायलट',
      icon: <ShieldCheck className="w-4 h-4 text-emerald-400" />
    },
    {
      id: 'business',
      label: 'बिज़नेस एडवाइजर',
      desc: 'स्टार्टअप आइडिया, रेवेन्यू व ग्रोथ',
      icon: <Briefcase className="w-4 h-4 text-indigo-400" />
    },
    {
      id: 'tech',
      label: 'सॉफ्टवेयर आर्किटेक्ट',
      desc: 'फुल-स्टैक कोडिंग, API व डेटाबेस',
      icon: <Code className="w-4 h-4 text-cyan-400" />
    },
    {
      id: 'customer_support',
      label: '24/7 कस्टमर केयर बॉट',
      desc: 'सपोर्ट, टिकट व समस्या निवारण',
      icon: <Headphones className="w-4 h-4 text-purple-400" />
    },
    {
      id: 'creative',
      label: 'कंटेंट व मार्केटिंग एक्सपर्ट',
      desc: 'विज्ञापन, सोशल मीडिया व कॉपीराइटिंग',
      icon: <PenTool className="w-4 h-4 text-amber-400" />
    },
  ];

  const starterPrompts = [
    'ग्रोथ माइंडसेट: AI इतना उन्नत काम कैसे करती है? आज आपने क्या नया सीखा?',
    'हमारा डेटा कोई ट्रैक या हैक न कर सके, और नए AI मॉडल्स कैसे सुरक्षित रहेंगे?',
    'अगर मैं लैपटॉप घर में छोड़कर बाहर जाऊं, तो फोन पर आप कैसे काम संभालोगे?',
    'अगर डेटाबेस या सर्वर क्रैश हो जाए तो आप इसे स्वतः कैसे ठीक करोगे?',
    'मेरा वेब प्लेटफॉर्म बिना किसी लैग के 100% स्मूथ कैसे चलेगा?'
  ];

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isLoading]);

  const handleSendMessage = async (customText?: string) => {
    const textToSend = (customText || inputMessage).trim();
    if (!textToSend || isLoading) return;

    const userMsg: ChatMessage = {
      id: `u-${Date.now()}`,
      role: 'user',
      content: textToSend,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setMessages(prev => [...prev, userMsg]);
    setInputMessage('');
    setIsLoading(true);

    try {
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: textToSend,
          persona,
          modelEngine,
          history: messages.map(m => ({ role: m.role, content: m.content }))
        })
      });

      const data = await response.json();
      const replyContent = data.reply || data.error || 'माफ़ कीजिए, कोई उत्तर प्राप्त नहीं हुआ।';

      const assistantMsg: ChatMessage = {
        id: `a-${Date.now()}`,
        role: 'assistant',
        content: replyContent,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };

      setMessages(prev => [...prev, assistantMsg]);

      // Cross-Device Sync Stream
      try {
        fetch('/api/devices/sync-message', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            text: textToSend,
            sender: 'user',
            sourceDevice: typeof window !== 'undefined' && window.innerWidth < 768 ? '📱 फोन' : '💻 लैपटॉप'
          })
        }).catch(() => {});
      } catch {}
    } catch (err: any) {
      const errorMsg: ChatMessage = {
        id: `e-${Date.now()}`,
        role: 'assistant',
        content: 'सर्वर से कनेक्ट करने में समस्या हुई। कृपया पुनः प्रयास करें।',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };
      setMessages(prev => [...prev, errorMsg]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleCopy = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const clearChat = () => {
    setMessages([
      {
        id: 'welcome',
        role: 'assistant',
        content: 'प्रणाम मालिक सागर! चैट रीसेट हो गई है। साथी आपकी आज्ञा का पालन करने के लिए तैयार है। आप क्या काम करवाना या सिखाना चाहते हैं?',
        timestamp: 'अभी'
      }
    ]);
  };

  return (
    <section id="ai-assistant" className="py-16 md:py-24 border-b border-slate-800/80">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="max-w-3xl mb-12">
          <div className="text-xs font-semibold text-amber-400 tracking-wider uppercase mb-2 flex items-center gap-1.5">
            <Crown className="w-4 h-4 text-amber-400" />
            Live Saathi AI Assistant & Master Console
          </div>
          <h2 className="text-2xl sm:text-3xl md:text-4xl font-bold text-white tracking-tight text-balance">
            ‘साथी’ लाइव असिस्टेंट — हर आदेश का 100% अनुपालन
          </h2>
          <p className="mt-3 text-base text-slate-300 leading-relaxed">
            मालिक सागर, आप साथी से यहाँ सीधे बातचीत कर सकते हैं। यह जेमिनी 3.8 फ़्लैश, चैटजीपीटी व क्लॉड टूल्स से जुड़ा है और हर उत्तर से पहले 3-Pass स्व-परीक्षण करता है।
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* Main Chat Interface */}
          <div className="lg:col-span-8 bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-2xl flex flex-col h-[640px]">
            
            {/* Top Bar: Persona Selection & Status */}
            <div className="p-4 bg-slate-950 border-b border-slate-800 flex flex-wrap items-center justify-between gap-3">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-lg bg-indigo-600/20 border border-indigo-500/40 flex items-center justify-center text-indigo-400">
                  <Bot className="w-5 h-5" />
                </div>
                <div>
                  <div className="text-xs font-bold text-white flex items-center gap-2">
                    <span className="flex items-center gap-1 text-amber-300">
                      <Crown className="w-3.5 h-3.5 text-amber-400" />
                      मालिक सागर के लिए समर्पित AI
                    </span>
                    <span className="inline-flex items-center gap-1 text-[10px] text-emerald-400 font-normal">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
                      100% आज्ञाकारी
                    </span>
                  </div>
                  <div className="text-[11px] text-slate-400 flex items-center gap-1.5">
                    <span>3-Pass स्व-परीक्षण इंजन</span>
                    <span>·</span>
                    <span className="text-indigo-400">Gemini 3.8 Flash</span>
                  </div>
                </div>
              </div>

              {/* Chat Actions */}
              <div className="flex items-center gap-2">
                <span className="inline-flex items-center gap-1 text-[10px] sm:text-[11px] text-emerald-300 bg-emerald-500/10 border border-emerald-500/30 px-2 py-0.5 sm:px-2.5 sm:py-1 rounded-full">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                  <span>💻📱 लैपटॉप + फोन सिंक</span>
                </span>
                <span className="hidden sm:inline-flex items-center gap-1 text-[11px] text-amber-300/90 bg-amber-500/10 border border-amber-500/30 px-2.5 py-1 rounded-full">
                  <Key className="w-3 h-3 text-amber-400" />
                  <span>API Key बाद में जोड़ें</span>
                </span>
                <button
                  onClick={clearChat}
                  title="बातचीत रीसेट करें"
                  className="p-1.5 text-xs text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors cursor-pointer flex items-center gap-1"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span className="hidden sm:inline">रीसेट</span>
                </button>
              </div>
            </div>

            {/* AI Engine Switcher (Gemini, ChatGPT, Claude, DeepSeek, Perplexity) */}
            <div className="px-4 py-2 bg-slate-950/80 border-b border-slate-800 flex items-center justify-between gap-2 overflow-x-auto text-xs">
              <div className="flex items-center gap-1.5 shrink-0">
                <span className="text-[11px] font-bold text-white flex items-center gap-1">
                  <Cpu className="w-3.5 h-3.5 text-indigo-400" />
                  AI इंजन:
                </span>
              </div>
              <div className="flex items-center gap-1.5 overflow-x-auto">
                <button
                  type="button"
                  onClick={() => setModelEngine('gemini')}
                  className={`px-2.5 py-1 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer whitespace-nowrap ${
                    modelEngine === 'gemini'
                      ? 'bg-amber-400 text-slate-950 shadow-sm'
                      : 'bg-slate-900 border border-slate-800 text-slate-300 hover:text-white'
                  }`}
                >
                  <Sparkles className="w-3 h-3 text-amber-500" />
                  <span>Google Gemini 3.8</span>
                </button>
                <button
                  type="button"
                  onClick={() => setModelEngine('chatgpt')}
                  className={`px-2.5 py-1 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer whitespace-nowrap ${
                    modelEngine === 'chatgpt'
                      ? 'bg-emerald-500 text-white shadow-sm'
                      : 'bg-slate-900 border border-slate-800 text-slate-300 hover:text-white'
                  }`}
                >
                  <Bot className="w-3 h-3 text-emerald-400" />
                  <span>OpenAI ChatGPT-4o</span>
                </button>
                <button
                  type="button"
                  onClick={() => setModelEngine('claude')}
                  className={`px-2.5 py-1 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer whitespace-nowrap ${
                    modelEngine === 'claude'
                      ? 'bg-orange-500 text-white shadow-sm'
                      : 'bg-slate-900 border border-slate-800 text-slate-300 hover:text-white'
                  }`}
                >
                  <Cpu className="w-3 h-3 text-orange-400" />
                  <span>Claude 3.5 Sonnet</span>
                </button>
                <button
                  type="button"
                  onClick={() => setModelEngine('deepseek')}
                  className={`px-2.5 py-1 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer whitespace-nowrap ${
                    modelEngine === 'deepseek'
                      ? 'bg-cyan-500 text-white shadow-sm'
                      : 'bg-slate-900 border border-slate-800 text-slate-300 hover:text-white'
                  }`}
                >
                  <Brain className="w-3 h-3 text-cyan-400" />
                  <span>DeepSeek R1</span>
                </button>
                <button
                  type="button"
                  onClick={() => setModelEngine('perplexity')}
                  className={`px-2.5 py-1 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer whitespace-nowrap ${
                    modelEngine === 'perplexity'
                      ? 'bg-sky-500 text-white shadow-sm'
                      : 'bg-slate-900 border border-slate-800 text-slate-300 hover:text-white'
                  }`}
                >
                  <Globe className="w-3 h-3 text-sky-400" />
                  <span>Perplexity AI</span>
                </button>
              </div>
            </div>

            {/* Persona Switcher Buttons */}
            <div className="px-4 py-2 bg-slate-950/60 border-b border-slate-800/80 flex items-center gap-2 overflow-x-auto text-xs">
              <span className="text-[11px] text-slate-400 shrink-0 font-medium">रोल चुनें:</span>
              {personaList.map(p => (
                <button
                  key={p.id}
                  onClick={() => setPersona(p.id as any)}
                  className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-lg font-medium whitespace-nowrap transition-colors cursor-pointer text-xs ${
                    persona === p.id 
                      ? 'bg-indigo-600 text-white shadow-sm' 
                      : 'bg-slate-900 border border-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  {p.icon}
                  <span>{p.label}</span>
                </button>
              ))}
            </div>

            {/* Messages Scroll Area */}
            <div className="flex-1 p-4 sm:p-6 overflow-y-auto space-y-4 bg-slate-900/40">
              {messages.map((msg) => {
                const isAssistant = msg.role === 'assistant';
                return (
                  <div
                    key={msg.id}
                    className={`flex items-start gap-3 ${isAssistant ? '' : 'flex-row-reverse'}`}
                  >
                    {/* Avatar */}
                    <div className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 text-xs font-semibold ${
                      isAssistant 
                        ? 'bg-indigo-600/30 text-indigo-300 border border-indigo-500/40' 
                        : 'bg-slate-800 text-slate-200 border border-slate-700'
                    }`}>
                      {isAssistant ? <Bot className="w-4 h-4" /> : <User className="w-4 h-4" />}
                    </div>

                    {/* Message Bubble */}
                    <div className={`group relative max-w-[85%] rounded-2xl p-4 text-xs sm:text-sm leading-relaxed ${
                      isAssistant 
                        ? 'bg-slate-950 border border-slate-800 text-slate-200' 
                        : 'bg-indigo-600 text-white'
                    }`}>
                      {isAssistant && (
                        <div className="mb-2.5 pb-2 border-b border-slate-800/80 flex items-center justify-between text-[10px]">
                          <span className="inline-flex items-center gap-1 text-amber-400 font-semibold bg-amber-500/10 px-2 py-0.5 rounded-full border border-amber-500/20">
                            <Crown className="w-3 h-3 text-amber-400" />
                            3-Pass स्व-परीक्षण: 0 Bugs Verified
                          </span>
                          <span className="text-slate-500">मालिक की मंज़ूरी प्रतीक्षित</span>
                        </div>
                      )}

                      <div className="whitespace-pre-wrap font-sans">{msg.content}</div>
                      
                      {/* Master Feedback Quick Buttons for Assistant */}
                      {isAssistant && (
                        <div className="mt-3 pt-2 border-t border-slate-800/60 flex flex-wrap items-center justify-between gap-2 text-[11px]">
                          <div className="flex items-center gap-1.5">
                            <span className="text-[10px] text-slate-400">आपकी समीक्षा:</span>
                            <button
                              onClick={() => {
                                handleSendMessage("हाँ, यह बिल्कुल ठीक है! इसे फाइनल करो।");
                              }}
                              className="px-2 py-0.5 bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 rounded flex items-center gap-1 cursor-pointer transition-colors"
                            >
                              <ThumbsUp className="w-2.5 h-2.5" />
                              <span>ठीक है</span>
                            </button>
                            <button
                              onClick={() => {
                                handleSendMessage("इसमें थोड़ी कमी है, इसे दोबारा 3 बार चेक करके और सुधारो।");
                              }}
                              className="px-2 py-0.5 bg-amber-500/10 hover:bg-amber-500/20 text-amber-300 border border-amber-500/30 rounded flex items-center gap-1 cursor-pointer transition-colors"
                            >
                              <ThumbsDown className="w-2.5 h-2.5" />
                              <span>सुधार करो</span>
                            </button>
                          </div>

                          <div className="flex items-center gap-2 text-[10px] text-slate-500">
                            <span>{msg.timestamp}</span>
                            <button
                              onClick={() => handleCopy(msg.id, msg.content)}
                              className="opacity-0 group-hover:opacity-100 transition-opacity text-slate-400 hover:text-white flex items-center gap-1 cursor-pointer"
                            >
                              {copiedId === msg.id ? (
                                <>
                                  <Check className="w-3 h-3 text-emerald-400" />
                                  <span className="text-emerald-400">कॉपी</span>
                                </>
                              ) : (
                                <>
                                  <Copy className="w-3 h-3" />
                                  <span>कॉपी</span>
                                </>
                              )}
                            </button>
                          </div>
                        </div>
                      )}

                      {!isAssistant && (
                        <div className="mt-2 pt-1.5 flex items-center justify-end text-[10px] text-indigo-200">
                          <span>{msg.timestamp}</span>
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}

              {isLoading && (
                <div className="flex items-start gap-3 animate-in fade-in">
                  <div className="w-8 h-8 rounded-lg bg-indigo-600/30 text-indigo-300 border border-indigo-500/40 flex items-center justify-center shrink-0">
                    <Bot className="w-4 h-4" />
                  </div>
                  <div className="bg-slate-950 border border-slate-800 rounded-2xl p-4 text-xs text-slate-400 flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-indigo-400 animate-bounce"></span>
                    <span className="w-2 h-2 rounded-full bg-indigo-400 animate-bounce [animation-delay:0.2s]"></span>
                    <span className="w-2 h-2 rounded-full bg-indigo-400 animate-bounce [animation-delay:0.4s]"></span>
                    <span className="ml-2 text-indigo-300 font-medium">सोच रहा हूँ...</span>
                  </div>
                </div>
              )}

              <div ref={messagesEndRef} />
            </div>

            {/* Quick Starters */}
            <div className="px-4 py-2 bg-slate-950/80 border-t border-slate-800 flex items-center gap-1.5 overflow-x-auto text-[11px] text-slate-400">
              <span className="shrink-0 text-indigo-400 font-medium">सुझाव:</span>
              {starterPrompts.map((prompt, i) => (
                <button
                  key={i}
                  onClick={() => handleSendMessage(prompt)}
                  className="px-2.5 py-1 bg-slate-900 border border-slate-800 rounded-lg hover:border-slate-700 hover:text-white transition-colors whitespace-nowrap cursor-pointer"
                >
                  {prompt}
                </button>
              ))}
            </div>

            {/* Input Form */}
            <form 
              onSubmit={(e) => {
                e.preventDefault();
                handleSendMessage();
              }}
              className="p-3 bg-slate-950 border-t border-slate-800 flex items-center gap-2"
            >
              <input
                type="text"
                value={inputMessage}
                onChange={(e) => setInputMessage(e.target.value)}
                placeholder="यहाँ अपना सवाल या प्रोजेक्ट आइडिया लिखें (उदा: मुझे एक कोचिंग ऐप के लिए AI चाहिए)..."
                disabled={isLoading}
                className="flex-1 bg-slate-900 text-white text-xs sm:text-sm px-4 py-2.5 rounded-xl border border-slate-700 focus:outline-none focus:border-indigo-500 placeholder:text-slate-500"
              />
              <button
                type="submit"
                disabled={!inputMessage.trim() || isLoading}
                className={`px-4 py-2.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer ${
                  inputMessage.trim() && !isLoading
                    ? 'bg-indigo-600 hover:bg-indigo-500 text-white shadow-sm'
                    : 'bg-slate-800 text-slate-500 cursor-not-allowed'
                }`}
              >
                <span>भेजें</span>
                <Send className="w-3.5 h-3.5" />
              </button>
            </form>

          </div>

          {/* Right Column: Custom AI Capabilities & Architectures */}
          <div className="lg:col-span-4 space-y-6">
            
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6">
              <h3 className="text-base font-bold text-white flex items-center gap-2 mb-3">
                <Cpu className="w-4 h-4 text-indigo-400" />
                हम आपके लिए कैसे AI असिस्टेंट्स बना सकते हैं?
              </h3>
              <p className="text-xs text-slate-300 leading-relaxed mb-4">
                हम आपके बिजनेस की विशेष आवश्यकताओं के अनुसार कस्टमाइज्ड और सुरक्षित AI सिस्टम तैयार करते हैं:
              </p>

              <div className="space-y-3.5">
                <div className="p-3 bg-slate-950 rounded-xl border border-slate-800">
                  <div className="text-xs font-bold text-indigo-300 flex items-center gap-1.5">
                    <Headphones className="w-3.5 h-3.5 text-indigo-400" />
                    1. 24/7 कस्टमर सपोर्ट एजेंट
                  </div>
                  <p className="text-[11px] text-slate-400 mt-1">
                    आपकी कंपनी के नियम, रिफंड पॉलिसी और प्रॉडक्ट सूची पर ट्रेंड बॉट जो बिना किसी ह्यूमन एजेंट के 90% सवालों का तुरंत उत्तर दे सकता है।
                  </p>
                </div>

                <div className="p-3 bg-slate-950 rounded-xl border border-slate-800">
                  <div className="text-xs font-bold text-emerald-300 flex items-center gap-1.5">
                    <Briefcase className="w-3.5 h-3.5 text-emerald-400" />
                    2. कंपनी नॉलेज बेस व PDF एनालाइजर
                  </div>
                  <p className="text-[11px] text-slate-400 mt-1">
                    सैकड़ों पेजों के कॉन्ट्रैक्ट्स, मैन्युअल, बिल और रिपोर्ट्स में से सेकंडों में सही जानकारी ढूँढने वाला स्मार्ट टूल।
                  </p>
                </div>

                <div className="p-3 bg-slate-950 rounded-xl border border-slate-800">
                  <div className="text-xs font-bold text-cyan-300 flex items-center gap-1.5">
                    <MessageSquare className="w-3.5 h-3.5 text-cyan-400" />
                    3. व्हाट्सएप व सोशल मीडिया AI बॉट
                  </div>
                  <p className="text-[11px] text-slate-400 mt-1">
                    सीधे व्हाट्सएप पर ग्राहकों से बात करके अपॉइंटमेंट बुक करने, ऑर्डर लेने और लीड्स कलेक्ट करने वाला स्वचालित बॉट।
                  </p>
                </div>

                <div className="p-3 bg-slate-950 rounded-xl border border-slate-800">
                  <div className="text-xs font-bold text-amber-300 flex items-center gap-1.5">
                    <Zap className="w-3.5 h-3.5 text-amber-400" />
                    4. इंटरनल वर्कफ़्लो व कोडिंग कोपायलट
                  </div>
                  <p className="text-[11px] text-slate-400 mt-1">
                    आपकी टीम के लिए स्वचालित ईमेल ड्राफ्टर, डेटा क्लीनर, टास्क प्लानर और रिपोर्ट जनरेटर।
                  </p>
                </div>
              </div>

              <div className="mt-6 pt-4 border-t border-slate-800 text-[11px] text-slate-400 flex items-center justify-between">
                <span className="flex items-center gap-1 text-emerald-400">
                  <ShieldCheck className="w-3.5 h-3.5" />
                  डेटा प्राइवेसी सुरक्षित
                </span>
                <span className="text-slate-300 font-mono">Enterprise Ready</span>
              </div>
            </div>

            {/* Quick CTA Box */}
            <div className="p-5 bg-gradient-to-br from-indigo-950/80 to-slate-900 border border-indigo-800/80 rounded-2xl">
              <h4 className="text-sm font-bold text-white flex items-center gap-1.5">
                <Sparkles className="w-4 h-4 text-indigo-400" />
                क्या आपको अपने ब्रांड का बॉट चाहिए?
              </h4>
              <p className="text-xs text-slate-300 mt-1.5 leading-relaxed">
                ऊपर चैट में लिखें कि आपका बिजनेस क्या है और आप अपने असिस्टेंट से क्या काम करवाना चाहते हैं—हम उसे तुरंत कॉन्फ़िगर कर देंगे!
              </p>
            </div>

          </div>

        </div>

      </div>
    </section>
  );
};
