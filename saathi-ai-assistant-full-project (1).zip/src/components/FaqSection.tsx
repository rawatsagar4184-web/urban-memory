import React, { useState } from 'react';
import { FREQUENT_QUESTIONS } from '../data/platformsData';
import { ChevronDown, HelpCircle, MessageSquare } from 'lucide-react';

interface FaqSectionProps {
  onStartClick: () => void;
}

export const FaqSection: React.FC<FaqSectionProps> = ({ onStartClick }) => {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  const toggle = (idx: number) => {
    setOpenIndex(prev => prev === idx ? null : idx);
  };

  return (
    <section id="faq" className="py-16 md:py-24 border-b border-slate-800/80">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto mb-12">
          <div className="text-xs font-semibold text-indigo-400 tracking-wider uppercase mb-2">
            Frequently Asked Questions
          </div>
          <h2 className="text-2xl sm:text-3xl md:text-4xl font-bold text-white tracking-tight">
            अक्सर पूछे जाने वाले सामान्य प्रश्न
          </h2>
          <p className="mt-3 text-sm text-slate-300">
            प्लेटफ़ॉर्म निर्माण, तकनीक, समय-सीमा और प्रोसेस के बारे में आपके मन के मुख्य प्रश्नों के उत्तर।
          </p>
        </div>

        {/* Accordion */}
        <div className="space-y-3">
          {FREQUENT_QUESTIONS.map((item, idx) => {
            const isOpen = openIndex === idx;
            return (
              <div 
                key={idx}
                className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden transition-colors"
              >
                <button
                  type="button"
                  onClick={() => toggle(idx)}
                  className="w-full p-5 text-left flex items-center justify-between gap-4 cursor-pointer hover:bg-slate-800/40 transition-colors"
                >
                  <span className="text-sm sm:text-base font-semibold text-white">
                    {item.questionHindi}
                  </span>
                  <ChevronDown className={`w-4 h-4 text-slate-400 shrink-0 transition-transform duration-200 ${
                    isOpen ? 'rotate-180 text-indigo-400' : ''
                  }`} />
                </button>

                {isOpen && (
                  <div className="px-5 pb-5 pt-1 text-xs sm:text-sm text-slate-300 leading-relaxed border-t border-slate-800/60 animate-in fade-in duration-150">
                    {item.answerHindi}
                  </div>
                )}
              </div>
            );
          })}
        </div>

        {/* Callout box for immediate action */}
        <div className="mt-12 p-6 bg-gradient-to-r from-indigo-950/60 via-slate-900 to-indigo-950/60 border border-indigo-900/60 rounded-2xl flex flex-col sm:flex-row items-center justify-between gap-6 text-center sm:text-left">
          <div>
            <h4 className="text-base font-bold text-white flex items-center justify-center sm:justify-start gap-2">
              <MessageSquare className="w-4 h-4 text-indigo-400" />
              क्या आपका कोई अलग या खास प्रोजेक्ट है?
            </h4>
            <p className="text-xs text-slate-300 mt-1 max-w-lg">
              आप सीधे चैट में बताएं कि आप क्या बनाना चाहते हैं। हम तुरंत आपके लिए डेटाबेस स्कीमा और लाइव वर्किंग कोड तैयार कर देंगे।
            </p>
          </div>
          <button
            onClick={onStartClick}
            className="px-5 py-2.5 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-500 rounded-lg transition-colors cursor-pointer shrink-0 shadow-sm"
          >
            अभी शुरू करें
          </button>
        </div>

      </div>
    </section>
  );
};
