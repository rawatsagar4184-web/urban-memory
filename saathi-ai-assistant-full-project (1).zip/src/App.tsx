/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Header } from './components/Header';
import { Hero } from './components/Hero';
import { CrossDeviceSyncHub } from './components/CrossDeviceSyncHub';
import { AntiHackVaultConsole } from './components/AntiHackVaultConsole';
import { SaathiTrainingStudio } from './components/SaathiTrainingStudio';
import { MasterCommandCenter } from './components/MasterCommandCenter';
import { SelfHealingGuardian } from './components/SelfHealingGuardian';
import { AiAssistant } from './components/AiAssistant';
import { PlatformShowcase } from './components/PlatformShowcase';
import { LivePrototypes } from './components/LivePrototypes';
import { ArchitecturePlanner } from './components/ArchitecturePlanner';
import { TechStackMatrix } from './components/TechStackMatrix';
import { FaqSection } from './components/FaqSection';
import { Footer } from './components/Footer';

export default function App() {
  const [selectedPlannerCategory, setSelectedPlannerCategory] = useState<string>('ecommerce');

  const scrollToSection = (id: string) => {
    const el = document.getElementById(id);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleSelectForPlanner = (platformId: string) => {
    setSelectedPlannerCategory(platformId);
    scrollToSection('planner');
  };

  return (
    <div className="min-h-screen bg-[#090D16] text-slate-100 flex flex-col font-sans selection:bg-amber-500 selection:text-slate-950">
      {/* Top Bar Navigation (3-Zone Contract) */}
      <Header
        onPlanClick={() => scrollToSection('planner')}
        onExploreClick={() => scrollToSection('categories')}
        onDemoClick={() => scrollToSection('demos')}
        onAiClick={() => scrollToSection('ai-assistant')}
        onGuardianClick={() => scrollToSection('guardian')}
        onMasterClick={() => scrollToSection('master-control')}
        onTrainingClick={() => scrollToSection('saathi-training')}
        onCrossDeviceClick={() => scrollToSection('cross-device-hub')}
        onSecurityClick={() => scrollToSection('security-vault')}
        onTechClick={() => scrollToSection('tech')}
        onFaqClick={() => scrollToSection('faq')}
      />

      {/* Main Content */}
      <main className="flex-1">
        {/* Hero Section */}
        <Hero
          onExploreClick={() => scrollToSection('categories')}
          onDemoClick={() => scrollToSection('demos')}
          onPlanClick={() => scrollToSection('guardian')}
          onAiClick={() => scrollToSection('ai-assistant')}
          onGuardianClick={() => scrollToSection('guardian')}
          onMasterClick={() => scrollToSection('master-control')}
          onTrainingClick={() => scrollToSection('saathi-training')}
          onCrossDeviceClick={() => scrollToSection('cross-device-hub')}
          onSecurityClick={() => scrollToSection('security-vault')}
        />

        {/* Anti-Tracking Vault & AI Model Security Quarantine */}
        <AntiHackVaultConsole />

        {/* Laptop & Mobile Ubiquity Hub & Zero-Lag Sync Engine */}
        <CrossDeviceSyncHub />

        {/* Saathi's Master Training Studio & Multi-AI Integration Hub (Gemini, ChatGPT, Claude) */}
        <SaathiTrainingStudio />

        {/* Master Ownership, Public Merge Switch & 3-Pass Self-Correction Engine */}
        <MasterCommandCenter />

        {/* Self-Healing Guardian, Bug Auto-Fix & Autopilot Platform Runner */}
        <SelfHealingGuardian />

        {/* Live Saathi AI Assistant Interactive Chat */}
        <AiAssistant />

        {/* 7 Core Platforms Catalog */}
        <PlatformShowcase onSelectForPlanner={handleSelectForPlanner} />

        {/* Interactive Working Sandboxes (E-Commerce, SaaS, Booking) */}
        <LivePrototypes />

        {/* Custom Architecture & Blueprint Planner */}
        <ArchitecturePlanner initialCategory={selectedPlannerCategory} />

        {/* Engineering Capabilities & Stack Matrix */}
        <TechStackMatrix />

        {/* Frequently Asked Questions */}
        <FaqSection onStartClick={() => scrollToSection('planner')} />
      </main>

      {/* Clean Quiet Footer */}
      <Footer />
    </div>
  );
}
